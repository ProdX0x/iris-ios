# Contributing

## Quick start

1. Fork the repo
2. Create a feature branch (`feat/new-skill-name` or `fix/skill-name-issue`)
3. Make your changes
4. Run `./validate-skills.sh`
5. Open a PR

## Adding a new skill

1. Create a folder under `skills/` with a lowercase hyphenated name matching the skill's `name` field.
2. Add a `SKILL.md` with YAML frontmatter:

```yaml
---
name: my-new-skill
description: >
  One or two sentences: what the skill does and when to use it. Include trigger phrases in English and French, like "generate the view", "génère la vue". The first word is a verb. Name the skills it requires.
---
```

3. Follow the standard body:

```markdown
# Skill Name

## Prerequisites check
[Which Docs/ files or generated files must exist. Name the skill that produces each. Stop if missing.]

## Step 1. Scope
[AskUserQuestion. Then search Docs/file-map.md for every type you are about to create.]

## Step 2 to N. [Design in chat, get approval, generate, register in file-map.md]

## Step N+1. Hand off
[Name the next skill by trigger phrase]

## What this skill produces
## Dependencies
## Rules
[never / always, non-negotiables]
```

4. Keep `SKILL.md` under 500 lines. Reference material goes in `references/`, scripts in `scripts/`, templates in `assets/`.

## Non-negotiables for every skill

- Reads `Docs/conventions.md` before generating anything.
- Searches `Docs/file-map.md` before creating any file. Never creates a type name that already exists.
- Registers every created, moved or deleted file in `Docs/file-map.md`.
- Designs in chat and gets approval via AskUserQuestion before writing files.
- One type per file, file name equals type name, header comment with Layer and Purpose.
- Never crosses a layer boundary. Redirects to the owning skill by name instead.
- Never uses em dashes. Short sentences. British English in skill text, English identifiers in code.

## Naming conventions

- Folder name = YAML `name` = lowercase, hyphen-separated
- Skill names read as noun phrases describing the output (`view-generator`, not `generating-views`)
- Three words max

## Testing locally

```bash
cp -r skills/my-new-skill ~/.claude/skills/
```

Open a test Xcode project, run `ios-project-foundation`, then trigger your skill.
