# iOS App Skills for AI Agents

19 Claude skills to build professional iOS apps from product idea to tested, audited code. MVVM in Presentation, Clean Architecture across Domain, Data and Presentation, Coordinators for navigation, a single composition root for dependency injection, and a file registry that makes duplication structurally impossible.

Built by [ProdX0x](https://github.com/prodx0x). Modelled on the structure of [charlie947/social-media-skills](https://github.com/charlie947/social-media-skills): foundation-first, auto-start, explicit dependencies, zero duplication.

**Contributions welcome.** Open a PR or an issue.

## What are Skills?

Skills are markdown files that give AI agents specialised workflows for specific tasks. When you install these in your project, Claude recognises when you are working on an iOS task and applies the right layer rules, naming conventions, file locations and quality gates.

## How Skills Work Together

Every skill reads shared context. `ios-project-foundation` is the foundation. Every other skill checks `Docs/conventions.md` and `Docs/file-map.md` first, and writes back to `file-map.md` every time it creates a file.

```
                 ┌──────────────────────────────────────────────┐
                 │           ios-project-foundation             │
                 │  Docs/project-brief.md · conventions.md ·    │
                 │  file-map.md   (read by every skill below)   │
                 └──────────────────────┬───────────────────────┘
                                        │
          ┌─────────────────────────────┼─────────────────────────────┐
          ▼                             ▼                             ▼
┌──────────────────┐        ┌──────────────────────┐        ┌──────────────────┐
│ product-         │        │ architecture-        │        │ ui-ux-designer   │
│  conception      │───────▶│  designer            │        │ design-system.md │
│ product.md       │        │ architecture.md      │        │ Tokens/          │
│ Features/*.md    │        └──────────┬───────────┘        └────────┬─────────┘
└────────┬─────────┘                   │                             │
         │              ┌──────────────▼───────────┐                 │
         │              │ file-structure-organizer │                 │
         │              │ folders + stubs          │                 │
         │              └──────────────┬───────────┘                 │
         ▼                             ▼                             ▼
┌─────────────────────┐   ┌─────────────────────┐   ┌──────────────────────────┐
│ Domain              │   │ Data                │   │ Presentation             │
├─────────────────────┤   ├─────────────────────┤   ├──────────────────────────┤
│ domain-modeler      │──▶│ data-layer-generator│   │ swiftui-component-library│
│ business-logic-     │   │                     │   │ viewmodel-generator      │
│  engine             │   └──────────┬──────────┘   │ view-generator           │
│ use-case-generator  │              │              │ coordinator-navigator    │
└──────────┬──────────┘              │              └────────────┬─────────────┘
           │                         ▼                           │
           │              ┌─────────────────────┐                │
           └─────────────▶│ dependency-injector │◀───────────────┘
                          │ Core/DI/AppContainer│
                          └──────────┬──────────┘
                                     ▼
        ┌──────────────┬─────────────┴──────────────┬──────────────────┐
        ▼              ▼                            ▼                  ▼
┌──────────────┐ ┌──────────────┐          ┌───────────────────┐ ┌──────────────┐
│ swift-coder  │ │test-generator│          │ code-deduplicator │ │layer-auditor │
└──────────────┘ └──────────────┘          └───────────────────┘ └──────────────┘
                                     ▲
                 ┌───────────────────┴───────────────────┐
                 │            feature-builder            │
                 │  orchestrates all 13 stages, gated    │
                 └───────────────────────────────────────┘
```

See each skill's `SKILL.md` for trigger phrases, inputs, outputs and dependencies.

## Available Skills

<!-- SKILLS:START -->
| Skill | Description |
|---|---|
| [ios-project-foundation](skills/ios-project-foundation/) | Interview to `Docs/project-brief.md`, `conventions.md` and `file-map.md`. The foundation every other skill reads. |
| [product-conception](skills/product-conception/) | Personas, jobs to be done, prioritised feature table, flows, acceptance criteria. Writes `product.md` and one spec per feature. |
| [architecture-designer](skills/architecture-designer/) | Layer diagram, feature to module map, navigation topology, data flow, ADRs. Writes `architecture.md`. |
| [file-structure-organizer](skills/file-structure-organizer/) | Generates the full folder tree and compilable stubs, audits misplaced files, registers everything. |
| [domain-modeler](skills/domain-modeler/) | Entities with typed IDs, value objects, typed errors, repository protocols. Pure Swift. Writes `domain-model.md`. |
| [business-logic-engine](skills/business-logic-engine/) | Business rules as entity methods and domain services, each with a rule ID. Extracts rules buried in ViewModels. |
| [use-case-generator](skills/use-case-generator/) | One protocol plus one default implementation per user action, single `execute`. |
| [data-layer-generator](skills/data-layer-generator/) | Repository implementations, remote and local data sources, DTOs, SwiftData models, mappers, error mapping. |
| [viewmodel-generator](skills/viewmodel-generator/) | `@MainActor @Observable` ViewModels with a single Phase enum, actions, presentation models, navigation intents. |
| [view-generator](skills/view-generator/) | SwiftUI views bound to a ViewModel, tokens and DS components only, three previews minimum. |
| [coordinator-navigator](skills/coordinator-navigator/) | Route enums, feature coordinators, AppCoordinator, tabs, modals, deep links. No navigation in views. |
| [ui-ux-designer](skills/ui-ux-designer/) | Semantic tokens, component inventory, text wireframes, HIG and accessibility rules. Writes `design-system.md`. |
| [swiftui-component-library](skills/swiftui-component-library/) | Implements `DS`-prefixed components with variants, states, accessibility and previews. Promotes shared components. |
| [swift-coder](skills/swift-coder/) | Minimal targeted edits and bug fixes with a before and after plan. Reuses existing code before writing new. |
| [code-deduplicator](skills/code-deduplicator/) | Exact, near and semantic duplicates plus dead code. Factorises into the right layer. Keeps `file-map.md` truthful. |
| [dependency-injector](skills/dependency-injector/) | Single `AppContainer`, typed factories, live, preview and test environments. Audits bypasses. |
| [test-generator](skills/test-generator/) | Swift Testing unit tests citing rule and AC IDs, hand-written mocks, fixtures, XCTest UI flows. |
| [layer-auditor](skills/layer-auditor/) | 11 consistency checks between layers, docs and disk. PASS or FAIL report with a fix plan mapped to skills. |
| [feature-builder](skills/feature-builder/) | Runs all 13 stages for one feature in order, gated, resumable, closed only on audit PASS. |
<!-- SKILLS:END -->

## Installation

### Option 1: Claude Code plugin marketplace

```bash
# Add the marketplace
/plugin marketplace add prodx0x/ios-app-skills

# Install the plugin
/plugin install ios-app-skills
```

### Option 2: Clone and copy

```bash
git clone https://github.com/prodx0x/ios-app-skills.git
cp -r ios-app-skills/skills/* ~/.claude/skills/
```

### Option 3: Individual skill upload (Claude Desktop)

```bash
cd ios-app-skills/skills
zip -r ios-project-foundation.skill ios-project-foundation
# Upload ios-project-foundation.skill through Customise skills in the Claude app
```

### Option 4: Git submodule

```bash
git submodule add https://github.com/prodx0x/ios-app-skills.git .agents/ios-app-skills
```

Then reference skills from `.agents/ios-app-skills/skills/`.

### Option 5: Project-local (Claude Code)

```bash
mkdir -p .claude/skills
cp -r ios-app-skills/skills/* .claude/skills/
```

Skills then travel with the Xcode project in git.

## Usage

Run `ios-project-foundation` first. Every other skill needs `Docs/conventions.md` and `Docs/file-map.md`.

Recommended first run on a new app:

```
"set up my iOS project"        → ios-project-foundation
"define the product"           → product-conception
"design the architecture"      → architecture-designer
"design the UI"                → ui-ux-designer
"generate the file structure"  → file-structure-organizer
"wire the dependencies"        → dependency-injector (bootstrap)
"build feature Invoices"       → feature-builder (everything else, gated)
```

Trigger phrases per skill (English and French both work):

```
"set up my iOS project" / "nouveau projet iOS"                → ios-project-foundation
"define the product" / "cadre les fonctionnalités"            → product-conception
"design the architecture" / "conçois l'architecture"          → architecture-designer
"generate the file structure" / "génère l'arborescence"       → file-structure-organizer
"model the domain" / "modélise le domaine"                    → domain-modeler
"write the business rules" / "règles métier"                  → business-logic-engine
"generate the use cases" / "génère les use cases"             → use-case-generator
"generate the data layer" / "implémente le repository"        → data-layer-generator
"generate the viewmodel for X" / "génère le viewmodel"        → viewmodel-generator
"generate the view for X" / "construis l'écran"               → view-generator
"wire the navigation" / "câble la navigation"                 → coordinator-navigator
"design the UI" / "design system" / "palette"                 → ui-ux-designer
"build the component library" / "composant réutilisable"      → swiftui-component-library
"fix this bug" / "corrige ce bug" / "implémente"              → swift-coder
"dedupe" / "trouve les doublons" / "code mort"                → code-deduplicator
"wire the dependencies" / "injection de dépendances"          → dependency-injector
"generate tests" / "génère les tests"                         → test-generator
"audit the layers" / "vérifie la cohérence"                   → layer-auditor
"build feature X" / "implémente X de bout en bout"            → feature-builder
```

## Skill Categories

### Foundation
- `ios-project-foundation` — interview, conventions, file registry

### Product and architecture
- `product-conception` — personas, features, acceptance criteria
- `architecture-designer` — layers, modules, navigation, ADRs
- `file-structure-organizer` — tree, stubs, audits misplaced files

### Domain
- `domain-modeler` — entities, value objects, errors, repository protocols
- `business-logic-engine` — rules with IDs, entity methods, domain services
- `use-case-generator` — protocol plus default implementation per action

### Data
- `data-layer-generator` — repositories, data sources, DTOs, mappers

### Presentation
- `viewmodel-generator` — Phase state, actions, presentation models
- `view-generator` — SwiftUI bound to ViewModel, previews
- `coordinator-navigator` — routes, coordinators, deep links

### Design
- `ui-ux-designer` — tokens, inventory, wireframes
- `swiftui-component-library` — DS components

### Implementation and quality
- `swift-coder` — targeted edits and fixes
- `code-deduplicator` — duplicates and dead code
- `dependency-injector` — AppContainer and environments
- `test-generator` — unit, mocks, UI tests
- `layer-auditor` — consistency verdict

### Orchestration
- `feature-builder` — 13 gated stages per feature

## Shared context files

All written to `Docs/` at the project root. Never scattered.

| File | Written by | Read by |
|---|---|---|
| `project-brief.md` | ios-project-foundation | all |
| `conventions.md` | ios-project-foundation | all |
| `file-map.md` | ios-project-foundation, then every skill | all |
| `product.md`, `Features/<Name>.md` | product-conception | architecture, domain, presentation, tests, feature-builder |
| `architecture.md` | architecture-designer | file-structure, data, DI, navigation, auditor |
| `domain-model.md` | domain-modeler, business-logic-engine, use-case-generator | data, presentation, tests |
| `design-system.md` | ui-ux-designer | component library, view-generator |
| `dedup-log.md` | code-deduplicator | code-deduplicator |
| `audit-<date>.md` | layer-auditor | feature-builder |

## Reference project layout

The tree every skill targets. Defined once in `Docs/conventions.md`.

```
<AppName>/
├── App/
│   ├── <AppName>App.swift
│   └── Resources/ (Assets.xcassets, Localizable.xcstrings)
├── Core/
│   ├── DI/          AppContainer.swift, AppEnvironment.swift, Registry.swift, AppContainer+<Feature>.swift
│   ├── Navigation/  AppCoordinator.swift, AppRoute.swift, AppCoordinatorView.swift, DeepLinkParser.swift
│   ├── Networking/  HTTPClient.swift
│   ├── Extensions/  <Type>+<Concern>.swift
│   └── Utilities/
├── DesignSystem/
│   ├── Tokens/      DSColor.swift, DSFont.swift, DSSpacing.swift, DSRadius.swift, DSMotion.swift
│   ├── Components/  DSButton.swift, DSScreen.swift, DSEmptyState.swift, ...
│   └── Modifiers/
├── Domain/
│   ├── Entities/<Feature>/      <Entity>.swift, <Entity>ID.swift
│   ├── ValueObjects/            Money.swift, Email.swift, ...
│   ├── Repositories/<Feature>/  <Noun>Repository.swift
│   ├── UseCases/<Feature>/      <Verb><Noun>UseCase.swift, Default<Verb><Noun>UseCase.swift
│   ├── Services/<Feature>/      <Name>Calculator.swift, <Name>Policy.swift
│   └── Errors/                  <Noun>Error.swift
├── Data/
│   ├── Repositories/<Feature>/         <Noun>RepositoryImpl.swift
│   ├── DataSources/Remote/<Feature>/   <Noun>RemoteDataSource.swift, URLSession<Noun>RemoteDataSource.swift
│   ├── DataSources/Local/<Feature>/    <Noun>LocalDataSource.swift, SwiftData<Noun>LocalDataSource.swift, <Noun>Model.swift
│   ├── DTOs/<Feature>/                 <Noun>DTO.swift
│   └── Mappers/<Feature>/              <Noun>Mapper.swift
├── Features/
│   └── <Feature>/
│       ├── Presentation/
│       │   ├── Views/        <Screen>View.swift
│       │   ├── ViewModels/   <Screen>ViewModel.swift, <Screen>+Models.swift, <Screen>ViewModel+Preview.swift
│       │   └── Components/   feature-only subviews
│       └── Coordinator/      <Feature>Route.swift, <Feature>Modal.swift, <Feature>Navigating.swift,
│                             <Feature>Coordinator.swift, <Feature>CoordinatorView.swift
├── Tests/
│   ├── UnitTests/
│   │   ├── Domain/<Feature>/, Data/<Feature>/, Presentation/<Feature>/
│   │   ├── Mocks/      Mock<Protocol>.swift
│   │   └── Fixtures/   <Entity>+Fixture.swift
│   └── UITests/        <Flow>UITests.swift
└── Docs/
    ├── project-brief.md, conventions.md, file-map.md
    ├── product.md, architecture.md, domain-model.md, design-system.md
    ├── dedup-log.md, audit-<date>.md
    └── Features/<Feature>.md
```

## Prerequisites

No external service. Skills use the tools available in Claude Code or Cowork: file read and write, shell (`xcodebuild`, `swift build`, `git`), and AskUserQuestion. Xcode 16 or later is recommended for folder-synchronised groups so that generated folders appear in the project without manual linking.

## Contributing

PRs and issues welcome. See [CONTRIBUTING.md](CONTRIBUTING.md). Run `./validate-skills.sh` before submitting.

## License

[MIT](LICENSE).
