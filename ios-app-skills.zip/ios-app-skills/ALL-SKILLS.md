# skills/ios-project-foundation/SKILL.md

````markdown
---
name: ios-project-foundation
description: >
  Build the shared context files for an iOS project from a short interview. Produces project-brief.md, conventions.md and file-map.md inside Docs/. This is the foundation every other iOS skill reads before writing a single line of Swift. Use this skill at the start of any new iOS or SwiftUI project, or when onboarding Claude onto an existing Xcode project. Trigger whenever the user says "set up my iOS project", "init the project context", "onboard me on this app", "start a new iOS app", "create the project foundation", "nouveau projet iOS", "initialise le projet", "pose les fondations", "configure les conventions", or opens a project folder that has no Docs/project-brief.md. Always produces three files saved into Docs/ at the project root.
---

# iOS Project Foundation

## CRITICAL: Auto-start on load

The moment this skill is loaded, installed, uploaded, or triggered, you MUST immediately run Step 1 below. Your very next message to the user is the interview. Nothing else.

Do NOT:
- Summarise this skill
- Describe what files it creates
- Explain how it works
- Ask if the user wants to run it
- Confirm installation

Do THIS:
- Go straight to Step 1
- Send the interview as your first and only response

## Step 1. Detect existing project

Before asking anything, scan the working directory:

1. Look for `*.xcodeproj`, `*.xcworkspace` or `Package.swift`. Note the project name.
2. Look for `Docs/project-brief.md`, `Docs/conventions.md`, `Docs/file-map.md`.
3. If all three exist, read them and say:

> Foundation already exists. Tell me what to update (brief, conventions or file map), or say "rebuild" to start over.

Then stop and wait.

4. If a Swift project exists but no Docs/ files, note every top-level folder and count `.swift` files. You will need this in Step 4. Then continue to Step 2.
5. If nothing exists, continue to Step 2.

## Step 2. Run the project interview

You MUST call the AskUserQuestion tool. Do not type the questions as chat text. AskUserQuestion supports a maximum of 4 questions per call, so send two calls: Batch 1 first, wait for answers, then Batch 2.

### Batch 1 (your very first action, no text before it)

```json
[
  {
    "question": "What is the app and what does it do in one sentence?",
    "header": "App",
    "multiSelect": false,
    "options": [
      {"label": "Utility", "description": "Solves one clear task (converter, tracker, calculator)"},
      {"label": "Content", "description": "Reads, browses or consumes content (feed, reader, catalogue)"},
      {"label": "Social or community", "description": "Users interact with each other"},
      {"label": "Business tool", "description": "Internal or professional workflow"}
    ]
  },
  {
    "question": "Minimum iOS version and Swift toolchain?",
    "header": "Targets",
    "multiSelect": false,
    "options": [
      {"label": "iOS 17+, Swift 6", "description": "Observation framework, strict concurrency. Recommended."},
      {"label": "iOS 16+, Swift 5.10", "description": "NavigationStack available, ObservableObject required"},
      {"label": "iOS 18+, Swift 6", "description": "Latest APIs only"}
    ]
  },
  {
    "question": "Where does the data live?",
    "header": "Data",
    "multiSelect": true,
    "options": [
      {"label": "Local only", "description": "SwiftData or file storage, no server"},
      {"label": "CloudKit", "description": "Apple sync, no custom backend"},
      {"label": "REST or GraphQL API", "description": "Custom backend over HTTPS"},
      {"label": "Firebase or Supabase", "description": "Third-party BaaS"}
    ]
  },
  {
    "question": "Third-party dependencies policy?",
    "header": "Dependencies",
    "multiSelect": false,
    "options": [
      {"label": "Zero third-party", "description": "Apple frameworks only. Recommended for App Store review speed."},
      {"label": "SPM allowed, minimal", "description": "One or two vetted packages maximum"},
      {"label": "SPM allowed, pragmatic", "description": "Whatever ships faster"}
    ]
  }
]
```

### Batch 2 (send immediately after Batch 1 answers, no commentary between)

```json
[
  {
    "question": "Who is the user and what is their main frustration today?",
    "header": "User",
    "multiSelect": false,
    "options": [
      {"label": "Consumer", "description": "General public, App Store discovery"},
      {"label": "Prosumer", "description": "Power users who pay for quality"},
      {"label": "Internal team", "description": "Enterprise or TestFlight distribution"}
    ]
  },
  {
    "question": "Monetisation?",
    "header": "Business",
    "multiSelect": false,
    "options": [
      {"label": "Free", "description": "No payment logic"},
      {"label": "One-time purchase", "description": "Paid upfront or single IAP"},
      {"label": "Subscription", "description": "StoreKit 2 subscription tiers"},
      {"label": "Undecided", "description": "Design the architecture to allow it later"}
    ]
  },
  {
    "question": "Code style preferences?",
    "header": "Style",
    "multiSelect": true,
    "options": [
      {"label": "Strict access control", "description": "Everything private unless proven otherwise"},
      {"label": "Protocol-first", "description": "Every dependency behind a protocol"},
      {"label": "Async/await only", "description": "No Combine, no completion handlers"},
      {"label": "Localisation from day one", "description": "String Catalog, no hardcoded copy"}
    ]
  }
]
```

After both batches, ask in chat for the app name and bundle identifier if not already detected from an existing `.xcodeproj`. Then move to Step 3.

## Step 3. Write Docs/project-brief.md

Create `Docs/project-brief.md`. Use this exact structure:

```
# Project Brief

## App
[Name, one-sentence purpose, category from question 1]

## Bundle
[Bundle identifier, minimum iOS version, Swift version, Xcode version]

## User
[2 to 3 sentences on who uses this and the frustration it removes]

## Core promise
[One sentence: what the user gets that they cannot get elsewhere]

## Data
[Where data lives, sync strategy, offline expectations]

## Business model
[From question 6, plus what it implies for architecture: StoreKit, entitlements, feature gating]

## Dependency policy
[From question 4, with the allowed list if any]

## Non-goals
[3 things this app will NOT do in version 1]
```

Keep it under 300 words. Every line must be something a later skill would reference when making a decision.

## Step 4. Write Docs/conventions.md

Create `Docs/conventions.md`. This is the single source of truth for naming, layering and style. Every other skill reads it before generating code.

Load `references/conventions-template.md` from this skill folder. Fill every placeholder from the interview answers. Do not leave any `[...]` placeholder in the output. The template already encodes the non-negotiable architecture:

- MVVM for presentation
- Clean Architecture in three layers: Domain, Data, Presentation
- Coordinators for navigation
- Constructor injection through a single `AppContainer`
- One type per file, file name equals type name

If the user chose iOS 16, replace `@Observable` with `ObservableObject` and `@Published` throughout the template and note it in the Observation section.

Keep conventions.md under 600 words. Rules, not prose.

## Step 5. Write Docs/file-map.md

Create `Docs/file-map.md`. This is the anti-duplication registry. Every skill that creates a file MUST append a row here. Every skill that is about to create a file MUST search this table first.

```
# File Map

Registry of every source file in the project. One row per file. Updated by every skill that creates or deletes a file. Search this table before creating anything.

| Path | Type | Layer | Purpose | Created by |
|---|---|---|---|---|
```

If an existing project was detected in Step 1, walk every `.swift` file and add one row per file. Infer Layer from the folder (Domain, Data, Presentation, Core, DesignSystem, App, Tests, Unknown). Infer Purpose from the primary type declaration. Set Created by to `existing`. Flag any file that contains more than one top-level type with `[multi-type]` in the Purpose column.

## Step 6. Confirm and hand off

Tell the user:

> Foundation is in place. Three files are now in Docs/: project-brief.md, conventions.md and file-map.md. Every iOS skill reads these before doing anything. Edit them anytime.
>
> Next steps, in order:
>
> - Say "define the product" to run product-conception and write the feature list
> - Say "design the architecture" to run architecture-designer
> - Say "build feature [name]" to run feature-builder end to end
>
> Each of these is a separate skill. Pick one and go.

## What this skill produces

Three files in `Docs/` at the project root:

1. `project-brief.md`: what the app is, for whom, data strategy, business model, dependency policy
2. `conventions.md`: naming, layering, file rules, style rules, the contract every other skill obeys
3. `file-map.md`: the registry of every source file, the anti-duplication mechanism

## Dependencies

- None. This is the foundation skill.
- `references/conventions-template.md` in this skill folder.

## Rules

- When this skill triggers, go straight to Step 1. No summary, no preamble.
- Always detect an existing project before interviewing. Never overwrite existing Docs/ files without the user saying "rebuild".
- Always put the three files in `Docs/`. Never in the project root, never in the Xcode group, never scattered.
- Never leave a placeholder in conventions.md.
- Never invent a bundle identifier. Ask.
- Keep project-brief.md under 300 words and conventions.md under 600 words.
- Never use em dashes in any output file.
- British English in skill files. Code identifiers and comments in English. User-facing copy in the language the user writes in.
````

# skills/product-conception/SKILL.md

````markdown
---
name: product-conception
description: >
  Turn an app idea into a scoped product definition: user personas, jobs to be done, feature list with priorities, user flows and acceptance criteria. Produces Docs/product.md and one Docs/Features/<name>.md stub per feature. Use this skill whenever the user says "define the product", "scope the app", "what features should this have", "write the product spec", "list the features", "MVP scope", "définis le produit", "cadre les fonctionnalités", "spec produit", "quelles fonctionnalités", or describes an app idea and wants it structured before any architecture or code. Requires ios-project-foundation to have run first.
---

# Product Conception

## Prerequisites check

The moment this skill triggers, check for `Docs/project-brief.md` and `Docs/conventions.md`.

If either is missing, tell the user:

> Product conception builds on the project foundation. Say "set up my iOS project" to run ios-project-foundation first, then come back here.

Then stop.

If both exist, read them fully, then check for `Docs/product.md`. If it exists, read it and go to Step 5 (update mode). Otherwise go straight to Step 1.

## Step 1. Gather the idea

Call AskUserQuestion:

```json
[
  {
    "question": "How much of the product is already decided?",
    "header": "Maturity",
    "multiSelect": false,
    "options": [
      {"label": "Just an idea", "description": "One sentence, help me shape it"},
      {"label": "Rough feature list", "description": "I will paste bullet points"},
      {"label": "Detailed spec", "description": "I will paste a document or notes"},
      {"label": "Existing app", "description": "Reverse-engineer from the codebase"}
    ]
  },
  {
    "question": "Scope target for version 1?",
    "header": "Scope",
    "multiSelect": false,
    "options": [
      {"label": "Tiny MVP", "description": "3 to 5 features, ship in weeks"},
      {"label": "Solid v1", "description": "6 to 10 features"},
      {"label": "Full product", "description": "Everything, phased"}
    ]
  }
]
```

Wait for the paste if applicable. If "Existing app", walk `Features/` and `Domain/UseCases/` and infer the feature list from folder names and use case names.

## Step 2. Define personas and jobs

From the brief and the idea, write:

- 1 to 3 personas. Name, one-line context, primary frustration, success moment.
- For each persona, 2 to 4 jobs to be done in the format: "When [situation], I want to [motivation], so I can [outcome]."

Present them in chat. Call AskUserQuestion to confirm which persona is primary. Do not proceed without confirmation.

## Step 3. Build the feature list

Derive features from the jobs. For each feature produce:

| Field | Rule |
|---|---|
| Name | PascalCase noun, becomes the folder name under `Features/` |
| Job served | Which JTBD it fulfils |
| Priority | P0 (v1 blocker), P1 (v1 nice), P2 (later) |
| Screens | List of screens, each one future View |
| Data touched | Entities read or written |
| Depends on | Other features that must exist first |

Respect the scope from Step 1. Tiny MVP means P0 only, maximum 5 features. Present the table. Call AskUserQuestion:

```json
[
  {
    "question": "Feature list looks right?",
    "header": "Confirm",
    "multiSelect": false,
    "options": [
      {"label": "Approve", "description": "Write the files"},
      {"label": "Cut features", "description": "I will tell you which to remove"},
      {"label": "Add features", "description": "I will tell you what is missing"}
    ]
  }
]
```

Iterate until approved. Maximum 3 rounds.

## Step 4. Write the files

### Docs/product.md

```
# Product

## Personas
[Name: context. Frustration. Success moment.] x1 to 3. Mark the primary one.

## Jobs to be done
[Grouped by persona, "When... I want... so I can..." format]

## Feature list
[The approved table from Step 3, sorted by priority then dependency order]

## User flows
[For each P0 feature: numbered steps from entry point to success state. Max 8 steps each.]

## Out of scope for v1
[Explicit list. Include anything the user mentioned and then cut.]

## Open questions
[Anything unresolved that architecture-designer must decide]
```

### Docs/Features/<Name>.md, one per feature

```
# Feature: <Name>

Status: specified
Priority: <P0|P1|P2>
Depends on: <feature names or none>

## Job
[The JTBD this serves, one line]

## Screens
[One line per screen: ScreenName. What the user sees. What they can do.]

## Acceptance criteria
[Given / When / Then, 3 to 6 criteria]

## Entities
[Entities this feature reads or writes. Names only. domain-modeler owns the definitions.]

## Notes
[Edge cases, platform constraints, anything the implementer must know]
```

Register every created file in `Docs/file-map.md` with Layer `Docs`.

## Step 5. Update mode

If `Docs/product.md` already existed, ask what changed (new feature, cut feature, priority change, new persona). Apply the change to `product.md` and to the affected `Docs/Features/<Name>.md`. Never regenerate untouched features. Bump the Status line of a changed feature to `respecified`.

## Step 6. Hand off

Tell the user:

> Product is defined. Docs/product.md and one spec per feature in Docs/Features/ are written.
>
> Next: say "design the architecture" to run architecture-designer. It reads the feature list and decides modules, data flow and technical choices.

## What this skill produces

1. `Docs/product.md`: personas, jobs, feature table, flows, scope boundaries
2. `Docs/Features/<Name>.md`: one spec stub per feature, consumed by every downstream skill

## Dependencies

- Requires: `Docs/project-brief.md`, `Docs/conventions.md` (ios-project-foundation)
- Feeds: architecture-designer, domain-modeler, feature-builder

## Rules

- Always read project-brief.md before proposing anything. Respect the non-goals listed there.
- Always confirm the primary persona and the feature list before writing files.
- Never write a feature without at least 3 acceptance criteria.
- Never define entity fields here. Names only. domain-modeler owns the shapes.
- Never exceed the scope chosen in Step 1.
- Feature names are PascalCase and become folder names. No spaces, no accents.
- Never use em dashes in any output file.
````

# skills/architecture-designer/SKILL.md

````markdown
---
name: architecture-designer
description: >
  Design the technical architecture of the iOS app: layer boundaries, module map, data flow, navigation topology, dependency graph and every technical decision recorded as an ADR. Produces Docs/architecture.md with text diagrams. Use this skill whenever the user says "design the architecture", "how should I structure this app", "architecture decisions", "which pattern for", "MVVM setup", "clean architecture for this app", "conçois l'architecture", "structure de l'app", "décisions techniques", "quel pattern", or before any code is written on a new project. Requires ios-project-foundation. Reads Docs/product.md if present.
---

# Architecture Designer

## Prerequisites check

Check for `Docs/project-brief.md` and `Docs/conventions.md`. If missing, say:

> Architecture needs the foundation. Say "set up my iOS project" first.

Then stop.

If present, read both. Read `Docs/product.md` and every `Docs/Features/*.md` if they exist. If `Docs/architecture.md` already exists, read it and go to Step 6 (amend mode). Otherwise go straight to Step 1.

## Step 1. Gather constraints

Call AskUserQuestion:

```json
[
  {
    "question": "Modularisation level?",
    "header": "Modules",
    "multiSelect": false,
    "options": [
      {"label": "Single target, folder layers", "description": "One app target, layers enforced by folders and conventions. Fastest to iterate."},
      {"label": "SPM local packages per layer", "description": "Domain, Data, DesignSystem as local packages. Compiler-enforced boundaries."},
      {"label": "SPM packages per feature", "description": "Each feature its own package. For teams of 3+."}
    ]
  },
  {
    "question": "Persistence engine?",
    "header": "Storage",
    "multiSelect": false,
    "options": [
      {"label": "SwiftData", "description": "iOS 17+, @Model, CloudKit ready"},
      {"label": "Core Data", "description": "Broad compatibility"},
      {"label": "Files or UserDefaults", "description": "Small state only"},
      {"label": "None", "description": "Stateless or remote only"}
    ]
  },
  {
    "question": "Navigation complexity?",
    "header": "Navigation",
    "multiSelect": false,
    "options": [
      {"label": "Single stack", "description": "One NavigationStack, linear flows"},
      {"label": "Tabs with stacks", "description": "TabView, one stack per tab"},
      {"label": "Deep links and modals", "description": "Tabs, sheets, full screen covers, URL routing"}
    ]
  }
]
```

If `product.md` is missing, also ask the user to list the 3 to 5 main features in chat.

## Step 2. Draw the layer diagram

Produce the layer diagram in a plain code block. Adapt names to this project. The arrows are the only allowed dependencies.

```
┌─────────────────────────────────────────────────────────────┐
│  App                                                        │
│  <AppName>App.swift  ·  AppContainer (composition root)     │
└───────────────────────────┬─────────────────────────────────┘
                            │ builds
┌───────────────────────────▼─────────────────────────────────┐
│  Presentation (MVVM)                                        │
│  Features/<Name>/  Views → ViewModels → Coordinators        │
│  DesignSystem/     Tokens, Components, Modifiers            │
└───────────────────────────┬─────────────────────────────────┘
                            │ depends on
┌───────────────────────────▼─────────────────────────────────┐
│  Domain (pure Swift)                                        │
│  Entities · ValueObjects · UseCases · Repository protocols  │
└───────────────────────────▲─────────────────────────────────┘
                            │ implements
┌───────────────────────────┴─────────────────────────────────┐
│  Data                                                       │
│  RepositoryImpl · Remote/Local DataSources · DTOs · Mappers │
└─────────────────────────────────────────────────────────────┘
```

## Step 3. Map features to modules

For every feature in `product.md`, produce one block:

```
Feature: <Name>
  Screens:        <ViewA>, <ViewB>
  ViewModels:     <ViewA>ViewModel, <ViewB>ViewModel
  Coordinator:    <Name>Coordinator, routes: [.list, .detail(id), .create]
  Use cases:      Fetch<Noun>sUseCase, Create<Noun>UseCase
  Repositories:   <Noun>Repository (protocol) ← <Noun>RepositoryImpl
  Data sources:   <Noun>RemoteDataSource, <Noun>LocalDataSource
  Entities:       <Noun>
  Cross-feature:  reads <OtherNoun> via <OtherNoun>Repository (never via another feature's ViewModel)
```

Detect shared entities: any entity used by two or more features is flagged `[shared]` and must be owned by exactly one feature folder in Domain. Record the owner.

## Step 4. Draw the navigation and data flow

**Navigation topology** as a text tree:

```
AppCoordinator
├── Tab: <TabName> → <Feature>Coordinator
│   ├── <ListView>
│   └── <DetailView>(id)
├── Tab: ...
└── Modal: <OnboardingCoordinator> (presented once)
```

**One data flow** end to end, for the most important P0 feature:

```
User tap
 → <View>.onTapGesture calls viewModel.load()
 → <ViewModel>.load() calls fetchUseCase.execute()
 → Default<Fetch>UseCase calls repository.fetchAll()
 → <RepositoryImpl> calls remoteDataSource.fetch() then localDataSource.save()
 → <Mapper>.toDomain(dto) returns [<Entity>]
 → ViewModel sets state = .loaded(items)
 → View re-renders
```

## Step 5. Record decisions and write Docs/architecture.md

Every choice is an ADR. Minimum set: modularisation, persistence, networking, navigation, DI, concurrency, error handling, localisation, testing strategy. Format:

```
### ADR-<n>: <Title>
Status: accepted
Context: [one or two sentences]
Decision: [one sentence]
Consequences: [what this forces, what it forbids]
```

Write `Docs/architecture.md`:

```
# Architecture

## Overview
[3 sentences: pattern, layers, modularisation level]

## Layer diagram
[Step 2 block]

## Feature map
[Step 3 blocks]

## Navigation topology
[Step 4 tree]

## Reference data flow
[Step 4 flow]

## Dependency graph
[Text list: which concrete type is injected where. AppContainer builds X with Y and Z.]

## Decisions
[All ADRs]

## Forbidden
[Explicit list: Views importing Data, Domain importing SwiftUI, ViewModels calling other ViewModels, singletons outside AppContainer, and anything project-specific]
```

Register the file in `Docs/file-map.md`. Update the Architecture section of `Docs/conventions.md` only if a decision changed something there (for example ObservableObject mode). Never rewrite conventions.md wholesale.

## Step 6. Amend mode

If `architecture.md` existed, ask what changed. Add a new ADR with Status `accepted` and mark the superseded ADR as `superseded by ADR-<n>`. Never delete an ADR. Update only the affected diagram sections.

## Step 7. Hand off

Tell the user:

> Architecture is written in Docs/architecture.md with [n] decisions recorded.
>
> Next: say "generate the file structure" to run file-structure-organizer, which turns this into real folders and stub files. Or say "build feature [name]" to run feature-builder.

## What this skill produces

1. `Docs/architecture.md`: diagrams, feature map, navigation, data flow, ADRs, forbidden list

## Dependencies

- Requires: `Docs/project-brief.md`, `Docs/conventions.md`
- Reads if present: `Docs/product.md`, `Docs/Features/*.md`
- Feeds: file-structure-organizer, domain-modeler, coordinator-navigator, dependency-injector

## Rules

- Always produce diagrams in plain code blocks. Never as images.
- Always record every choice as an ADR. A decision not written down does not exist.
- Never introduce a fourth layer. Domain, Data, Presentation, plus App and Core as infrastructure.
- Never let a feature depend on another feature's Presentation. Cross-feature access goes through Domain.
- Never contradict conventions.md. If a decision requires changing it, say so explicitly and edit only that section.
- Never propose a third-party package if the dependency policy in project-brief.md is "zero".
- Never use em dashes in any output file.
````

# skills/file-structure-organizer/SKILL.md

````markdown
---
name: file-structure-organizer
description: >
  Generate the complete folder tree and stub files of the iOS project from Docs/architecture.md, and register every file in Docs/file-map.md. Also audits an existing project and moves misplaced files to their correct layer. Use this skill whenever the user says "generate the file structure", "create the folders", "scaffold the project", "organise my files", "where should this file go", "clean up the project tree", "audit the structure", "génère l'arborescence", "crée les dossiers", "range les fichiers", "où mettre ce fichier", "nettoie l'arbo". Requires ios-project-foundation and architecture-designer.
---

# File Structure Organiser

## Prerequisites check

Check for `Docs/conventions.md` and `Docs/architecture.md`. If either is missing, say:

> The tree is generated from the architecture. Run ios-project-foundation then architecture-designer first.

Then stop. If both exist, read them fully plus `Docs/file-map.md`. Go straight to Step 1.

## Step 1. Choose mode

Call AskUserQuestion:

```json
[
  {
    "question": "What do you need?",
    "header": "Mode",
    "multiSelect": false,
    "options": [
      {"label": "Scaffold from scratch", "description": "Create every folder and stub file from architecture.md"},
      {"label": "Scaffold one feature", "description": "Create only Features/<Name> and its Domain and Data folders"},
      {"label": "Audit existing tree", "description": "Find misplaced files and propose moves"},
      {"label": "Place one file", "description": "Tell me where a given type belongs"}
    ]
  }
]
```

## Step 2. Build the target tree

Derive the tree from the Folder layout section of `conventions.md` and the Feature map of `architecture.md`. One folder per feature under `Features/`, and matching feature subfolders under `Domain/UseCases/`, `Domain/Entities/`, `Domain/Repositories/`, `Data/Repositories/`, `Data/DataSources/`, `Data/DTOs/`, `Data/Mappers/`.

Print the full tree in a plain code block before creating anything:

```
<AppName>/
├── App/
│   ├── <AppName>App.swift
│   └── Resources/
│       ├── Assets.xcassets/
│       └── Localizable.xcstrings
├── Core/
│   ├── DI/
│   │   ├── AppContainer.swift
│   │   └── AppContainer+<Feature>.swift
│   ├── Navigation/
│   │   ├── AppCoordinator.swift
│   │   └── AppRoute.swift
│   ├── Extensions/
│   └── Utilities/
├── DesignSystem/
│   ├── Tokens/
│   ├── Components/
│   └── Modifiers/
├── Domain/
│   ├── Entities/<Feature>/
│   ├── ValueObjects/
│   ├── Repositories/<Feature>/
│   ├── UseCases/<Feature>/
│   └── Errors/
├── Data/
│   ├── Repositories/<Feature>/
│   ├── DataSources/Remote/<Feature>/
│   ├── DataSources/Local/<Feature>/
│   ├── DTOs/<Feature>/
│   └── Mappers/<Feature>/
├── Features/
│   └── <Feature>/
│       ├── Presentation/
│       │   ├── Views/
│       │   ├── ViewModels/
│       │   └── Components/
│       └── Coordinator/
├── Tests/
│   ├── UnitTests/
│   │   ├── Domain/<Feature>/
│   │   ├── Data/<Feature>/
│   │   ├── Presentation/<Feature>/
│   │   └── Mocks/
│   └── UITests/
└── Docs/
```

Call AskUserQuestion to approve the tree. Do not create anything before approval.

## Step 3. Create folders and stubs

For every folder: create it. Add a `.gitkeep` only in folders that would otherwise be empty.

For every file named in the Feature map of `architecture.md`: create a stub with the correct type declaration, a one-line doc comment stating its layer and purpose, and nothing else. Stub template:

```swift
// <FileName>.swift
// Layer: <Domain|Data|Presentation|Core|App>
// Purpose: <one line from architecture.md>

import Foundation

<protocol|struct|final class|enum> <TypeName> {
}
```

Stubs never contain logic. Downstream skills fill them. A stub must compile.

Do not create stubs for files that already exist in `file-map.md`. If a file exists at the wrong path, go to Step 5 instead of creating a duplicate.

## Step 4. Register everything

Append one row per created file to `Docs/file-map.md`:

```
| Features/Invoices/Presentation/ViewModels/InvoiceListViewModel.swift | class | Presentation | Screen state and actions for invoice list | file-structure-organizer |
```

Sort the table by Path after appending.

## Step 5. Audit mode

Walk every `.swift` file. For each, check:

1. Path matches the layer implied by the type name suffix (`ViewModel` in `Features/*/Presentation/ViewModels/`, `RepositoryImpl` in `Data/Repositories/`, and so on per the Naming table in conventions.md)
2. File name equals the primary type name
3. Exactly one top-level type per file
4. No forbidden import for its layer (`import SwiftUI` in Domain, `import Data` in Presentation)
5. File is present in `file-map.md`

Output a table of violations:

```
| File | Violation | Proposed fix |
|---|---|---|
```

Call AskUserQuestion to approve moves. Apply approved moves with `git mv` when in a git repo, plain move otherwise. Update the Xcode project only if using folder-synchronised groups (Xcode 16+). Otherwise tell the user which groups to re-link. Update `file-map.md` for every move.

## Step 6. Place one file mode

Ask for the type name and its responsibility in one line. Answer with the exact path, the reason (which rule in conventions.md), and whether a file with that name already exists in `file-map.md`. If it exists, say so and stop. Never create a second file with the same type name.

## Step 7. Hand off

Tell the user:

> Tree is in place with [n] folders and [n] stub files, all registered in Docs/file-map.md.
>
> Next: say "model the domain" to run domain-modeler, or "build feature [name]" to run feature-builder.

## What this skill produces

1. The complete folder tree under the project root
2. Compilable stub files, one type each
3. Updated `Docs/file-map.md`

## Dependencies

- Requires: `Docs/conventions.md`, `Docs/architecture.md`, `Docs/file-map.md`
- Feeds: every code-generating skill

## Rules

- Always print the tree and get approval before creating anything.
- Always check file-map.md before creating a file. A type name that already exists is never created again.
- Never put logic in a stub.
- Never create catch-all files (Utils, Helpers, Extensions, Constants).
- Never create a folder that conventions.md does not define. Propose a conventions change instead.
- Never move a file without approval.
- Never use em dashes in any output file.
````

# skills/domain-modeler/SKILL.md

````markdown
---
name: domain-modeler
description: >
  Model the Domain layer: entities, value objects, invariants, typed errors and repository protocols, as pure Swift with no framework imports. Produces Docs/domain-model.md plus one file per type under Domain/. Use this skill whenever the user says "model the domain", "define the entities", "what are the models", "create the data model", "domain layer", "value objects", "repository protocol", "modélise le domaine", "définis les entités", "crée les modèles", "couche domaine", or when any skill needs an entity that does not exist yet. Requires ios-project-foundation. Reads Docs/Features/*.md and Docs/architecture.md.
---

# Domain Modeler

## Prerequisites check

Check for `Docs/conventions.md` and `Docs/file-map.md`. If missing, say:

> Domain modelling needs the foundation. Say "set up my iOS project" first.

Then stop. If present, read both, then read `Docs/architecture.md`, every `Docs/Features/*.md` and `Docs/domain-model.md` if they exist. Go straight to Step 1.

## Step 1. Scope the modelling

Call AskUserQuestion:

```json
[
  {
    "question": "What should I model?",
    "header": "Scope",
    "multiSelect": false,
    "options": [
      {"label": "Whole product", "description": "Every entity named across Docs/Features/*.md"},
      {"label": "One feature", "description": "Only the entities of one feature spec"},
      {"label": "One entity", "description": "I will describe it in chat"}
    ]
  }
]
```

Collect the entity names from the chosen scope. Before designing anything, search `Docs/file-map.md` and `Domain/Entities/` for each name. Split the list into `existing` and `new`. Existing entities are read, never regenerated. Only extend them if a feature spec needs a field they lack, and say so.

## Step 2. Design each entity

For every new entity, decide and write in chat:

| Aspect | Rule |
|---|---|
| Kind | `struct` by default. `final class` only with a written reason (identity semantics, reference sharing). |
| Identity | `let id: <Entity>ID` where `<Entity>ID` is a typed wrapper around UUID or String. Never bare `UUID` as a field type. |
| Fields | Named, typed, minimal. No optional unless absence is a real state. |
| Value objects | Any field with validation rules (email, money, percentage, phone) becomes a value object with a failable or throwing initialiser. |
| Invariants | Rules that must always hold. Enforced in the initialiser or a mutating method. Listed explicitly. |
| Conformances | `Equatable`, `Hashable`, `Sendable`, `Identifiable`. `Codable` only if the entity itself crosses a boundary, otherwise DTOs handle it. |
| Relationships | By ID reference, never by embedding another entity unless composition is intrinsic. |

Flag shared entities (used by two or more features) and assign one owning feature folder.

## Step 3. Design errors and repository protocols

For each feature in scope, one `<Noun>Error` enum in `Domain/Errors/`:

```swift
enum InvoiceError: Error, Equatable, Sendable {
    case notFound(InvoiceID)
    case invalidAmount
    case alreadyPaid
    case storage(underlying: String)
}
```

For each aggregate root, one repository protocol in `Domain/Repositories/<Feature>/`:

```swift
protocol InvoiceRepository: Sendable {
    func fetchAll() async throws(InvoiceError) -> [Invoice]
    func fetch(id: InvoiceID) async throws(InvoiceError) -> Invoice
    func save(_ invoice: Invoice) async throws(InvoiceError)
    func delete(id: InvoiceID) async throws(InvoiceError)
}
```

Use typed throws when Swift 6 is set in conventions.md. Otherwise plain `throws` with the error documented.

Present all entities, value objects, errors and protocols in chat as Swift. Call AskUserQuestion to approve. Iterate, maximum 3 rounds.

## Step 4. Write the files

One file per type, at the path dictated by conventions.md:

- `Domain/Entities/<Feature>/<Entity>.swift`
- `Domain/Entities/<Feature>/<Entity>ID.swift`
- `Domain/ValueObjects/<ValueObject>.swift`
- `Domain/Errors/<Noun>Error.swift`
- `Domain/Repositories/<Feature>/<Noun>Repository.swift`

File header on every file:

```swift
// <Name>.swift
// Layer: Domain
// Purpose: <one line>
```

Only `import Foundation`. Nothing else. Every file must compile alone.

Register each file in `Docs/file-map.md`. If a stub already existed from file-structure-organizer, fill it in place. Never create a sibling.

## Step 5. Write Docs/domain-model.md

```
# Domain Model

## Entities
[One block per entity: name, owning feature, fields with types, invariants, relationships by ID]

## Value objects
[Name, wrapped type, validation rule, example valid and invalid values]

## Errors
[One enum per feature, every case with the situation that raises it]

## Repositories
[One protocol per aggregate, method signatures, which error each can throw]

## Glossary
[Ubiquitous language: every domain word, one definition. Used by every skill to name things identically.]
```

If the file existed, merge: add new sections, update changed ones, never drop existing entries.

## Step 6. Hand off

Tell the user:

> Domain is modelled: [n] entities, [n] value objects, [n] error types, [n] repository protocols. Docs/domain-model.md is the reference.
>
> Next: say "generate the use cases" to run use-case-generator, or "write the business rules" for business-logic-engine.

## What this skill produces

1. Pure Swift files under `Domain/`, one type each
2. `Docs/domain-model.md` with the glossary every other skill uses

## Dependencies

- Requires: `Docs/conventions.md`, `Docs/file-map.md`
- Reads if present: `Docs/architecture.md`, `Docs/Features/*.md`, `Docs/domain-model.md`
- Feeds: use-case-generator, business-logic-engine, data-layer-generator, viewmodel-generator, test-generator

## Rules

- Always search file-map.md and Domain/ before designing an entity. Existing entities are extended, never duplicated.
- Always use typed IDs. Never `UUID` or `String` as an identity field type.
- Never import SwiftUI, UIKit, SwiftData, CoreData, Combine or any networking framework in Domain.
- Never put formatting, persistence or networking concerns in an entity.
- Never make a repository protocol expose DTOs. Domain types only.
- Every value object has at least one documented invalid input.
- Every glossary term is used verbatim by downstream skills. No synonyms.
- Never use em dashes in any output file.
````

# skills/business-logic-engine/SKILL.md

````markdown
---
name: business-logic-engine
description: >
  Extract and implement business rules as pure, testable domain services and entity methods. Turns acceptance criteria and product rules into Swift logic that lives in Domain, never in ViewModels or Views. Produces Domain/Services/ files and a rules table in Docs/domain-model.md. Use this skill whenever the user says "write the business rules", "implement the logic for", "validation rules", "calculation logic", "domain service", "the rule is", "règles métier", "logique métier", "implémente la règle", "calcul de", "validation de", or when a use case needs a rule that spans several entities. Requires domain-modeler.
---

# Business Logic Engine

## Prerequisites check

Check for `Docs/conventions.md` and `Docs/domain-model.md`. If either is missing, say:

> Business rules attach to entities. Run domain-modeler first ("model the domain").

Then stop. If present, read both, plus `Docs/Features/*.md` and `Docs/file-map.md`. Go straight to Step 1.

## Step 1. Collect the rules

Call AskUserQuestion:

```json
[
  {
    "question": "Where do the rules come from?",
    "header": "Source",
    "multiSelect": false,
    "options": [
      {"label": "Feature specs", "description": "Extract from acceptance criteria in Docs/Features/*.md"},
      {"label": "I will describe them", "description": "I will type the rules in chat"},
      {"label": "Existing code", "description": "Find rules currently buried in ViewModels or Views and move them"}
    ]
  }
]
```

If "Existing code": grep `Features/` for `if`, `guard`, `switch`, arithmetic and `Date` logic inside ViewModels and Views. List every candidate rule with its file and line. These are extraction targets.

## Step 2. Write the rules table

Every rule gets an ID and a home before any code:

```
| ID | Rule (plain language) | Inputs | Output | Home | Feature |
|---|---|---|---|---|---|
| R-01 | An invoice cannot be paid twice | Invoice.status | InvoiceError.alreadyPaid | Invoice.markPaid() | Invoices |
| R-02 | Total = sum(lines) + VAT, rounded to 2 decimals | [InvoiceLine], VATRate | Money | InvoiceTotalCalculator | Invoices |
```

Home decision:
- Rule touches one entity's own state: entity method (mutating or computed)
- Rule touches several entities or needs a policy: domain service in `Domain/Services/<Feature>/<Name>.swift`
- Rule is a pure calculation: `struct <Name>Calculator` with a single `calculate` method, stateless

Call AskUserQuestion to approve the table. Iterate, maximum 3 rounds.

## Step 3. Implement

Entity methods are added to the existing entity file, or to `<Entity>+Rules.swift` next to it if the entity file would exceed 150 lines.

Domain services:

```swift
// InvoiceTotalCalculator.swift
// Layer: Domain
// Purpose: R-02 invoice total with VAT

import Foundation

struct InvoiceTotalCalculator: Sendable {
    func calculate(lines: [InvoiceLine], vatRate: VATRate) -> Money {
        let subtotal = lines.reduce(Money.zero) { $0 + $1.amount }
        return subtotal.applying(vatRate).rounded(scale: 2)
    }
}
```

Every rule implementation carries its rule ID in the Purpose line. No rule without an ID. No ID without a test (test-generator reads this table).

If a rule needs data the entity does not have, stop and say which field is missing. Do not add fields silently. Send the user to domain-modeler.

## Step 4. Remove extracted duplicates

If Step 1 found rules in ViewModels or Views: after the domain implementation exists, replace the original code with a call to the domain method. Show every replacement as before and after in chat before applying. Never leave the old logic in place.

## Step 5. Update Docs/domain-model.md

Add or update a `## Business rules` section with the approved table. Register new files in `Docs/file-map.md`.

## Step 6. Hand off

Tell the user:

> [n] rules implemented in Domain, all traceable by ID. Say "generate the use cases" to wire them, or "generate tests" to cover every rule.

## What this skill produces

1. Entity methods and domain services under `Domain/`
2. `## Business rules` table in `Docs/domain-model.md`

## Dependencies

- Requires: `Docs/domain-model.md` (domain-modeler), `Docs/conventions.md`
- Feeds: use-case-generator, test-generator, code-deduplicator

## Rules

- Always give every rule an ID before implementing it.
- Always keep rules in Domain. Never in a ViewModel, never in a View, never in Data.
- Never add a field to an entity here. Redirect to domain-modeler.
- Never import anything but Foundation.
- Domain services are stateless structs. If it needs state, it is an entity.
- Never leave extracted logic duplicated at its original site.
- Never use em dashes in any output file.
````

# skills/use-case-generator/SKILL.md

````markdown
---
name: use-case-generator
description: >
  Generate use cases (interactors) for the Domain layer: one protocol plus one default implementation per user action, orchestrating repositories and business rules. Produces Domain/UseCases/<Feature>/ files. Use this skill whenever the user says "generate the use cases", "create a use case for", "interactor", "application logic for", "wire the domain", "génère les use cases", "crée un use case", "cas d'utilisation", or when viewmodel-generator needs an action that has no use case yet. Requires domain-modeler.
---

# Use Case Generator

## Prerequisites check

Check for `Docs/conventions.md` and `Docs/domain-model.md`. If missing, say:

> Use cases orchestrate entities and repositories. Run domain-modeler first.

Then stop. If present, read both plus `Docs/Features/*.md`, `Docs/file-map.md`, and the `## Business rules` table if it exists. Go straight to Step 1.

## Step 1. Scope

Call AskUserQuestion:

```json
[
  {
    "question": "Which use cases?",
    "header": "Scope",
    "multiSelect": false,
    "options": [
      {"label": "All for one feature", "description": "Derive from the feature spec's screens and acceptance criteria"},
      {"label": "One use case", "description": "I will name the action"},
      {"label": "Whole product", "description": "Every feature in Docs/Features/"}
    ]
  }
]
```

## Step 2. Derive the use case list

From the acceptance criteria and screens, list every user-initiated or system-initiated action. Naming per conventions.md: `<Verb><Noun>UseCase`. Allowed verbs: Fetch, Create, Update, Delete, Search, Sync, Validate, Submit, Toggle, Export, Import. Propose a new verb only with a reason.

Before listing, search `Docs/file-map.md` and `Domain/UseCases/` for each name. Mark existing ones. Existing use cases are never regenerated.

Present:

```
| Use case | Input | Output | Repositories | Rules applied | Error |
|---|---|---|---|---|---|
| FetchInvoicesUseCase | none | [Invoice] | InvoiceRepository | none | InvoiceError |
| CreateInvoiceUseCase | CreateInvoiceInput | Invoice | InvoiceRepository, ClientRepository | R-02 | InvoiceError |
```

Call AskUserQuestion to approve. Maximum 3 rounds.

## Step 3. Generate

One protocol and one implementation per use case. Two files.

`Domain/UseCases/<Feature>/<Verb><Noun>UseCase.swift`:

```swift
// CreateInvoiceUseCase.swift
// Layer: Domain
// Purpose: Create an invoice for a client applying R-02

import Foundation

protocol CreateInvoiceUseCase: Sendable {
    func execute(_ input: CreateInvoiceInput) async throws(InvoiceError) -> Invoice
}

struct CreateInvoiceInput: Sendable, Equatable {
    let clientID: ClientID
    let lines: [InvoiceLine]
    let vatRate: VATRate
}
```

`Domain/UseCases/<Feature>/Default<Verb><Noun>UseCase.swift`:

```swift
// DefaultCreateInvoiceUseCase.swift
// Layer: Domain
// Purpose: Default implementation of CreateInvoiceUseCase

import Foundation

struct DefaultCreateInvoiceUseCase: CreateInvoiceUseCase {
    private let invoices: InvoiceRepository
    private let clients: ClientRepository
    private let calculator: InvoiceTotalCalculator

    init(invoices: InvoiceRepository, clients: ClientRepository, calculator: InvoiceTotalCalculator) {
        self.invoices = invoices
        self.clients = clients
        self.calculator = calculator
    }

    func execute(_ input: CreateInvoiceInput) async throws(InvoiceError) -> Invoice {
        _ = try await clients.fetch(id: input.clientID).mapError(InvoiceError.init)
        let total = calculator.calculate(lines: input.lines, vatRate: input.vatRate)
        let invoice = Invoice(id: InvoiceID(), clientID: input.clientID, lines: input.lines, total: total, status: .draft)
        try await invoices.save(invoice)
        return invoice
    }
}
```

Rules for the body:
- One `execute` method. Exactly one.
- All dependencies are protocols, injected via `init`.
- Input is a dedicated `<Verb><Noun>Input` struct when more than one parameter. Defined in the protocol file.
- No formatting, no UI state, no logging framework.
- Cross-feature reads go through the other feature's repository protocol, never its use case, unless composition is explicit in architecture.md.

If a use case needs a rule not in the rules table, stop and redirect to business-logic-engine. If it needs a repository method that does not exist, stop and redirect to domain-modeler.

## Step 4. Register

Append every file to `Docs/file-map.md`. Add a `## Use cases` section to `Docs/domain-model.md` with the approved table if not present, or merge rows.

## Step 5. Hand off

Tell the user:

> [n] use cases generated under Domain/UseCases/. Say "generate the data layer" to implement the repositories, or "generate the viewmodel for [screen]" to consume them.

## What this skill produces

1. `Domain/UseCases/<Feature>/<Name>UseCase.swift` (protocol and input)
2. `Domain/UseCases/<Feature>/Default<Name>UseCase.swift` (implementation)
3. `## Use cases` table in `Docs/domain-model.md`

## Dependencies

- Requires: `Docs/domain-model.md`, `Docs/conventions.md`
- Feeds: viewmodel-generator, dependency-injector, test-generator

## Rules

- Always search file-map.md before naming a use case.
- Always one protocol plus one default implementation. Never a concrete class alone.
- Never put UI concerns, formatting, or navigation in a use case.
- Never instantiate a repository inside a use case.
- Never let a use case call a ViewModel or a coordinator.
- Never use em dashes in any output file.
````

# skills/data-layer-generator/SKILL.md

````markdown
---
name: data-layer-generator
description: >
  Implement the Data layer for a feature: repository implementations, remote and local data sources, DTOs and mappers, honouring the repository protocols in Domain. Produces Data/ files. Use this skill whenever the user says "generate the data layer", "implement the repository", "API client for", "persistence for", "SwiftData model for", "CloudKit for", "mapper", "DTO", "génère la couche data", "implémente le repository", "client API", "persistance", or when dependency-injector finds a repository protocol with no implementation. Requires domain-modeler and architecture-designer.
---

# Data Layer Generator

## Prerequisites check

Check for `Docs/conventions.md`, `Docs/domain-model.md` and `Docs/architecture.md`. If any is missing, say:

> The data layer implements Domain protocols under the persistence decisions in architecture.md. Run domain-modeler and architecture-designer first.

Then stop. If present, read all three plus `Docs/file-map.md`. Go straight to Step 1.

## Step 1. Scope and sources

Call AskUserQuestion:

```json
[
  {
    "question": "Which repository?",
    "header": "Scope",
    "multiSelect": false,
    "options": [
      {"label": "All for one feature", "description": "Every repository protocol of the feature"},
      {"label": "One repository", "description": "I will name it"},
      {"label": "Whole product", "description": "Every protocol without an implementation"}
    ]
  },
  {
    "question": "Data sources for this scope?",
    "header": "Sources",
    "multiSelect": true,
    "options": [
      {"label": "Remote", "description": "REST/GraphQL per architecture.md networking ADR"},
      {"label": "Local", "description": "SwiftData/CoreData/files per persistence ADR"},
      {"label": "Remote with local cache", "description": "Both, remote is source of truth"},
      {"label": "In-memory", "description": "For prototypes and previews"}
    ]
  }
]
```

If Remote is chosen and no API contract is in the project (`Docs/api.md` or an OpenAPI file), ask the user to paste the endpoints and one sample JSON per endpoint. Do not invent field names.

Search `Docs/file-map.md` and `Data/` for every target type name. Existing implementations are never regenerated.

## Step 2. Design per repository

For each repository protocol, present in chat:

```
InvoiceRepository
  Impl:        InvoiceRepositoryImpl
  Remote:      InvoiceRemoteDataSource (protocol) ← URLSessionInvoiceRemoteDataSource
  Local:       InvoiceLocalDataSource (protocol) ← SwiftDataInvoiceLocalDataSource
  DTOs:        InvoiceDTO (Codable), InvoiceLineDTO
  Model:       InvoiceModel (@Model, SwiftData) if local
  Mapper:      InvoiceMapper (DTO ↔ Invoice, Model ↔ Invoice)
  Strategy:    remote first, write-through cache, local on offline
  Error map:   URLError → InvoiceError.network, DecodingError → InvoiceError.corruptData
```

Call AskUserQuestion to approve. Maximum 3 rounds.

## Step 3. Generate

Files, one type each, under the paths from conventions.md:

- `Data/DTOs/<Feature>/<Noun>DTO.swift`: `Codable`, `Sendable`, field names match the API exactly, `CodingKeys` when they differ from Swift style
- `Data/DataSources/Remote/<Feature>/<Noun>RemoteDataSource.swift`: protocol
- `Data/DataSources/Remote/<Feature>/URLSession<Noun>RemoteDataSource.swift`: implementation using the shared `HTTPClient` from `Core/Networking/` (create it once if absent, register it)
- `Data/DataSources/Local/<Feature>/<Noun>LocalDataSource.swift`: protocol
- `Data/DataSources/Local/<Feature>/<Engine><Noun>LocalDataSource.swift`: implementation
- `Data/DataSources/Local/<Feature>/<Noun>Model.swift`: `@Model` class if SwiftData
- `Data/Mappers/<Feature>/<Noun>Mapper.swift`: static pure functions `toDomain` and `toDTO` / `toModel`
- `Data/Repositories/<Feature>/<Noun>RepositoryImpl.swift`

Repository implementation shape:

```swift
// InvoiceRepositoryImpl.swift
// Layer: Data
// Purpose: InvoiceRepository over remote API with local cache

import Foundation

final class InvoiceRepositoryImpl: InvoiceRepository {
    private let remote: InvoiceRemoteDataSource
    private let local: InvoiceLocalDataSource
    private let mapper: InvoiceMapper

    init(remote: InvoiceRemoteDataSource, local: InvoiceLocalDataSource, mapper: InvoiceMapper = InvoiceMapper()) {
        self.remote = remote
        self.local = local
        self.mapper = mapper
    }

    func fetchAll() async throws(InvoiceError) -> [Invoice] {
        do {
            let dtos = try await remote.fetchAll()
            let invoices = dtos.map(mapper.toDomain)
            try await local.replaceAll(invoices.map(mapper.toModel))
            return invoices
        } catch let error as URLError where error.code == .notConnectedToInternet {
            return try await local.fetchAll().map(mapper.toDomain)
        } catch {
            throw InvoiceError.storage(underlying: String(describing: error))
        }
    }
}
```

Rules for bodies:
- Every external error is mapped to the feature's domain error. Nothing else crosses the boundary.
- Mappers are pure. No async, no side effects, tested by test-generator.
- No business rule in Data. If a rule is needed, redirect to business-logic-engine.
- SwiftData `@Model` classes never leave Data. Domain sees entities only.

## Step 4. Register and document

Append every file to `Docs/file-map.md`. Add a `## Data strategy` section per feature to `Docs/architecture.md` with the Step 2 block.

## Step 5. Hand off

Tell the user:

> Data layer for [scope] is implemented and mapped to domain errors. Say "wire the dependencies" to register everything in AppContainer, or "generate tests" for mapper and repository tests.

## What this skill produces

1. DTOs, data sources, models, mappers and repository implementations under `Data/`
2. `## Data strategy` blocks in `Docs/architecture.md`

## Dependencies

- Requires: `Docs/domain-model.md`, `Docs/architecture.md`, `Docs/conventions.md`
- Feeds: dependency-injector, test-generator

## Rules

- Always honour the exact repository protocol signature. Never change a Domain protocol from here.
- Always map external errors to the domain error enum.
- Never expose a DTO or @Model outside Data.
- Never invent API field names. Ask for a sample payload.
- Never put caching policy in a use case. It belongs in the repository implementation.
- Never use em dashes in any output file.
````

# skills/viewmodel-generator/SKILL.md

````markdown
---
name: viewmodel-generator
description: >
  Generate MVVM ViewModels for SwiftUI screens: observable state, explicit actions, use case orchestration, error to user-message mapping and navigation intents sent to a coordinator. Produces Features/<Name>/Presentation/ViewModels/ files. Use this skill whenever the user says "generate the viewmodel", "viewmodel for [screen]", "screen state", "MVVM for this view", "génère le viewmodel", "état de l'écran", "logique de présentation", or when view-generator needs a ViewModel that does not exist. Requires use-case-generator output for the actions the screen needs.
---

# ViewModel Generator

## Prerequisites check

Check for `Docs/conventions.md` and `Docs/domain-model.md`. If missing, say:

> ViewModels consume use cases. Run domain-modeler and use-case-generator first.

Then stop. If present, read both plus `Docs/Features/<Feature>.md`, `Docs/architecture.md`, `Docs/file-map.md`. Note the Observation mode in conventions.md (`@Observable` or `ObservableObject`). Go straight to Step 1.

## Step 1. Identify the screen

Call AskUserQuestion:

```json
[
  {
    "question": "Which screen?",
    "header": "Screen",
    "multiSelect": false,
    "options": [
      {"label": "Pick from feature spec", "description": "I will choose from the Screens list in Docs/Features/"},
      {"label": "Describe a new screen", "description": "Not yet in a spec, I will describe it"},
      {"label": "All screens of a feature", "description": "Generate every ViewModel of one feature"}
    ]
  }
]
```

For each target screen, search `Docs/file-map.md` for `<Screen>ViewModel`. If it exists, read it and switch to extend mode: only add missing state or actions, never rewrite.

## Step 2. Design the state and actions

Present in chat before writing:

```
InvoiceListViewModel
  State:
    phase: Phase (.idle | .loading | .loaded([InvoiceRowItem]) | .empty | .failed(message: String))
    searchQuery: String
    isRefreshing: Bool
  Derived:
    filteredItems: [InvoiceRowItem]   (computed, no stored duplicate)
  Actions:
    load()          → FetchInvoicesUseCase
    refresh()       → FetchInvoicesUseCase
    delete(id:)     → DeleteInvoiceUseCase
    select(id:)     → coordinator.navigate(.detail(id))   [navigation intent]
    tapCreate()     → coordinator.navigate(.create)       [navigation intent]
  Presentation models:
    InvoiceRowItem (id, title, amountText, statusBadge)  built from Invoice in Presentation, not in Domain
  Error mapping:
    InvoiceError.notFound → "This invoice no longer exists."
    InvoiceError.storage  → "Could not load invoices. Pull to retry."
```

Rules for the design:
- State is a single `Phase` enum for the main content plus flat properties for controls. Never several booleans that can contradict (`isLoading` and `hasError` both true).
- Every use case the screen needs must exist. If one is missing, stop and redirect to use-case-generator.
- Navigation is an intent sent to a coordinator protocol. The ViewModel never knows the destination View.
- Presentation models (row items, formatted strings) are structs in `Features/<Name>/Presentation/ViewModels/<Screen>+Models.swift` or a dedicated file if reused across screens of the feature.

Call AskUserQuestion to approve. Maximum 3 rounds.

## Step 3. Generate

`@Observable` mode (iOS 17+):

```swift
// InvoiceListViewModel.swift
// Layer: Presentation
// Purpose: State and actions for the invoice list screen

import Foundation
import Observation

@MainActor
@Observable
final class InvoiceListViewModel {
    enum Phase: Equatable {
        case idle, loading, empty
        case loaded([InvoiceRowItem])
        case failed(message: String)
    }

    private(set) var phase: Phase = .idle
    var searchQuery = ""
    private(set) var isRefreshing = false

    var filteredItems: [InvoiceRowItem] {
        guard case .loaded(let items) = phase else { return [] }
        guard !searchQuery.isEmpty else { return items }
        return items.filter { $0.title.localizedCaseInsensitiveContains(searchQuery) }
    }

    private let fetchInvoices: FetchInvoicesUseCase
    private let deleteInvoice: DeleteInvoiceUseCase
    private weak var coordinator: (any InvoicesNavigating)?

    init(fetchInvoices: FetchInvoicesUseCase, deleteInvoice: DeleteInvoiceUseCase, coordinator: any InvoicesNavigating) {
        self.fetchInvoices = fetchInvoices
        self.deleteInvoice = deleteInvoice
        self.coordinator = coordinator
    }

    func load() async {
        phase = .loading
        await fetch()
    }

    func refresh() async {
        isRefreshing = true
        defer { isRefreshing = false }
        await fetch()
    }

    func delete(id: InvoiceID) async {
        do {
            try await deleteInvoice.execute(id)
            await fetch()
        } catch {
            phase = .failed(message: Self.message(for: error))
        }
    }

    func select(id: InvoiceID) {
        coordinator?.navigate(to: .detail(id))
    }

    func tapCreate() {
        coordinator?.navigate(to: .create)
    }

    private func fetch() async {
        do {
            let invoices = try await fetchInvoices.execute()
            phase = invoices.isEmpty ? .empty : .loaded(invoices.map(InvoiceRowItem.init))
        } catch {
            phase = .failed(message: Self.message(for: error))
        }
    }

    private static func message(for error: InvoiceError) -> String {
        switch error {
        case .notFound: String(localized: "invoice.error.notFound")
        case .storage: String(localized: "invoice.error.storage")
        default: String(localized: "error.generic")
        }
    }
}
```

`ObservableObject` mode (iOS 16): same structure with `final class X: ObservableObject`, `@Published private(set) var`, and no `import Observation`.

Rules for the body:
- `@MainActor` always.
- Setters of state are `private(set)`. Only the ViewModel mutates its state.
- No `import SwiftUI`. Foundation and Observation only.
- No direct repository access. Use cases only.
- No `Task { }` inside the ViewModel. Actions are `async`, the View owns the task.
- Strings come from the String Catalog when conventions.md says catalog mode.

Write `<Screen>+Models.swift` for presentation models, with `init(_ entity:)` mapping from the domain entity. Number and date formatting happens here, once.

## Step 4. Coordinator protocol

If `Features/<Name>/Coordinator/<Name>Navigating.swift` does not exist, create it with the routes the ViewModel needs and register it. coordinator-navigator will implement it. Never implement navigation in this skill.

```swift
protocol InvoicesNavigating: AnyObject {
    func navigate(to route: InvoicesRoute)
}
```

## Step 5. Register and hand off

Append every file to `Docs/file-map.md`. Update the Screens section of `Docs/Features/<Name>.md` with `ViewModel: done`.

Tell the user:

> [n] ViewModel(s) generated. Say "generate the view for [screen]" to build the SwiftUI view, or "generate tests" to cover the state transitions.

## What this skill produces

1. `Features/<Name>/Presentation/ViewModels/<Screen>ViewModel.swift`
2. `Features/<Name>/Presentation/ViewModels/<Screen>+Models.swift`
3. `Features/<Name>/Coordinator/<Name>Navigating.swift` if absent

## Dependencies

- Requires: `Docs/conventions.md`, `Docs/domain-model.md`, use cases from use-case-generator
- Feeds: view-generator, coordinator-navigator, dependency-injector, test-generator

## Rules

- Always design state and actions in chat and get approval before generating.
- Always one Phase enum for main content. Never contradictory booleans.
- Never import SwiftUI in a ViewModel.
- Never call a repository, a data source or another ViewModel.
- Never create a Task inside the ViewModel.
- Never hold a destination View. Navigation is an intent.
- Never format in the View what the ViewModel can format in a presentation model.
- Never use em dashes in any output file.
````

# skills/view-generator/SKILL.md

````markdown
---
name: view-generator
description: >
  Generate SwiftUI views bound to an existing ViewModel, using only DesignSystem tokens and components, with previews for every state. Produces Features/<Name>/Presentation/Views/ files. Use this skill whenever the user says "generate the view", "build the screen", "SwiftUI for [screen]", "make the UI for", "génère la vue", "construis l'écran", "fais l'interface de", "écran SwiftUI", or after viewmodel-generator finishes a screen. Requires viewmodel-generator and ui-ux-designer output (Docs/design-system.md).
---

# View Generator

## Prerequisites check

Check for `Docs/conventions.md`, `Docs/design-system.md` and the target `<Screen>ViewModel.swift`. If any is missing, say which one:

> Views bind to a ViewModel and use the design system. Run [viewmodel-generator | ui-ux-designer] first.

Then stop. If all present, read them plus `Docs/Features/<Feature>.md` and `Docs/file-map.md`. Go straight to Step 1.

## Step 1. Identify the screen and layout

Read the ViewModel's `Phase` enum and actions. Then call AskUserQuestion:

```json
[
  {
    "question": "Layout pattern?",
    "header": "Layout",
    "multiSelect": false,
    "options": [
      {"label": "List", "description": "Scrollable list with rows, search, pull to refresh"},
      {"label": "Detail", "description": "Single item, sections, actions bar"},
      {"label": "Form", "description": "Inputs, validation feedback, submit"},
      {"label": "Dashboard", "description": "Cards and summary blocks"}
    ]
  },
  {
    "question": "Design reference?",
    "header": "Reference",
    "multiSelect": false,
    "options": [
      {"label": "Design system only", "description": "Compose from DesignSystem/Components"},
      {"label": "I will paste a wireframe or screenshot", "description": "Match a mockup"},
      {"label": "Mirror an existing screen", "description": "Same structure as a screen already in the app"}
    ]
  }
]
```

Search `Docs/file-map.md` for `<Screen>View`. If it exists, switch to extend mode.

## Step 2. Map states to UI

Present a table before writing:

```
| Phase | UI |
|---|---|
| .idle / .loading | DSLoadingView (design system) |
| .empty | DSEmptyState(title:, action:) |
| .loaded(items) | List of InvoiceRow inside DSScreen |
| .failed(message) | DSErrorState(message:, retry:) |
```

List every design system component the view will use. For each, confirm it exists in `DesignSystem/Components/` via `file-map.md`. If one is missing, stop and redirect to swiftui-component-library. Never inline a component the design system should own.

Call AskUserQuestion to approve. Maximum 3 rounds.

## Step 3. Generate

```swift
// InvoiceListView.swift
// Layer: Presentation
// Purpose: Invoice list screen bound to InvoiceListViewModel

import SwiftUI

struct InvoiceListView: View {
    @State private var viewModel: InvoiceListViewModel

    init(viewModel: InvoiceListViewModel) {
        _viewModel = State(initialValue: viewModel)
    }

    var body: some View {
        DSScreen(title: String(localized: "invoices.title")) {
            content
        }
        .searchable(text: $viewModel.searchQuery)
        .refreshable { await viewModel.refresh() }
        .toolbar {
            ToolbarItem(placement: .primaryAction) {
                DSIconButton(icon: .plus, label: String(localized: "invoices.create")) {
                    viewModel.tapCreate()
                }
            }
        }
        .task { await viewModel.load() }
    }

    @ViewBuilder
    private var content: some View {
        switch viewModel.phase {
        case .idle, .loading:
            DSLoadingView()
        case .empty:
            DSEmptyState(title: String(localized: "invoices.empty"), actionTitle: String(localized: "invoices.create")) {
                viewModel.tapCreate()
            }
        case .loaded:
            List(viewModel.filteredItems) { item in
                InvoiceRow(item: item)
                    .contentShape(Rectangle())
                    .onTapGesture { viewModel.select(id: item.id) }
                    .swipeActions { deleteButton(for: item.id) }
            }
            .listStyle(.plain)
        case .failed(let message):
            DSErrorState(message: message) {
                Task { await viewModel.load() }
            }
        }
    }

    private func deleteButton(for id: InvoiceID) -> some View {
        Button(role: .destructive) {
            Task { await viewModel.delete(id: id) }
        } label: {
            Label(String(localized: "common.delete"), systemImage: "trash")
        }
    }
}

#Preview("Loaded") {
    InvoiceListView(viewModel: .preview(phase: .loaded(InvoiceRowItem.samples)))
}

#Preview("Empty") {
    InvoiceListView(viewModel: .preview(phase: .empty))
}

#Preview("Failed") {
    InvoiceListView(viewModel: .preview(phase: .failed(message: "Could not load invoices.")))
}
```

For `ObservableObject` mode: `@StateObject private var viewModel` and `_viewModel = StateObject(wrappedValue:)`.

Feature-only subviews (`InvoiceRow`) go in `Features/<Name>/Presentation/Components/`, one file each. If a subview is generic (no feature type in its signature), it belongs in `DesignSystem/Components/` instead, and you redirect to swiftui-component-library.

Previews need a `.preview(phase:)` factory. Create `Features/<Name>/Presentation/ViewModels/<Screen>ViewModel+Preview.swift` with mock use cases from `Tests/UnitTests/Mocks/` if they exist, otherwise minimal inline stubs marked `#if DEBUG`.

Rules for the body:
- No colours, fonts, spacing literals. Tokens only (`DSColor`, `DSFont`, `DSSpacing`).
- No business logic. No formatting. No `if` on domain values beyond switching on Phase.
- No `NavigationLink` with a destination. Navigation is `viewModel.select(...)`.
- Every user-facing string via `String(localized:)` when catalog mode. Add the keys to `Localizable.xcstrings` with base-language values.
- `body` under 40 lines. Extract `@ViewBuilder` properties.
- Accessibility: every interactive element has a label. Every image has a description or is decorative.

## Step 4. Register and hand off

Append every file to `Docs/file-map.md`. Add new localisation keys to the String Catalog. Update `Docs/Features/<Name>.md` Screens section with `View: done`.

Tell the user:

> [Screen]View generated with [n] previews. Say "wire the navigation" for coordinator-navigator, or "generate UI tests" for test-generator.

## What this skill produces

1. `Features/<Name>/Presentation/Views/<Screen>View.swift`
2. `Features/<Name>/Presentation/Components/<Row|Card|Section>.swift` as needed
3. `Features/<Name>/Presentation/ViewModels/<Screen>ViewModel+Preview.swift`
4. String Catalog keys

## Dependencies

- Requires: `<Screen>ViewModel.swift` (viewmodel-generator), `Docs/design-system.md` (ui-ux-designer), `DesignSystem/Components/` (swiftui-component-library)
- Feeds: coordinator-navigator, test-generator

## Rules

- Always map every Phase case to a UI. A missing case is a bug.
- Always use design system tokens and components. Never a raw `Color`, `Font` or numeric padding.
- Never put navigation destinations in a View.
- Never put logic in a View beyond switching on state.
- Never inline a reusable component. Redirect to swiftui-component-library.
- Always ship at least three previews: loaded, empty, failed.
- Never use em dashes in any output file.
````

# skills/coordinator-navigator/SKILL.md

````markdown
---
name: coordinator-navigator
description: >
  Implement navigation with the Coordinator pattern on top of NavigationStack: route enums, feature coordinators, AppCoordinator, tab and modal management, deep link routing, all outside the Views. Produces Core/Navigation/ and Features/<Name>/Coordinator/ files. Use this skill whenever the user says "wire the navigation", "coordinator for", "add a route", "deep link", "navigate from X to Y", "tab bar setup", "câble la navigation", "coordinateur", "ajoute une route", "lien profond", "navigation entre écrans", or when a ViewModel emits a navigation intent with no coordinator implementation. Requires architecture-designer (navigation topology) and viewmodel-generator (Navigating protocols).
---

# Coordinator Navigator

## Prerequisites check

Check for `Docs/conventions.md` and `Docs/architecture.md`. If missing, say:

> Navigation follows the topology in architecture.md. Run architecture-designer first.

Then stop. If present, read both, plus `Docs/file-map.md` and every `Features/*/Coordinator/*Navigating.swift`. Go straight to Step 1.

## Step 1. Scope

Call AskUserQuestion:

```json
[
  {
    "question": "What to wire?",
    "header": "Scope",
    "multiSelect": false,
    "options": [
      {"label": "App root", "description": "AppCoordinator, tabs, root stack, first launch"},
      {"label": "One feature", "description": "Routes and coordinator for one feature"},
      {"label": "Add a route", "description": "One new destination in an existing coordinator"},
      {"label": "Deep links", "description": "URL scheme and universal links to routes"}
    ]
  }
]
```

Search `Docs/file-map.md` for existing `AppCoordinator`, `<Feature>Coordinator`, `<Feature>Route`. Existing coordinators are extended, never rewritten.

## Step 2. Define routes

For the feature, one `enum <Feature>Route: Hashable` with one case per destination, carrying only IDs or value types, never entities:

```swift
// InvoicesRoute.swift
// Layer: Presentation
// Purpose: Every destination reachable inside the Invoices feature

import Foundation

enum InvoicesRoute: Hashable {
    case list
    case detail(InvoiceID)
    case create
    case edit(InvoiceID)
}
```

Sheets and full-screen covers get their own enum `enum <Feature>Modal: Identifiable`. Present the routes and the presentation style (push, sheet, cover) per route in a table. Call AskUserQuestion to approve.

## Step 3. Generate the feature coordinator

```swift
// InvoicesCoordinator.swift
// Layer: Presentation
// Purpose: Owns the Invoices navigation stack and builds its screens

import SwiftUI
import Observation

@MainActor
@Observable
final class InvoicesCoordinator: InvoicesNavigating {
    var path = NavigationPath()
    var modal: InvoicesModal?

    private let container: AppContainer

    init(container: AppContainer) {
        self.container = container
    }

    func navigate(to route: InvoicesRoute) {
        switch route {
        case .list: path = NavigationPath()
        case .detail(let id): path.append(InvoicesRoute.detail(id))
        case .create: modal = .create
        case .edit(let id): path.append(InvoicesRoute.edit(id))
        }
    }

    func pop() { if !path.isEmpty { path.removeLast() } }
    func dismissModal() { modal = nil }

    @ViewBuilder
    func view(for route: InvoicesRoute) -> some View {
        switch route {
        case .list: InvoiceListView(viewModel: container.makeInvoiceListViewModel(coordinator: self))
        case .detail(let id): InvoiceDetailView(viewModel: container.makeInvoiceDetailViewModel(id: id, coordinator: self))
        case .create: InvoiceFormView(viewModel: container.makeInvoiceFormViewModel(mode: .create, coordinator: self))
        case .edit(let id): InvoiceFormView(viewModel: container.makeInvoiceFormViewModel(mode: .edit(id), coordinator: self))
        }
    }
}
```

Plus a root view `Features/<Name>/Coordinator/<Feature>CoordinatorView.swift` that owns the `NavigationStack(path:)`, `.navigationDestination(for: <Feature>Route.self)` and `.sheet(item:)` bindings, and nothing else.

The `container.make...` factories must exist. If not, stop and redirect to dependency-injector with the exact list of factories needed.

## Step 4. Generate the app coordinator

`Core/Navigation/AppCoordinator.swift`: owns `selectedTab`, one child coordinator per tab (from the topology in architecture.md), the onboarding or auth gate, and `handle(url:)` for deep links. `Core/Navigation/AppRoute.swift`: top-level routes (tab selection, global modals). `App/<AppName>App.swift` instantiates `AppCoordinator(container: .shared)` once and renders `AppCoordinatorView`.

Deep links: `handle(url:)` parses the URL into an `AppRoute` and forwards to the right child coordinator. Parsing lives in `Core/Navigation/DeepLinkParser.swift`, pure and testable.

## Step 5. Register and hand off

Append every file to `Docs/file-map.md`. Update the Navigation topology in `Docs/architecture.md` if a route was added.

Tell the user:

> Navigation wired for [scope]. [n] routes, [n] modals. Say "wire the dependencies" if factories are missing, or "generate UI tests" to cover the flows.

## What this skill produces

1. `Features/<Name>/Coordinator/<Feature>Route.swift`, `<Feature>Modal.swift`, `<Feature>Coordinator.swift`, `<Feature>CoordinatorView.swift`
2. `Core/Navigation/AppCoordinator.swift`, `AppRoute.swift`, `AppCoordinatorView.swift`, `DeepLinkParser.swift`

## Dependencies

- Requires: `Docs/architecture.md`, `*Navigating.swift` protocols (viewmodel-generator), `AppContainer` factories (dependency-injector)
- Feeds: test-generator, feature-builder

## Rules

- Always one route enum per feature. Routes carry IDs, never entities.
- Always build screens through AppContainer factories. Never `SomeViewModel(...)` inline in a coordinator.
- Never let a View hold a NavigationPath or a destination.
- Never let a coordinator call a use case or a repository.
- Never let two coordinators reference each other directly. Parent to child only, child talks up through a protocol.
- Never use em dashes in any output file.
````

# skills/ui-ux-designer/SKILL.md

````markdown
---
name: ui-ux-designer
description: >
  Design the visual and interaction system of the app: design tokens (colour, typography, spacing, radius, motion), component inventory, screen wireframes as text, and interaction rules following Apple Human Interface Guidelines. Produces Docs/design-system.md and DesignSystem/Tokens/ files. Use this skill whenever the user says "design the UI", "design system", "tokens", "colour palette", "typography", "wireframe", "how should this screen look", "UX for", "conçois l'interface", "design system", "palette", "typographie", "maquette", "à quoi doit ressembler", or before view-generator runs for the first time. Requires ios-project-foundation. Reads Docs/product.md.
---

# UI/UX Designer

## Prerequisites check

Check for `Docs/project-brief.md` and `Docs/conventions.md`. If missing, say:

> The design system follows the product brief. Run ios-project-foundation first.

Then stop. If present, read both plus `Docs/product.md`, `Docs/Features/*.md` and `Docs/design-system.md` if present. If `design-system.md` exists, go to Step 6 (extend mode). Otherwise go straight to Step 1.

## Step 1. Gather direction

Call AskUserQuestion:

```json
[
  {
    "question": "Visual direction?",
    "header": "Direction",
    "multiSelect": false,
    "options": [
      {"label": "Native Apple", "description": "System colours, SF fonts, standard controls. Fastest, always HIG compliant."},
      {"label": "Native with brand accent", "description": "System base, one brand colour, custom components where it matters"},
      {"label": "Custom branded", "description": "Full palette, custom type scale, bespoke components"}
    ]
  },
  {
    "question": "Brand inputs?",
    "header": "Brand",
    "multiSelect": false,
    "options": [
      {"label": "I have hex codes and fonts", "description": "I will paste them"},
      {"label": "I have a reference app or screenshots", "description": "I will describe or paste"},
      {"label": "Propose for me", "description": "Derive from the product brief"}
    ]
  },
  {
    "question": "Appearance support?",
    "header": "Appearance",
    "multiSelect": true,
    "options": [
      {"label": "Light and dark", "description": "Both, semantic colours required"},
      {"label": "Dynamic Type", "description": "Full range including accessibility sizes"},
      {"label": "Reduce Motion", "description": "Every animation has a reduced variant"},
      {"label": "iPad layouts", "description": "Size class aware"}
    ]
  }
]
```

Wait for pasted inputs if applicable.

## Step 2. Define tokens

Present the token set in chat. Every token is semantic, never named after its value.

```
Colour (light / dark)
  ds.background.primary      #FFFFFF / #000000
  ds.background.secondary    #F2F2F7 / #1C1C1E
  ds.text.primary            #000000 / #FFFFFF
  ds.text.secondary          #3C3C43 99% / #EBEBF5 60%
  ds.accent                  <brand> / <brand adjusted>
  ds.status.success / warning / danger / info

Typography (Dynamic Type mapped)
  ds.font.largeTitle   → .largeTitle, bold
  ds.font.title        → .title2, semibold
  ds.font.body         → .body
  ds.font.caption      → .caption

Spacing (4pt grid)
  ds.space.xs 4 · s 8 · m 16 · l 24 · xl 32 · xxl 48

Radius
  ds.radius.s 6 · m 12 · l 20 · pill 999

Motion
  ds.motion.fast 0.15s · standard 0.25s · slow 0.4s, easeInOut
  Reduce Motion: cross-fade only
```

Call AskUserQuestion to approve. Maximum 3 rounds.

## Step 3. Component inventory

From the screens in `Docs/Features/*.md`, list every reusable component the app needs. Prefix `DS`. For each: name, purpose, variants, states, which screens use it.

```
| Component | Purpose | Variants | States | Used by |
|---|---|---|---|---|
| DSScreen | Page container, title, background, safe areas | plain, grouped | none | every screen |
| DSButton | Primary action | primary, secondary, destructive, ghost | enabled, disabled, loading | Form, Detail |
| DSEmptyState | No content placeholder | with action, without | none | List screens |
| DSErrorState | Failure with retry | inline, fullscreen | none | every loading screen |
| DSLoadingView | Progress placeholder | inline, fullscreen | none | every loading screen |
| DSCard | Grouped content block | elevated, flat | none | Dashboard, Detail |
| DSTextField | Text input with validation | default, secure, multiline | idle, focused, error | Form |
| DSBadge | Status label | success, warning, danger, neutral | none | Rows |
```

A component earns a row only if two or more screens use it, or if it encodes a rule (validation display, loading). Feature-only components stay in the feature folder and are not listed here.

## Step 4. Wireframes

For each P0 screen, a text wireframe:

```
┌─────────────────────────────┐
│ ‹ Back        Invoices   [+]│  DSScreen title, toolbar
├─────────────────────────────┤
│ 🔍 Search                   │  .searchable
├─────────────────────────────┤
│ ▢ Acme Corp      €1,200  ● │  InvoiceRow: title, amount, DSBadge
│ ▢ Globex         €340    ● │
│ ...                         │
├─────────────────────────────┤
│ (empty) DSEmptyState        │  when no invoices
└─────────────────────────────┘
```

Plus interaction notes per screen: tap targets, swipe actions, haptics, transitions, empty and error behaviour.

## Step 5. Write the files

`Docs/design-system.md`:

```
# Design System

## Direction
[From Step 1, 2 sentences]

## Tokens
[Step 2 block, final]

## Components
[Step 3 table]

## Wireframes
[Step 4, one per P0 screen]

## Interaction rules
[Haptics policy, animation policy, loading policy, error display policy, empty state policy]

## Accessibility
[Dynamic Type range, VoiceOver labelling rule, contrast minimum 4.5:1, Reduce Motion behaviour, minimum tap target 44pt]

## HIG references
[Which HIG patterns each screen type follows]
```

Token files, one per category, under `DesignSystem/Tokens/`:

```swift
// DSColor.swift
// Layer: DesignSystem
// Purpose: Semantic colour tokens, light and dark

import SwiftUI

enum DSColor {
    static let backgroundPrimary = Color("ds.background.primary", bundle: .main)
    static let textPrimary = Color("ds.text.primary", bundle: .main)
    static let accent = Color("ds.accent", bundle: .main)
}
```

Colour values go into `App/Resources/Assets.xcassets` as colour sets with light and dark appearances. Never hex literals in Swift. `DSFont`, `DSSpacing`, `DSRadius`, `DSMotion` follow the same pattern with static constants.

Register every file in `Docs/file-map.md`.

## Step 6. Extend mode

If `design-system.md` exists, ask what to add: a token, a component row, a wireframe. Add only that. Never rename an existing token. If a token must change value, change it in the asset catalogue and note the date in the doc.

## Step 7. Hand off

Tell the user:

> Design system is written: [n] tokens, [n] components inventoried, [n] wireframes. Say "build the component library" to run swiftui-component-library and implement the DS components.

## What this skill produces

1. `Docs/design-system.md`
2. `DesignSystem/Tokens/DSColor.swift`, `DSFont.swift`, `DSSpacing.swift`, `DSRadius.swift`, `DSMotion.swift`
3. Colour sets in the asset catalogue

## Dependencies

- Requires: `Docs/project-brief.md`, `Docs/conventions.md`
- Reads if present: `Docs/product.md`, `Docs/Features/*.md`
- Feeds: swiftui-component-library, view-generator

## Rules

- Always name tokens semantically. Never `blue500`, always `accent` or `status.info`.
- Always provide light and dark values for every colour.
- Always map typography to Dynamic Type styles. Never fixed point sizes as the primary scale.
- Never put hex literals in Swift files.
- Never inventory a component used by only one screen.
- Every interactive element meets 44pt and 4.5:1 contrast.
- Never use em dashes in any output file.
````

# skills/swiftui-component-library/SKILL.md

````markdown
---
name: swiftui-component-library
description: >
  Implement the reusable SwiftUI components inventoried in Docs/design-system.md, one file per component under DesignSystem/Components/, with variants, states, accessibility and previews, using tokens only. Also promotes a feature-local component to the design system when a second feature needs it. Use this skill whenever the user says "build the component library", "create the DS components", "make a reusable button", "component for", "promote this component", "shared component", "crée les composants", "bibliothèque de composants", "composant réutilisable", "factorise ce composant", or when view-generator reports a missing DS component. Requires ui-ux-designer.
---

# SwiftUI Component Library

## Prerequisites check

Check for `Docs/design-system.md` and `DesignSystem/Tokens/`. If missing, say:

> Components are built from tokens. Run ui-ux-designer first ("design the UI").

Then stop. If present, read `design-system.md`, `Docs/conventions.md`, `Docs/file-map.md`. Go straight to Step 1.

## Step 1. Scope

Call AskUserQuestion:

```json
[
  {
    "question": "What to build?",
    "header": "Scope",
    "multiSelect": false,
    "options": [
      {"label": "Whole inventory", "description": "Every component in design-system.md not yet implemented"},
      {"label": "One component", "description": "I will name it"},
      {"label": "Promote from a feature", "description": "Move a Features/*/Presentation/Components/ file into DesignSystem"},
      {"label": "Add a variant", "description": "Extend an existing DS component"}
    ]
  }
]
```

Cross-check the inventory against `Docs/file-map.md`. Components already in `DesignSystem/Components/` are never regenerated. If the user names a component absent from the inventory, add the row to `design-system.md` first (redirect to ui-ux-designer extend mode or do it inline if trivial and say so).

## Step 2. Design the API

For each component, present its public API before writing:

```
DSButton
  init(_ title: String, variant: Variant = .primary, isLoading: Bool = false, action: @escaping () -> Void)
  Variant: primary, secondary, destructive, ghost
  Disabled: via .disabled() environment, styled automatically
  Sizing: full width by default, .dsButtonCompact() modifier for inline
  Accessibility: title is the label, isLoading sets .accessibilityValue("Loading")
```

API rules:
- Small, explicit initialisers. No configuration bag with 12 optionals.
- Variants are nested enums.
- Style follows the SwiftUI `ButtonStyle` / `ViewModifier` idiom where it fits, so consumers can `.buttonStyle(.dsPrimary)`.
- No callbacks with domain types. Strings, IDs, closures only.

Call AskUserQuestion to approve. Maximum 3 rounds.

## Step 3. Implement

```swift
// DSButton.swift
// Layer: DesignSystem
// Purpose: Primary action button with variants and loading state

import SwiftUI

struct DSButton: View {
    enum Variant { case primary, secondary, destructive, ghost }

    private let title: String
    private let variant: Variant
    private let isLoading: Bool
    private let action: () -> Void

    @Environment(\.isEnabled) private var isEnabled

    init(_ title: String, variant: Variant = .primary, isLoading: Bool = false, action: @escaping () -> Void) {
        self.title = title
        self.variant = variant
        self.isLoading = isLoading
        self.action = action
    }

    var body: some View {
        Button(action: action) {
            ZStack {
                Text(title).opacity(isLoading ? 0 : 1)
                if isLoading { ProgressView().tint(foreground) }
            }
            .font(DSFont.body.weight(.semibold))
            .frame(maxWidth: .infinity, minHeight: 44)
            .padding(.horizontal, DSSpacing.m)
            .background(background, in: RoundedRectangle(cornerRadius: DSRadius.m))
            .foregroundStyle(foreground)
        }
        .disabled(isLoading || !isEnabled)
        .opacity(isEnabled ? 1 : 0.4)
        .accessibilityLabel(title)
        .accessibilityValue(isLoading ? Text("Loading") : Text(""))
    }

    private var background: Color {
        switch variant {
        case .primary: DSColor.accent
        case .secondary: DSColor.backgroundSecondary
        case .destructive: DSColor.statusDanger
        case .ghost: .clear
        }
    }

    private var foreground: Color {
        switch variant {
        case .primary, .destructive: DSColor.textOnAccent
        case .secondary, .ghost: DSColor.textPrimary
        }
    }
}

#Preview("Variants") {
    VStack(spacing: DSSpacing.m) {
        DSButton("Primary") {}
        DSButton("Secondary", variant: .secondary) {}
        DSButton("Destructive", variant: .destructive) {}
        DSButton("Ghost", variant: .ghost) {}
        DSButton("Loading", isLoading: true) {}
        DSButton("Disabled") {}.disabled(true)
    }
    .padding()
}
```

Every component file:
- Tokens only. Zero literal colours, fonts, or numeric spacing.
- One preview showing every variant and state, plus one preview with `.dynamicTypeSize(.accessibility3)` and one with `.preferredColorScheme(.dark)`.
- Accessibility label, value and traits set where the default is not enough.
- No dependency on Domain or any feature. `import SwiftUI` only.

Modifiers go in `DesignSystem/Modifiers/<Name>Modifier.swift` with a `View` extension in the same file.

## Step 4. Promote mode

When promoting a feature component:
1. Read the feature file. Strip every feature type from its signature (replace `InvoiceRowItem` with strings and closures).
2. Create the DS version with the `DS` prefix.
3. Replace the feature component with a thin wrapper that maps the feature model to the DS component, or delete it if the wrapper would be trivial and update the View directly.
4. Show before and after in chat. Apply after approval.
5. Update `file-map.md`: new DS file, deleted or modified feature file.

## Step 5. Register and hand off

Append every file to `Docs/file-map.md`. Mark each row of the inventory in `design-system.md` with `Status: implemented`.

Tell the user:

> [n] components implemented under DesignSystem/Components/ with previews. Say "generate the view for [screen]" to use them.

## What this skill produces

1. `DesignSystem/Components/DS<Name>.swift`, one per component
2. `DesignSystem/Modifiers/<Name>Modifier.swift` as needed
3. Status updates in `Docs/design-system.md`

## Dependencies

- Requires: `Docs/design-system.md`, `DesignSystem/Tokens/` (ui-ux-designer)
- Feeds: view-generator

## Rules

- Always `DS` prefix. Always one component per file.
- Always tokens. Never literals.
- Never import Domain or a feature type into DesignSystem.
- Never regenerate an existing component. Extend with a variant.
- Every component ships with variant, dark mode and accessibility-size previews.
- Never use em dashes in any output file.
````

# skills/swift-coder/SKILL.md

````markdown
---
name: swift-coder
description: >
  Write or modify Swift code inside an existing file with strict respect for Docs/conventions.md: minimal targeted edits, layer rules, naming, no duplication, no dead code. The general-purpose implementation skill used when no specialised generator applies, and for bug fixes. Use this skill whenever the user says "write the code for", "implement this function", "fix this bug", "refactor this", "add this method", "why does this crash", "écris le code", "implémente", "corrige ce bug", "refactore", "ajoute cette méthode", "pourquoi ça plante", or pastes Swift code asking for changes. Requires ios-project-foundation.
---

# Swift Coder

## Prerequisites check

Check for `Docs/conventions.md` and `Docs/file-map.md`. If missing, say:

> I write code against the project conventions. Run ios-project-foundation first, or say "no conventions" to proceed with Apple defaults for this one task.

If the user says "no conventions", proceed with Swift API Design Guidelines and note that nothing is registered. Otherwise read both files plus `Docs/architecture.md` and `Docs/domain-model.md` if present. Go straight to Step 1.

## Step 1. Locate the change

Call AskUserQuestion:

```json
[
  {
    "question": "What kind of change?",
    "header": "Change",
    "multiSelect": false,
    "options": [
      {"label": "Bug fix", "description": "Something is wrong, minimal targeted fix"},
      {"label": "New function or method", "description": "Add behaviour to an existing type"},
      {"label": "Refactor", "description": "Same behaviour, better structure"},
      {"label": "Explain or diagnose", "description": "No edit yet, tell me what is happening"}
    ]
  }
]
```

Ask for the file path or the pasted code if not given. Read the whole file. Read every type it references that lives in the project.

Before proposing anything, search `Docs/file-map.md` and grep the codebase for a function or type that already does what is being asked. If one exists, propose reusing it instead of writing new code. State the path.

## Step 2. Plan the edit

Output a plan before touching anything:

```
File: Features/Invoices/Presentation/ViewModels/InvoiceListViewModel.swift
Change 1 (line 42): guard on empty query before filtering
  Before: return items.filter { $0.title.contains(searchQuery) }
  After:  guard !searchQuery.isEmpty else { return items }
          return items.filter { $0.title.localizedCaseInsensitiveContains(searchQuery) }
Reason: R-07, empty query returns everything, and search must be case insensitive
Layer check: Presentation, allowed
Duplication check: no existing filter helper in file-map.md
```

For bug fixes: only lines that cause the bug. If you notice an unrelated improvement, list it under `Not applied` with one line each. Never apply it.

For new code: state which layer it belongs to per conventions.md. If it does not belong in the target file, say where it goes and stop, or redirect to the specialised skill (viewmodel-generator, use-case-generator, data-layer-generator, swiftui-component-library).

Call AskUserQuestion to approve the plan. No edit before approval.

## Step 3. Apply

Use targeted string replacement per change. Never rewrite the whole file for a partial change. Keep the file header comment. Keep existing formatting.

After applying, run a self-check on the edited file:

| Check | Rule |
|---|---|
| Layer | No forbidden import for the file's layer |
| Naming | Matches the Naming table |
| Access | `private` by default |
| Safety | No force unwrap, no `try!`, no `as!` |
| Concurrency | `@MainActor` where UI state is touched, `Sendable` where crossing actors |
| Size | File under 300 lines, function under 40 lines |
| Dead code | No unused variable, parameter, import or function introduced |
| Strings | Catalog keys in catalog mode |

Report any violation you had to accept and why.

## Step 4. Diagnose mode

For "Explain or diagnose": read the code and the call sites. Answer in this order: what happens, why, the exact line, the fix in one sentence. Then offer to apply it via Bug fix mode. No edit.

## Step 5. Register and hand off

If a new file was created (only when the plan justified it), append to `Docs/file-map.md`. If a rule was implemented, add its ID to the `## Business rules` table in `domain-model.md`.

Tell the user:

> Applied [n] change(s) to [file]. [Not applied: list]. Say "generate tests" to cover this, or "dedupe" to check for duplicates across the project.

## What this skill produces

1. Targeted edits in existing files
2. Rarely, a new file registered in `Docs/file-map.md`

## Dependencies

- Requires: `Docs/conventions.md`, `Docs/file-map.md`
- Reads if present: `Docs/architecture.md`, `Docs/domain-model.md`
- Feeds: test-generator, code-deduplicator

## Rules

- Always plan with before and after per change, and get approval, before editing.
- Always search for existing code that does the job before writing new code.
- Never touch lines unrelated to the requested change. Mention, do not apply.
- Never move logic across layers silently. Say it and redirect.
- Never introduce a catch-all file.
- Never leave a TODO. Unfinished work goes in Docs/Features/<name>.md.
- Never use em dashes in any output file.
````

# skills/code-deduplicator/SKILL.md

````markdown
---
name: code-deduplicator
description: >
  Detect and eliminate duplicated code and dead code across the project: identical or near-identical functions, repeated view fragments, parallel types, unused files, unreferenced symbols. Factorises into the correct layer, deletes what is dead, and keeps Docs/file-map.md truthful. Use this skill whenever the user says "dedupe", "find duplicates", "remove dead code", "clean up", "factorise", "this looks copied", "unused files", "déduplique", "trouve les doublons", "supprime le code mort", "nettoie", "factorise", "fichiers inutilisés", or at the end of every feature-builder run. Requires ios-project-foundation.
---

# Code Deduplicator

## Prerequisites check

Check for `Docs/conventions.md` and `Docs/file-map.md`. If missing, say:

> Deduplication works against the file map. Run ios-project-foundation first.

Then stop. If present, read both. Go straight to Step 1.

## Step 1. Scope

Call AskUserQuestion:

```json
[
  {
    "question": "Where to look?",
    "header": "Scope",
    "multiSelect": false,
    "options": [
      {"label": "Whole project", "description": "Every .swift file"},
      {"label": "One feature", "description": "Features/<Name> plus its Domain and Data folders"},
      {"label": "One layer", "description": "Domain, Data, Presentation or DesignSystem"},
      {"label": "Since last run", "description": "Files changed after the last entry in Docs/dedup-log.md"}
    ]
  }
]
```

## Step 2. Scan

Run four passes and collect findings. Use grep, ripgrep or a script in `scripts/` if the project is large.

**Pass A. Exact and near duplicates**
- Functions with identical bodies modulo whitespace and identifier names
- View bodies with the same modifier chain and structure
- Types with the same stored properties under different names (`InvoiceRowItem` vs `InvoiceCellModel`)
- Extensions declaring the same helper on the same type in two files

**Pass B. Semantic duplicates**
- Two mappers converting the same pair of types
- Two error to message tables for the same error enum
- Formatting logic (dates, money, percentages) implemented in more than one place
- Validation of the same value object in a ViewModel and in Domain

**Pass C. Dead code**
- Files in `file-map.md` that no longer exist on disk, and files on disk absent from `file-map.md`
- Types with zero references outside their own file (excluding App entry, previews, tests)
- Functions, properties, parameters and imports never used
- Feature folders whose spec is `Status: cut` in `Docs/product.md`
- Commented-out code blocks over 5 lines

**Pass D. Layer leaks that create duplication**
- A rule implemented in Domain and again in a ViewModel guard
- A DTO used directly by a View instead of the entity

## Step 3. Report

Output one table before changing anything:

```
| ID | Kind | Location A | Location B | Proposed action | Target layer |
|---|---|---|---|---|---|
| D-01 | near duplicate | InvoiceListViewModel.swift:88 | InvoiceDetailViewModel.swift:61 | extract InvoiceError+Message.swift | Presentation |
| D-02 | semantic | Invoice+Formatting.swift | InvoiceRow.swift:22 | keep Domain? no, move to InvoiceRowItem | Presentation |
| X-01 | dead file | Core/Utilities/Legacy.swift | | delete | |
| X-02 | unused func | InvoiceMapper.swift:40 toLegacyDTO | | delete | |
```

Target layer follows conventions.md:
- Formatting for display: Presentation model (`<Screen>+Models.swift`)
- Rule or calculation: Domain (business-logic-engine owns it, redirect if new)
- Generic view fragment: DesignSystem (swiftui-component-library owns it, redirect if it needs design)
- Generic Swift helper on a Foundation type: `Core/Extensions/<Type>+<Concern>.swift`, one concern per file, never a catch-all

Call AskUserQuestion with three options: apply all, choose by ID, cancel. Wait.

## Step 4. Apply

For each approved item:
1. Create the single canonical implementation at the target path (or reuse the surviving one).
2. Replace every duplicate call site with a call to the canonical one. Show before and after per site.
3. Delete the duplicate definitions and dead files with `git rm` when in a git repo.
4. Update `Docs/file-map.md`: add the canonical file, remove deleted files.
5. If tests exist for a deleted symbol, delete or redirect them and say so.

Build check: if a build command is available (`xcodebuild` or `swift build`), run it. If not, list every touched file so the user can build.

## Step 5. Log

Append to `Docs/dedup-log.md` (create with a title if absent):

```
## <date>
Scope: <scope>
Applied: D-01, D-02, X-01
Skipped: X-02 (user kept it)
Files touched: <n>. Lines removed: <n>.
```

## Step 6. Hand off

Tell the user:

> Removed [n] duplicates and [n] dead items. file-map.md is in sync with disk. Say "generate tests" to cover the factorised code, or "audit the layers" to run layer-auditor.

## What this skill produces

1. Factorised canonical implementations in the correct layer
2. Deleted duplicate and dead code
3. `Docs/dedup-log.md` entry and a synchronised `Docs/file-map.md`

## Dependencies

- Requires: `Docs/conventions.md`, `Docs/file-map.md`
- May redirect to: business-logic-engine, swiftui-component-library
- Feeds: test-generator, layer-auditor

## Rules

- Always report the full table and get approval before deleting anything.
- Never factorise into a catch-all file. One concern per file.
- Never move a rule into Presentation to make deduplication easier. Domain wins.
- Never delete a file referenced by the Xcode project without stating that the reference must be removed.
- Always keep file-map.md equal to the disk after the run.
- Never use em dashes in any output file.
````

# skills/dependency-injector/SKILL.md

````markdown
---
name: dependency-injector
description: >
  Build and maintain the composition root: a single AppContainer with typed factories for repositories, use cases, ViewModels and coordinators, environment-specific wiring (live, preview, test) and no service locator lookups. Produces Core/DI/ files. Use this skill whenever the user says "wire the dependencies", "dependency injection", "container", "how do I inject", "factory for", "preview container", "test container", "câble les dépendances", "injection de dépendances", "conteneur", "comment injecter", or when coordinator-navigator or view-generator reports a missing factory. Requires use-case-generator and data-layer-generator output.
---

# Dependency Injector

## Prerequisites check

Check for `Docs/conventions.md`, `Docs/architecture.md` and `Docs/file-map.md`. If missing, say:

> DI wires what the architecture defines. Run architecture-designer first.

Then stop. If present, read all three. Read `Core/DI/AppContainer.swift` if it exists. Go straight to Step 1.

## Step 1. Scope

Call AskUserQuestion:

```json
[
  {
    "question": "What to wire?",
    "header": "Scope",
    "multiSelect": false,
    "options": [
      {"label": "Bootstrap the container", "description": "Create AppContainer and the environment variants for the first time"},
      {"label": "One feature", "description": "Add factories for every type of one feature"},
      {"label": "Missing factories", "description": "Scan for make... calls that do not exist and add them"},
      {"label": "Audit", "description": "Find direct instantiations that bypass the container"}
    ]
  }
]
```

## Step 2. Build the dependency graph

From `file-map.md`, collect for the scope every protocol and its implementation, every use case and its `init` parameters, every ViewModel and its `init`, every coordinator. Present the graph:

```
InvoiceListViewModel
  ← FetchInvoicesUseCase        = DefaultFetchInvoicesUseCase
      ← InvoiceRepository       = InvoiceRepositoryImpl
          ← InvoiceRemoteDataSource = URLSessionInvoiceRemoteDataSource ← HTTPClient
          ← InvoiceLocalDataSource  = SwiftDataInvoiceLocalDataSource  ← ModelContainer
  ← DeleteInvoiceUseCase        = DefaultDeleteInvoiceUseCase ← InvoiceRepository
  ← InvoicesNavigating          = InvoicesCoordinator (passed by the coordinator itself)
```

Lifetimes:
- Shared, one instance per app: `HTTPClient`, `ModelContainer`, repositories, data sources. Stored as `lazy var` or `let` in the container.
- Transient, one per screen: use cases (cheap structs), ViewModels. Built by factory methods.
- Coordinators: owned by their parent coordinator, not by the container. The container builds them on request from the parent.

Flag any type that cannot be resolved (missing implementation). Redirect to data-layer-generator or use-case-generator with the exact type name. Do not stub.

Call AskUserQuestion to approve. Maximum 3 rounds.

## Step 3. Generate

`Core/DI/AppContainer.swift`:

```swift
// AppContainer.swift
// Layer: Core
// Purpose: Composition root. The only place concrete types are chosen.

import Foundation
import SwiftData

@MainActor
final class AppContainer {
    static let shared = AppContainer(environment: .live)

    let environment: AppEnvironment

    init(environment: AppEnvironment) {
        self.environment = environment
    }

    // MARK: Shared infrastructure
    lazy var httpClient: HTTPClient = environment.makeHTTPClient()
    lazy var modelContainer: ModelContainer = environment.makeModelContainer()
}
```

`Core/DI/AppEnvironment.swift`: `enum AppEnvironment { case live, preview, test }` with the infrastructure factories per case (live URLSession vs stub client, on-disk vs in-memory ModelContainer).

`Core/DI/AppContainer+<Feature>.swift`, one extension per feature:

```swift
// AppContainer+Invoices.swift
// Layer: Core
// Purpose: Factories for the Invoices feature

import Foundation

extension AppContainer {
    // MARK: Data (shared)
    var invoiceRepository: InvoiceRepository {
        registry.resolve(InvoiceRepository.self) {
            InvoiceRepositoryImpl(
                remote: URLSessionInvoiceRemoteDataSource(client: httpClient),
                local: SwiftDataInvoiceLocalDataSource(container: modelContainer)
            )
        }
    }

    // MARK: Domain (transient)
    func makeFetchInvoicesUseCase() -> FetchInvoicesUseCase {
        DefaultFetchInvoicesUseCase(invoices: invoiceRepository)
    }

    // MARK: Presentation (transient)
    func makeInvoiceListViewModel(coordinator: any InvoicesNavigating) -> InvoiceListViewModel {
        InvoiceListViewModel(
            fetchInvoices: makeFetchInvoicesUseCase(),
            deleteInvoice: makeDeleteInvoiceUseCase(),
            coordinator: coordinator
        )
    }

    func makeInvoicesCoordinator() -> InvoicesCoordinator {
        InvoicesCoordinator(container: self)
    }
}
```

`Core/DI/Registry.swift`: a tiny typed cache (`resolve(_:factory:)`) keyed by `ObjectIdentifier`, used only for shared lifetimes, private to the container. No global lookup API. No string keys.

Preview and test:
- `AppContainer.preview` static in `Core/DI/AppContainer+Preview.swift` under `#if DEBUG`, using in-memory data sources and sample data from `Tests/UnitTests/Mocks/` or DesignSystem sample fixtures.
- Test targets build `AppContainer(environment: .test)` and override repositories through a `override<T>(_:with:)` method available only in `.test` and `.preview`.

## Step 4. Audit mode

Grep the project for `RepositoryImpl(`, `DataSource(`, `UseCase(`, `ViewModel(`, `Coordinator(` outside `Core/DI/`, previews and tests. Each hit is a bypass. Report the table and replace with a factory call after approval.

## Step 5. Register and hand off

Append every file to `Docs/file-map.md`. Write or update the `## Dependency graph` section of `Docs/architecture.md` with the Step 2 graph.

Tell the user:

> Container wired for [scope]: [n] shared instances, [n] factories. Say "wire the navigation" for coordinator-navigator, or "generate tests" to use the test container.

## What this skill produces

1. `Core/DI/AppContainer.swift`, `AppEnvironment.swift`, `Registry.swift`, `AppContainer+Preview.swift`
2. `Core/DI/AppContainer+<Feature>.swift` per feature
3. `## Dependency graph` in `Docs/architecture.md`

## Dependencies

- Requires: `Docs/architecture.md`, `Docs/conventions.md`, implementations from data-layer-generator and use-case-generator
- Feeds: coordinator-navigator, view-generator previews, test-generator

## Rules

- Always one composition root. Never a second container, never a global service locator.
- Always constructor injection. Never property injection, never `@Environment` for domain services.
- Never expose concrete types from factories. Return the protocol.
- Never instantiate a domain or data type outside `Core/DI/`, previews or tests.
- Never stub a missing implementation. Redirect.
- Never use em dashes in any output file.
````

# skills/test-generator/SKILL.md

````markdown
---
name: test-generator
description: >
  Generate unit tests (Swift Testing) for use cases, business rules, mappers, ViewModels and coordinators, plus UI tests (XCTest) for critical user flows, with hand-written mocks, one test file per type, under Tests/. Use this skill whenever the user says "generate tests", "write tests for", "unit test", "UI test", "cover this", "mock for", "test coverage", "génère les tests", "écris les tests", "test unitaire", "test UI", "couvre ce code", "mock pour", or at the end of every feature-builder run. Requires ios-project-foundation and the code under test.
---

# Test Generator

## Prerequisites check

Check for `Docs/conventions.md` and `Docs/file-map.md`. If missing, say:

> Tests follow the project conventions. Run ios-project-foundation first.

Then stop. If present, read both, plus `Docs/domain-model.md` (rules table) and `Docs/Features/*.md` (acceptance criteria). Go straight to Step 1.

## Step 1. Scope

Call AskUserQuestion:

```json
[
  {
    "question": "What to test?",
    "header": "Scope",
    "multiSelect": false,
    "options": [
      {"label": "One feature", "description": "Every use case, rule, mapper, ViewModel and flow of one feature"},
      {"label": "One type", "description": "I will name it"},
      {"label": "Uncovered only", "description": "Every type in file-map.md without a matching <Type>Tests file"},
      {"label": "UI flows", "description": "XCTest UI tests for the P0 user flows in Docs/product.md"}
    ]
  }
]
```

Search `Tests/` and `file-map.md` for existing `<Type>Tests` and `Mock<Protocol>`. Existing tests are extended, never rewritten. Existing mocks are reused.

## Step 2. Plan the cases

Present a case table before writing:

```
CreateInvoiceUseCaseTests
| Case | Given | When | Then | Rule / AC |
|---|---|---|---|---|
| creates draft with computed total | client exists, 2 lines, 20% VAT | execute | invoice.status == .draft, total == 120.00 | R-02 |
| throws when client missing | clients.fetch throws notFound | execute | throws InvoiceError.clientNotFound | AC-3 |
| does not save on failure | repository.save throws | execute | throws, saveCallCount == 1, no partial state | AC-4 |
```

Sources for cases:
- Every rule ID in the `## Business rules` table gets at least one test
- Every acceptance criterion in the feature spec gets at least one test
- Every `Phase` transition of a ViewModel gets one test
- Every mapper gets a round trip test and a malformed input test
- Every coordinator route gets a test that `navigate(to:)` mutates `path` or `modal` as expected

Call AskUserQuestion to approve. Maximum 3 rounds.

## Step 3. Generate mocks

One mock per protocol in `Tests/UnitTests/Mocks/Mock<Protocol>.swift`:

```swift
// MockInvoiceRepository.swift
// Layer: Tests
// Purpose: Recording mock for InvoiceRepository

import Foundation
@testable import <AppName>

final class MockInvoiceRepository: InvoiceRepository, @unchecked Sendable {
    var fetchAllResult: Result<[Invoice], InvoiceError> = .success([])
    var saveResult: Result<Void, InvoiceError> = .success(())
    private(set) var saveCalls: [Invoice] = []
    private(set) var deleteCalls: [InvoiceID] = []

    func fetchAll() async throws(InvoiceError) -> [Invoice] { try fetchAllResult.get() }
    func fetch(id: InvoiceID) async throws(InvoiceError) -> Invoice {
        guard let found = try fetchAllResult.get().first(where: { $0.id == id }) else { throw .notFound(id) }
        return found
    }
    func save(_ invoice: Invoice) async throws(InvoiceError) { saveCalls.append(invoice); try saveResult.get() }
    func delete(id: InvoiceID) async throws(InvoiceError) { deleteCalls.append(id) }
}
```

Mocks record calls and return configurable results. No logic. No third-party mocking library.

Fixtures: `Tests/UnitTests/Fixtures/<Entity>+Fixture.swift` with `static func fixture(...)` using sensible defaults, one per entity, reused by previews through `#if DEBUG` when conventions allow.

## Step 4. Generate unit tests

Swift Testing, one file per type, path mirrors the source layer:

```swift
// CreateInvoiceUseCaseTests.swift
// Layer: Tests
// Purpose: R-02 and AC-3, AC-4 of Invoices

import Testing
@testable import <AppName>

@Suite("CreateInvoiceUseCase")
struct CreateInvoiceUseCaseTests {
    private let invoices = MockInvoiceRepository()
    private let clients = MockClientRepository()

    private func makeSUT() -> DefaultCreateInvoiceUseCase {
        DefaultCreateInvoiceUseCase(invoices: invoices, clients: clients, calculator: InvoiceTotalCalculator())
    }

    @Test("creates a draft with the computed total (R-02)")
    func createsDraft() async throws {
        clients.fetchResult = .success(.fixture())
        let sut = makeSUT()

        let invoice = try await sut.execute(.fixture(vatRate: .percent(20)))

        #expect(invoice.status == .draft)
        #expect(invoice.total == Money(120, currency: .eur))
        #expect(invoices.saveCalls.count == 1)
    }

    @Test("throws when the client does not exist (AC-3)")
    func throwsWhenClientMissing() async {
        clients.fetchResult = .failure(.notFound(.fixture))
        let sut = makeSUT()

        await #expect(throws: InvoiceError.clientNotFound) {
            try await sut.execute(.fixture())
        }
        #expect(invoices.saveCalls.isEmpty)
    }
}
```

ViewModel tests run with `@MainActor` on the suite and assert `phase` after each action. Coordinator tests assert `path.count` and `modal`.

Test rules:
- Arrange, act, assert with blank lines between. One behaviour per test.
- Test names describe behaviour and cite the rule or AC ID.
- No sleeping, no timers. Async is awaited.
- No test touches the network, the disk or the keychain. `AppEnvironment.test` only.

## Step 5. Generate UI tests

XCTest, `Tests/UITests/<Flow>UITests.swift`, one class per P0 flow from `product.md`. Use accessibility identifiers set by view-generator (`ds.<screen>.<element>`). If identifiers are missing, list them and redirect to view-generator before writing the test. Launch with `-uiTesting` argument so the app uses `AppEnvironment.test` seeded data.

## Step 6. Register and hand off

Append every file to `Docs/file-map.md`. Add a `## Test coverage` section to `Docs/Features/<Name>.md` listing rule IDs and AC IDs covered.

Tell the user:

> [n] test files, [n] mocks, [n] fixtures generated. Run `xcodebuild test -scheme <AppName>` or the Xcode test navigator. Say "audit the layers" to finish the feature with layer-auditor.

## What this skill produces

1. `Tests/UnitTests/<Layer>/<Feature>/<Type>Tests.swift`
2. `Tests/UnitTests/Mocks/Mock<Protocol>.swift`
3. `Tests/UnitTests/Fixtures/<Entity>+Fixture.swift`
4. `Tests/UITests/<Flow>UITests.swift`

## Dependencies

- Requires: `Docs/conventions.md`, `Docs/file-map.md`, the code under test
- Reads: `Docs/domain-model.md` rules table, `Docs/Features/*.md` acceptance criteria
- Feeds: feature-builder completion gate

## Rules

- Always one test file per type, mirroring the source path.
- Always cite the rule or AC ID in the test name.
- Never use a mocking library. Hand-written recording mocks only.
- Never rewrite an existing test file. Append cases.
- Never touch network, disk or keychain in unit tests.
- Never use em dashes in any output file.
````

# skills/layer-auditor/SKILL.md

````markdown
---
name: layer-auditor
description: >
  Verify total consistency between layers and documentation: every import respects the dependency direction, every protocol has one implementation registered in the container, every ViewModel maps every error, every screen in a spec has a View and a ViewModel, every rule has a test, and Docs/file-map.md equals the disk. Produces Docs/audit-<date>.md with a pass or fail verdict. Use this skill whenever the user says "audit the layers", "check consistency", "is the architecture respected", "what is missing", "pre-release check", "review the project", "audite les couches", "vérifie la cohérence", "l'architecture est-elle respectée", "qu'est-ce qui manque", "revue du projet", or as the final gate of feature-builder. Requires ios-project-foundation and architecture-designer.
---

# Layer Auditor

## Prerequisites check

Check for `Docs/conventions.md`, `Docs/architecture.md` and `Docs/file-map.md`. If missing, say:

> The audit checks code against architecture.md and conventions.md. Run the foundation skills first.

Then stop. If present, read all three plus `Docs/domain-model.md`, `Docs/design-system.md`, every `Docs/Features/*.md`. Go straight to Step 1.

## Step 1. Scope

Call AskUserQuestion:

```json
[
  {
    "question": "Audit scope?",
    "header": "Scope",
    "multiSelect": false,
    "options": [
      {"label": "Whole project", "description": "Every check, every file"},
      {"label": "One feature", "description": "Vertical slice from spec to tests"},
      {"label": "Docs versus disk", "description": "Only file-map.md synchronisation"}
    ]
  }
]
```

## Step 2. Run the checks

Each check produces pass, warn or fail with a list of offenders.

**C1. Dependency direction**
Grep every file's imports. Domain: only Foundation. Data: never SwiftUI, never a Features type. Presentation: never a Data type (`Impl`, `DTO`, `DataSource`, `Model` @Model). DesignSystem: never Domain, never Features. Fail on any violation.

**C2. One type per file, name equals file**
Parse top-level declarations. Fail on mismatch.

**C3. Protocol coverage**
Every `Repository`, `UseCase`, `DataSource`, `Navigating` protocol has exactly one non-mock implementation and one factory or property in `Core/DI/`. Warn on zero implementations, fail on two.

**C4. Spec to code**
For each `Docs/Features/<Name>.md`, every screen listed has `<Screen>View.swift` and `<Screen>ViewModel.swift` in file-map.md, every entity listed exists in `Domain/Entities/`, every acceptance criterion ID appears in at least one test name. Fail on missing view or viewmodel, warn on missing test.

**C5. Rules to tests**
Every rule ID in the `## Business rules` table appears in at least one test name. Warn on gaps.

**C6. Error mapping**
Every `case` of every domain error enum is handled in at least one ViewModel `message(for:)` or equivalent, or falls into a documented default. Warn on unmapped cases.

**C7. Navigation**
Every `<Feature>Route` case is handled in `view(for:)`. Every `navigate(to:)` call in ViewModels targets an existing case. No `NavigationLink(destination:)` anywhere in Features. Fail on any.

**C8. Design system**
No `Color(red:`, `Color(hex:`, `.font(.system(size:`, or numeric padding literals in Features or DesignSystem/Components. Warn.

**C9. Safety**
No `!` force unwrap on optionals outside tests and previews, no `try!`, no `as!`, no `fatalError` outside preconditions in `AppEnvironment`. Fail.

**C10. Registry**
file-map.md rows equal the set of `.swift` files on disk, minus build artefacts. Fail on drift, and list both directions.

**C11. Dead documentation**
Every ADR referenced in code comments exists. Every feature spec with `Status: specified` older than the newest code file in its folder is flagged as possibly stale. Warn.

## Step 3. Write the report

`Docs/audit-<YYYY-MM-DD>.md`:

```
# Audit <date>

Scope: <scope>
Verdict: PASS | FAIL (<n> fails, <n> warns)

| Check | Result | Offenders |
|---|---|---|
| C1 Dependency direction | pass | |
| C3 Protocol coverage | fail | ClientRepository: no implementation |
| ... | | |

## Fix plan
[Ordered list: offender, responsible skill, one-line action]
1. ClientRepository has no implementation → data-layer-generator → "generate the data layer for Clients"
2. AC-4 of Invoices untested → test-generator → "generate tests for CreateInvoiceUseCase"
```

Register the report in `Docs/file-map.md` with Layer `Docs`.

## Step 4. Offer fixes

Call AskUserQuestion:

```json
[
  {
    "question": "Next?",
    "header": "Fix",
    "multiSelect": false,
    "options": [
      {"label": "Fix C10 now", "description": "Synchronise file-map.md with disk immediately"},
      {"label": "Walk the fix plan", "description": "Trigger each responsible skill in order"},
      {"label": "Stop here", "description": "I will handle it"}
    ]
  }
]
```

C10 is the only check this skill fixes itself. Everything else is delegated to the responsible skill by name. Never patch code from the auditor.

## Step 5. Hand off

Tell the user:

> Audit written to Docs/audit-<date>.md. Verdict: [PASS | FAIL]. [n] items in the fix plan, each mapped to the skill that owns it.

## What this skill produces

1. `Docs/audit-<date>.md` with verdict, table and ordered fix plan
2. Optionally, a synchronised `Docs/file-map.md`

## Dependencies

- Requires: `Docs/conventions.md`, `Docs/architecture.md`, `Docs/file-map.md`
- Reads: `Docs/domain-model.md`, `Docs/design-system.md`, `Docs/Features/*.md`
- Delegates to: every generator skill, code-deduplicator

## Rules

- Always run every check in scope. Never skip a check because it is slow.
- Always name the responsible skill for every offender.
- Never edit source code from this skill. Only file-map.md.
- A FAIL verdict blocks feature-builder from declaring a feature done.
- Never use em dashes in any output file.
````

# skills/feature-builder/SKILL.md

````markdown
---
name: feature-builder
description: >
  Orchestrate every iOS skill to deliver one feature end to end: spec, domain, rules, use cases, data, DI, ViewModels, views, navigation, tests, deduplication and audit, in the only valid order, with a gate between each stage. Use this skill whenever the user says "build feature [name]", "implement [name] end to end", "ship the [name] feature", "full feature", "from spec to tests", "construis la fonctionnalité", "implémente [nom] de bout en bout", "livre la feature", "feature complète", or names a feature from Docs/product.md and wants it done. Requires ios-project-foundation and architecture-designer. Every other skill is invoked as a stage.
---

# Feature Builder

## CRITICAL: Auto-start on load

When this skill triggers, go straight to Step 1. Do not summarise the pipeline. Do not list the stages. Start immediately.

## Prerequisites check

Check for `Docs/conventions.md`, `Docs/architecture.md`, `Docs/design-system.md` and `Core/DI/AppContainer.swift`. For each missing item, name the skill that produces it:

> feature-builder needs: [conventions.md → ios-project-foundation] [architecture.md → architecture-designer] [design-system.md → ui-ux-designer] [AppContainer.swift → dependency-injector bootstrap]. Run those first.

Then stop. If all present, read `conventions.md`, `architecture.md` and `file-map.md`. Go to Step 1.

## Step 1. Pick the feature

If the user named a feature, look for `Docs/Features/<Name>.md`. Otherwise call AskUserQuestion listing every feature from `Docs/product.md` whose Status is not `done`, sorted by priority then dependency order, as the options. If `product.md` is missing, ask the user to describe the feature in chat and run product-conception in one-feature mode first.

Read the feature spec. Check `Depends on`. If a dependency feature is not `Status: done`, stop:

> <Name> depends on <Other>, which is not done. Build <Other> first, or say "ignore dependency" to proceed with stubs.

Create or update `Docs/Features/<Name>.md` with a `## Build log` section:

```
## Build log
| Stage | Skill | Status | Files |
|---|---|---|---|
| 1 Spec | product-conception | pending | |
| 2 Domain | domain-modeler | pending | |
| 3 Rules | business-logic-engine | pending | |
| 4 Use cases | use-case-generator | pending | |
| 5 Data | data-layer-generator | pending | |
| 6 DI | dependency-injector | pending | |
| 7 ViewModels | viewmodel-generator | pending | |
| 8 Components | swiftui-component-library | pending | |
| 9 Views | view-generator | pending | |
| 10 Navigation | coordinator-navigator | pending | |
| 11 Tests | test-generator | pending | |
| 12 Dedupe | code-deduplicator | pending | |
| 13 Audit | layer-auditor | pending | |
```

## Step 2. Run the pipeline

Run the stages in this exact order. For every stage:

1. Announce the stage in one line: `Stage 4/13: use-case-generator for Invoices.`
2. Invoke the skill by following its SKILL.md with the feature pre-selected (answer its scope question with this feature, do not ask the user again).
3. The skill's own approval gates still apply. Wait for the user at each of them.
4. When the skill hands off, update the Build log row: `done` and the list of files created.
5. If the skill redirects to another skill (for example, viewmodel-generator finds a missing use case), run that skill inline for the missing piece, log it as a sub-stage `4a`, then resume.
6. If a stage fails or the user says "stop", mark the row `blocked` with the reason and stop the pipeline. The feature stays `Status: in progress`.

Stage rules:
- Stage 1 is skipped if the spec already has acceptance criteria. Log `skipped: spec exists`.
- Stage 3 is skipped if the spec's acceptance criteria contain no rule beyond CRUD. Log `skipped: no rules`.
- Stage 5 uses the data sources declared for this feature in `architecture.md`. Never ask again.
- Stage 8 runs only for components that view-generator's plan needs and that are missing from `DesignSystem/Components/`. Run stage 9's Step 2 first to get the list, then stage 8, then the rest of stage 9.
- Stage 12 runs in "One feature" scope.
- Stage 13 runs in "One feature" scope. A FAIL verdict sends the pipeline back to the responsible stage. Maximum 2 loops, then stop and report.

## Step 3. Gate between stages

After each stage, call AskUserQuestion:

```json
[
  {
    "question": "Stage <n> done. Continue?",
    "header": "Gate",
    "multiSelect": false,
    "options": [
      {"label": "Continue", "description": "Run stage <n+1>"},
      {"label": "Review files first", "description": "Show me what was created before moving on"},
      {"label": "Stop here", "description": "Pause the pipeline, resume later with the same command"}
    ]
  }
]
```

The pipeline is resumable: on a later run for the same feature, read the Build log and start at the first row that is not `done` or `skipped`.

## Step 4. Close the feature

When stage 13 returns PASS:

1. Set `Status: done` in `Docs/Features/<Name>.md`.
2. Update the feature row in `Docs/product.md` to `done`.
3. Append a `## Delivered` section to the spec: screens, use cases, rules, tests count, files count.
4. If a build command is available, run it and run the tests. Report the result verbatim.

Tell the user:

> Feature <Name> delivered. [n] files, [n] tests, audit PASS. Docs/Features/<Name>.md has the full build log.
>
> Next: say "build feature [next P0 name]" to continue, or "audit the layers" for a whole-project check.

## What this skill produces

1. Every artefact of every stage skill for one feature
2. A complete `## Build log` and `## Delivered` section in `Docs/Features/<Name>.md`
3. Updated `Docs/product.md` status

## Dependencies

- Requires: ios-project-foundation, architecture-designer, ui-ux-designer, dependency-injector bootstrap
- Invokes, in order: product-conception, domain-modeler, business-logic-engine, use-case-generator, data-layer-generator, dependency-injector, viewmodel-generator, swiftui-component-library, view-generator, coordinator-navigator, test-generator, code-deduplicator, layer-auditor
- May invoke on redirect: swift-coder, file-structure-organizer

## Rules

- Always run stages in the listed order. Never generate a View before its ViewModel, never a ViewModel before its use cases, never a use case before its entities.
- Always respect each stage skill's own approval gates. The orchestrator never auto-approves.
- Always log every stage, including skipped and blocked, in the Build log.
- Never declare a feature done without a PASS from layer-auditor.
- Never ask a question a stage skill already answered from the spec or architecture.
- Never use em dashes in any output file.
````

# skills/ios-project-foundation/references/conventions-template.md

````markdown
# Conventions

Single source of truth for this project. Every skill reads this file before generating code. If code disagrees with this file, the code is wrong.

## Targets
- Minimum iOS: [version]
- Swift: [version], strict concurrency: [complete | minimal]
- Xcode: [version]
- Observation: [@Observable | ObservableObject]

## Architecture
- Pattern: MVVM in the Presentation layer, Clean Architecture across three layers.
- Layers and the only allowed dependency direction:
  - Presentation depends on Domain
  - Data depends on Domain
  - Domain depends on nothing (no UIKit, no SwiftUI, no Foundation networking, no SwiftData)
- Navigation: Coordinators. Views never push other views. Views emit intents, coordinators decide.
- Dependency injection: constructor injection. One `AppContainer` in `Core/DI/`. No global singletons except `AppContainer.shared` used only at the composition root.
- Concurrency: async/await only. No Combine. No completion handlers. Every ViewModel is `@MainActor`.

## Folder layout
```
App/                 entry point, AppDelegate, Info.plist, Resources/
Core/                DI/, Navigation/, Extensions/, Utilities/
DesignSystem/        Tokens/, Components/, Modifiers/
Domain/              Entities/, ValueObjects/, Repositories/, UseCases/, Errors/
Data/                Repositories/, DataSources/Remote/, DataSources/Local/, DTOs/, Mappers/
Features/<Name>/     Presentation/Views/, Presentation/ViewModels/, Presentation/Components/, Coordinator/
Tests/               UnitTests/<Layer>/, UITests/
Docs/                project-brief.md, conventions.md, architecture.md, domain-model.md, design-system.md, file-map.md, Features/
```
- Domain and Data are grouped by feature inside each subfolder: `Domain/UseCases/<Feature>/`, `Data/Repositories/<Feature>/`.
- Feature-only UI components live in `Features/<Name>/Presentation/Components/`. If a component is used by two features, it moves to `DesignSystem/Components/`.

## Naming
| Thing | Rule | Example |
|---|---|---|
| Entity | Noun, no suffix | `Invoice` |
| Value object | Noun, no suffix | `Money` |
| Repository protocol | `<Noun>Repository` | `InvoiceRepository` |
| Repository impl | `<Noun>RepositoryImpl` | `InvoiceRepositoryImpl` |
| Use case protocol | `<Verb><Noun>UseCase` | `CreateInvoiceUseCase` |
| Use case impl | `Default<Verb><Noun>UseCase` | `DefaultCreateInvoiceUseCase` |
| Data source | `<Noun><Remote|Local>DataSource` | `InvoiceRemoteDataSource` |
| DTO | `<Noun>DTO` | `InvoiceDTO` |
| Mapper | `<Noun>Mapper` | `InvoiceMapper` |
| ViewModel | `<Screen>ViewModel` | `InvoiceListViewModel` |
| View | `<Screen>View` | `InvoiceListView` |
| Coordinator | `<Feature>Coordinator` | `InvoicesCoordinator` |
| Route enum | `<Feature>Route` | `InvoicesRoute` |
| Domain error | `<Noun>Error` | `InvoiceError` |
| Test | `<TypeUnderTest>Tests` | `CreateInvoiceUseCaseTests` |
| Mock | `Mock<Protocol>` | `MockInvoiceRepository` |

## File rules
- One top-level type per file. File name equals type name. `InvoiceListViewModel.swift` contains `InvoiceListViewModel` and nothing else.
- Extensions of a type live in `<Type>+<Concern>.swift` next to the type.
- No file over 300 lines. Split by concern.
- No `Utils.swift`, `Helpers.swift`, `Extensions.swift` catch-all files.
- Every new file is registered in `Docs/file-map.md`.

## Code style
- Access control: [strict | default]. Default to `private` and widen only when needed.
- Every dependency is a protocol. Concrete types are injected, never instantiated inside a consumer.
- Use cases expose one `execute` method.
- ViewModels expose state as stored properties and actions as methods. No `@Published` unless ObservableObject mode.
- Views are dumb: read state, call actions, render. No business logic, no formatting logic beyond presentation.
- No force unwrap. No `try!`. No `as!`.
- Errors: typed domain errors. Never `Error` alone at a public boundary.
- Strings: [String Catalog only | hardcoded allowed]. No user-facing string literal in a View if catalog mode.
- No `TODO` left in generated code. Unfinished work goes in Docs/Features/<name>.md.

## Testing
- Unit tests: Swift Testing (`@Test`, `#expect`). One test file per type.
- UI tests: XCTest. One test class per critical user flow.
- Every use case has a test. Every ViewModel has a test. Every mapper has a test.
- Mocks are hand-written, live in `Tests/UnitTests/Mocks/`, one per protocol.

## Dependencies
- Policy: [zero | minimal | pragmatic]
- Allowed packages: [list or "none"]

## Localisation
- [String Catalog from day one | English only for v1]
- Base language: [en | fr]
````
