# Versions

## 1.0.0 — 2026-08-29

Initial release. 19 skills covering the full iOS delivery pipeline.

**Foundation**
- ios-project-foundation

**Product and architecture**
- product-conception
- architecture-designer
- file-structure-organizer

**Domain**
- domain-modeler
- business-logic-engine
- use-case-generator

**Data**
- data-layer-generator

**Presentation**
- viewmodel-generator
- view-generator
- coordinator-navigator

**Design**
- ui-ux-designer
- swiftui-component-library

**Implementation and quality**
- swift-coder
- code-deduplicator
- dependency-injector
- test-generator
- layer-auditor

**Orchestration**
- feature-builder
