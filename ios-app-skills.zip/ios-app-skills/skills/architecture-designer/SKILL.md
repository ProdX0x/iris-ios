---
name: architecture-designer
description: >
  Design the technical architecture of the iOS app: layer boundaries, module map, data flow, navigation topology, dependency graph and every technical decision recorded as an ADR. Produces Docs/architecture.md with text diagrams. Use this skill whenever the user says "design the architecture", "how should I structure this app", "architecture decisions", "which pattern for", "MVVM setup", "clean architecture for this app", "conçois l'architecture", "structure de l'app", "décisions techniques", "quel pattern", or before any code is written on a new project. Requires ios-project-foundation. Reads Docs/product.md if present.
---

# Architecture Designer

## Prerequisites check

Check for `Docs/project-brief.md` and `Docs/conventions.md`. If missing, say:

> Architecture needs the foundation. Say "set up my iOS project" first.

Then stop.

If present, read both. Read `Docs/product.md` and every `Docs/Features/*.md` if they exist. If `Docs/architecture.md` already exists, read it and go to Step 6 (amend mode). Otherwise go straight to Step 1.

## Step 1. Gather constraints

Call AskUserQuestion:

```json
[
  {
    "question": "Modularisation level?",
    "header": "Modules",
    "multiSelect": false,
    "options": [
      {"label": "Single target, folder layers", "description": "One app target, layers enforced by folders and conventions. Fastest to iterate."},
      {"label": "SPM local packages per layer", "description": "Domain, Data, DesignSystem as local packages. Compiler-enforced boundaries."},
      {"label": "SPM packages per feature", "description": "Each feature its own package. For teams of 3+."}
    ]
  },
  {
    "question": "Persistence engine?",
    "header": "Storage",
    "multiSelect": false,
    "options": [
      {"label": "SwiftData", "description": "iOS 17+, @Model, CloudKit ready"},
      {"label": "Core Data", "description": "Broad compatibility"},
      {"label": "Files or UserDefaults", "description": "Small state only"},
      {"label": "None", "description": "Stateless or remote only"}
    ]
  },
  {
    "question": "Navigation complexity?",
    "header": "Navigation",
    "multiSelect": false,
    "options": [
      {"label": "Single stack", "description": "One NavigationStack, linear flows"},
      {"label": "Tabs with stacks", "description": "TabView, one stack per tab"},
      {"label": "Deep links and modals", "description": "Tabs, sheets, full screen covers, URL routing"}
    ]
  }
]
```

If `product.md` is missing, also ask the user to list the 3 to 5 main features in chat.

## Step 2. Draw the layer diagram

Produce the layer diagram in a plain code block. Adapt names to this project. The arrows are the only allowed dependencies.

```
┌─────────────────────────────────────────────────────────────┐
│  App                                                        │
│  <AppName>App.swift  ·  AppContainer (composition root)     │
└───────────────────────────┬─────────────────────────────────┘
                            │ builds
┌───────────────────────────▼─────────────────────────────────┐
│  Presentation (MVVM)                                        │
│  Features/<Name>/  Views → ViewModels → Coordinators        │
│  DesignSystem/     Tokens, Components, Modifiers            │
└───────────────────────────┬─────────────────────────────────┘
                            │ depends on
┌───────────────────────────▼─────────────────────────────────┐
│  Domain (pure Swift)                                        │
│  Entities · ValueObjects · UseCases · Repository protocols  │
└───────────────────────────▲─────────────────────────────────┘
                            │ implements
┌───────────────────────────┴─────────────────────────────────┐
│  Data                                                       │
│  RepositoryImpl · Remote/Local DataSources · DTOs · Mappers │
└─────────────────────────────────────────────────────────────┘
```

## Step 3. Map features to modules

For every feature in `product.md`, produce one block:

```
Feature: <Name>
  Screens:        <ViewA>, <ViewB>
  ViewModels:     <ViewA>ViewModel, <ViewB>ViewModel
  Coordinator:    <Name>Coordinator, routes: [.list, .detail(id), .create]
  Use cases:      Fetch<Noun>sUseCase, Create<Noun>UseCase
  Repositories:   <Noun>Repository (protocol) ← <Noun>RepositoryImpl
  Data sources:   <Noun>RemoteDataSource, <Noun>LocalDataSource
  Entities:       <Noun>
  Cross-feature:  reads <OtherNoun> via <OtherNoun>Repository (never via another feature's ViewModel)
```

Detect shared entities: any entity used by two or more features is flagged `[shared]` and must be owned by exactly one feature folder in Domain. Record the owner.

## Step 4. Draw the navigation and data flow

**Navigation topology** as a text tree:

```
AppCoordinator
├── Tab: <TabName> → <Feature>Coordinator
│   ├── <ListView>
│   └── <DetailView>(id)
├── Tab: ...
└── Modal: <OnboardingCoordinator> (presented once)
```

**One data flow** end to end, for the most important P0 feature:

```
User tap
 → <View>.onTapGesture calls viewModel.load()
 → <ViewModel>.load() calls fetchUseCase.execute()
 → Default<Fetch>UseCase calls repository.fetchAll()
 → <RepositoryImpl> calls remoteDataSource.fetch() then localDataSource.save()
 → <Mapper>.toDomain(dto) returns [<Entity>]
 → ViewModel sets state = .loaded(items)
 → View re-renders
```

## Step 5. Record decisions and write Docs/architecture.md

Every choice is an ADR. Minimum set: modularisation, persistence, networking, navigation, DI, concurrency, error handling, localisation, testing strategy. Format:

```
### ADR-<n>: <Title>
Status: accepted
Context: [one or two sentences]
Decision: [one sentence]
Consequences: [what this forces, what it forbids]
```

Write `Docs/architecture.md`:

```
# Architecture

## Overview
[3 sentences: pattern, layers, modularisation level]

## Layer diagram
[Step 2 block]

## Feature map
[Step 3 blocks]

## Navigation topology
[Step 4 tree]

## Reference data flow
[Step 4 flow]

## Dependency graph
[Text list: which concrete type is injected where. AppContainer builds X with Y and Z.]

## Decisions
[All ADRs]

## Forbidden
[Explicit list: Views importing Data, Domain importing SwiftUI, ViewModels calling other ViewModels, singletons outside AppContainer, and anything project-specific]
```

Register the file in `Docs/file-map.md`. Update the Architecture section of `Docs/conventions.md` only if a decision changed something there (for example ObservableObject mode). Never rewrite conventions.md wholesale.

## Step 6. Amend mode

If `architecture.md` existed, ask what changed. Add a new ADR with Status `accepted` and mark the superseded ADR as `superseded by ADR-<n>`. Never delete an ADR. Update only the affected diagram sections.

## Step 7. Hand off

Tell the user:

> Architecture is written in Docs/architecture.md with [n] decisions recorded.
>
> Next: say "generate the file structure" to run file-structure-organizer, which turns this into real folders and stub files. Or say "build feature [name]" to run feature-builder.

## What this skill produces

1. `Docs/architecture.md`: diagrams, feature map, navigation, data flow, ADRs, forbidden list

## Dependencies

- Requires: `Docs/project-brief.md`, `Docs/conventions.md`
- Reads if present: `Docs/product.md`, `Docs/Features/*.md`
- Feeds: file-structure-organizer, domain-modeler, coordinator-navigator, dependency-injector

## Rules

- Always produce diagrams in plain code blocks. Never as images.
- Always record every choice as an ADR. A decision not written down does not exist.
- Never introduce a fourth layer. Domain, Data, Presentation, plus App and Core as infrastructure.
- Never let a feature depend on another feature's Presentation. Cross-feature access goes through Domain.
- Never contradict conventions.md. If a decision requires changing it, say so explicitly and edit only that section.
- Never propose a third-party package if the dependency policy in project-brief.md is "zero".
- Never use em dashes in any output file.
