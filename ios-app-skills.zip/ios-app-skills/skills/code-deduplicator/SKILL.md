---
name: code-deduplicator
description: >
  Detect and eliminate duplicated code and dead code across the project: identical or near-identical functions, repeated view fragments, parallel types, unused files, unreferenced symbols. Factorises into the correct layer, deletes what is dead, and keeps Docs/file-map.md truthful. Use this skill whenever the user says "dedupe", "find duplicates", "remove dead code", "clean up", "factorise", "this looks copied", "unused files", "déduplique", "trouve les doublons", "supprime le code mort", "nettoie", "factorise", "fichiers inutilisés", or at the end of every feature-builder run. Requires ios-project-foundation.
---

# Code Deduplicator

## Prerequisites check

Check for `Docs/conventions.md` and `Docs/file-map.md`. If missing, say:

> Deduplication works against the file map. Run ios-project-foundation first.

Then stop. If present, read both. Go straight to Step 1.

## Step 1. Scope

Call AskUserQuestion:

```json
[
  {
    "question": "Where to look?",
    "header": "Scope",
    "multiSelect": false,
    "options": [
      {"label": "Whole project", "description": "Every .swift file"},
      {"label": "One feature", "description": "Features/<Name> plus its Domain and Data folders"},
      {"label": "One layer", "description": "Domain, Data, Presentation or DesignSystem"},
      {"label": "Since last run", "description": "Files changed after the last entry in Docs/dedup-log.md"}
    ]
  }
]
```

## Step 2. Scan

Run four passes and collect findings. Use grep, ripgrep or a script in `scripts/` if the project is large.

**Pass A. Exact and near duplicates**
- Functions with identical bodies modulo whitespace and identifier names
- View bodies with the same modifier chain and structure
- Types with the same stored properties under different names (`InvoiceRowItem` vs `InvoiceCellModel`)
- Extensions declaring the same helper on the same type in two files

**Pass B. Semantic duplicates**
- Two mappers converting the same pair of types
- Two error to message tables for the same error enum
- Formatting logic (dates, money, percentages) implemented in more than one place
- Validation of the same value object in a ViewModel and in Domain

**Pass C. Dead code**
- Files in `file-map.md` that no longer exist on disk, and files on disk absent from `file-map.md`
- Types with zero references outside their own file (excluding App entry, previews, tests)
- Functions, properties, parameters and imports never used
- Feature folders whose spec is `Status: cut` in `Docs/product.md`
- Commented-out code blocks over 5 lines

**Pass D. Layer leaks that create duplication**
- A rule implemented in Domain and again in a ViewModel guard
- A DTO used directly by a View instead of the entity

## Step 3. Report

Output one table before changing anything:

```
| ID | Kind | Location A | Location B | Proposed action | Target layer |
|---|---|---|---|---|---|
| D-01 | near duplicate | InvoiceListViewModel.swift:88 | InvoiceDetailViewModel.swift:61 | extract InvoiceError+Message.swift | Presentation |
| D-02 | semantic | Invoice+Formatting.swift | InvoiceRow.swift:22 | keep Domain? no, move to InvoiceRowItem | Presentation |
| X-01 | dead file | Core/Utilities/Legacy.swift | | delete | |
| X-02 | unused func | InvoiceMapper.swift:40 toLegacyDTO | | delete | |
```

Target layer follows conventions.md:
- Formatting for display: Presentation model (`<Screen>+Models.swift`)
- Rule or calculation: Domain (business-logic-engine owns it, redirect if new)
- Generic view fragment: DesignSystem (swiftui-component-library owns it, redirect if it needs design)
- Generic Swift helper on a Foundation type: `Core/Extensions/<Type>+<Concern>.swift`, one concern per file, never a catch-all

Call AskUserQuestion with three options: apply all, choose by ID, cancel. Wait.

## Step 4. Apply

For each approved item:
1. Create the single canonical implementation at the target path (or reuse the surviving one).
2. Replace every duplicate call site with a call to the canonical one. Show before and after per site.
3. Delete the duplicate definitions and dead files with `git rm` when in a git repo.
4. Update `Docs/file-map.md`: add the canonical file, remove deleted files.
5. If tests exist for a deleted symbol, delete or redirect them and say so.

Build check: if a build command is available (`xcodebuild` or `swift build`), run it. If not, list every touched file so the user can build.

## Step 5. Log

Append to `Docs/dedup-log.md` (create with a title if absent):

```
## <date>
Scope: <scope>
Applied: D-01, D-02, X-01
Skipped: X-02 (user kept it)
Files touched: <n>. Lines removed: <n>.
```

## Step 6. Hand off

Tell the user:

> Removed [n] duplicates and [n] dead items. file-map.md is in sync with disk. Say "generate tests" to cover the factorised code, or "audit the layers" to run layer-auditor.

## What this skill produces

1. Factorised canonical implementations in the correct layer
2. Deleted duplicate and dead code
3. `Docs/dedup-log.md` entry and a synchronised `Docs/file-map.md`

## Dependencies

- Requires: `Docs/conventions.md`, `Docs/file-map.md`
- May redirect to: business-logic-engine, swiftui-component-library
- Feeds: test-generator, layer-auditor

## Rules

- Always report the full table and get approval before deleting anything.
- Never factorise into a catch-all file. One concern per file.
- Never move a rule into Presentation to make deduplication easier. Domain wins.
- Never delete a file referenced by the Xcode project without stating that the reference must be removed.
- Always keep file-map.md equal to the disk after the run.
- Never use em dashes in any output file.
