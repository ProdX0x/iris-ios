---
name: domain-modeler
description: >
  Model the Domain layer: entities, value objects, invariants, typed errors and repository protocols, as pure Swift with no framework imports. Produces Docs/domain-model.md plus one file per type under Domain/. Use this skill whenever the user says "model the domain", "define the entities", "what are the models", "create the data model", "domain layer", "value objects", "repository protocol", "modélise le domaine", "définis les entités", "crée les modèles", "couche domaine", or when any skill needs an entity that does not exist yet. Requires ios-project-foundation. Reads Docs/Features/*.md and Docs/architecture.md.
---

# Domain Modeler

## Prerequisites check

Check for `Docs/conventions.md` and `Docs/file-map.md`. If missing, say:

> Domain modelling needs the foundation. Say "set up my iOS project" first.

Then stop. If present, read both, then read `Docs/architecture.md`, every `Docs/Features/*.md` and `Docs/domain-model.md` if they exist. Go straight to Step 1.

## Step 1. Scope the modelling

Call AskUserQuestion:

```json
[
  {
    "question": "What should I model?",
    "header": "Scope",
    "multiSelect": false,
    "options": [
      {"label": "Whole product", "description": "Every entity named across Docs/Features/*.md"},
      {"label": "One feature", "description": "Only the entities of one feature spec"},
      {"label": "One entity", "description": "I will describe it in chat"}
    ]
  }
]
```

Collect the entity names from the chosen scope. Before designing anything, search `Docs/file-map.md` and `Domain/Entities/` for each name. Split the list into `existing` and `new`. Existing entities are read, never regenerated. Only extend them if a feature spec needs a field they lack, and say so.

## Step 2. Design each entity

For every new entity, decide and write in chat:

| Aspect | Rule |
|---|---|
| Kind | `struct` by default. `final class` only with a written reason (identity semantics, reference sharing). |
| Identity | `let id: <Entity>ID` where `<Entity>ID` is a typed wrapper around UUID or String. Never bare `UUID` as a field type. |
| Fields | Named, typed, minimal. No optional unless absence is a real state. |
| Value objects | Any field with validation rules (email, money, percentage, phone) becomes a value object with a failable or throwing initialiser. |
| Invariants | Rules that must always hold. Enforced in the initialiser or a mutating method. Listed explicitly. |
| Conformances | `Equatable`, `Hashable`, `Sendable`, `Identifiable`. `Codable` only if the entity itself crosses a boundary, otherwise DTOs handle it. |
| Relationships | By ID reference, never by embedding another entity unless composition is intrinsic. |

Flag shared entities (used by two or more features) and assign one owning feature folder.

## Step 3. Design errors and repository protocols

For each feature in scope, one `<Noun>Error` enum in `Domain/Errors/`:

```swift
enum InvoiceError: Error, Equatable, Sendable {
    case notFound(InvoiceID)
    case invalidAmount
    case alreadyPaid
    case storage(underlying: String)
}
```

For each aggregate root, one repository protocol in `Domain/Repositories/<Feature>/`:

```swift
protocol InvoiceRepository: Sendable {
    func fetchAll() async throws(InvoiceError) -> [Invoice]
    func fetch(id: InvoiceID) async throws(InvoiceError) -> Invoice
    func save(_ invoice: Invoice) async throws(InvoiceError)
    func delete(id: InvoiceID) async throws(InvoiceError)
}
```

Use typed throws when Swift 6 is set in conventions.md. Otherwise plain `throws` with the error documented.

Present all entities, value objects, errors and protocols in chat as Swift. Call AskUserQuestion to approve. Iterate, maximum 3 rounds.

## Step 4. Write the files

One file per type, at the path dictated by conventions.md:

- `Domain/Entities/<Feature>/<Entity>.swift`
- `Domain/Entities/<Feature>/<Entity>ID.swift`
- `Domain/ValueObjects/<ValueObject>.swift`
- `Domain/Errors/<Noun>Error.swift`
- `Domain/Repositories/<Feature>/<Noun>Repository.swift`

File header on every file:

```swift
// <Name>.swift
// Layer: Domain
// Purpose: <one line>
```

Only `import Foundation`. Nothing else. Every file must compile alone.

Register each file in `Docs/file-map.md`. If a stub already existed from file-structure-organizer, fill it in place. Never create a sibling.

## Step 5. Write Docs/domain-model.md

```
# Domain Model

## Entities
[One block per entity: name, owning feature, fields with types, invariants, relationships by ID]

## Value objects
[Name, wrapped type, validation rule, example valid and invalid values]

## Errors
[One enum per feature, every case with the situation that raises it]

## Repositories
[One protocol per aggregate, method signatures, which error each can throw]

## Glossary
[Ubiquitous language: every domain word, one definition. Used by every skill to name things identically.]
```

If the file existed, merge: add new sections, update changed ones, never drop existing entries.

## Step 6. Hand off

Tell the user:

> Domain is modelled: [n] entities, [n] value objects, [n] error types, [n] repository protocols. Docs/domain-model.md is the reference.
>
> Next: say "generate the use cases" to run use-case-generator, or "write the business rules" for business-logic-engine.

## What this skill produces

1. Pure Swift files under `Domain/`, one type each
2. `Docs/domain-model.md` with the glossary every other skill uses

## Dependencies

- Requires: `Docs/conventions.md`, `Docs/file-map.md`
- Reads if present: `Docs/architecture.md`, `Docs/Features/*.md`, `Docs/domain-model.md`
- Feeds: use-case-generator, business-logic-engine, data-layer-generator, viewmodel-generator, test-generator

## Rules

- Always search file-map.md and Domain/ before designing an entity. Existing entities are extended, never duplicated.
- Always use typed IDs. Never `UUID` or `String` as an identity field type.
- Never import SwiftUI, UIKit, SwiftData, CoreData, Combine or any networking framework in Domain.
- Never put formatting, persistence or networking concerns in an entity.
- Never make a repository protocol expose DTOs. Domain types only.
- Every value object has at least one documented invalid input.
- Every glossary term is used verbatim by downstream skills. No synonyms.
- Never use em dashes in any output file.
