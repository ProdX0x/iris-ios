---
name: product-conception
description: >
  Turn an app idea into a scoped product definition: user personas, jobs to be done, feature list with priorities, user flows and acceptance criteria. Produces Docs/product.md and one Docs/Features/<name>.md stub per feature. Use this skill whenever the user says "define the product", "scope the app", "what features should this have", "write the product spec", "list the features", "MVP scope", "définis le produit", "cadre les fonctionnalités", "spec produit", "quelles fonctionnalités", or describes an app idea and wants it structured before any architecture or code. Requires ios-project-foundation to have run first.
---

# Product Conception

## Prerequisites check

The moment this skill triggers, check for `Docs/project-brief.md` and `Docs/conventions.md`.

If either is missing, tell the user:

> Product conception builds on the project foundation. Say "set up my iOS project" to run ios-project-foundation first, then come back here.

Then stop.

If both exist, read them fully, then check for `Docs/product.md`. If it exists, read it and go to Step 5 (update mode). Otherwise go straight to Step 1.

## Step 1. Gather the idea

Call AskUserQuestion:

```json
[
  {
    "question": "How much of the product is already decided?",
    "header": "Maturity",
    "multiSelect": false,
    "options": [
      {"label": "Just an idea", "description": "One sentence, help me shape it"},
      {"label": "Rough feature list", "description": "I will paste bullet points"},
      {"label": "Detailed spec", "description": "I will paste a document or notes"},
      {"label": "Existing app", "description": "Reverse-engineer from the codebase"}
    ]
  },
  {
    "question": "Scope target for version 1?",
    "header": "Scope",
    "multiSelect": false,
    "options": [
      {"label": "Tiny MVP", "description": "3 to 5 features, ship in weeks"},
      {"label": "Solid v1", "description": "6 to 10 features"},
      {"label": "Full product", "description": "Everything, phased"}
    ]
  }
]
```

Wait for the paste if applicable. If "Existing app", walk `Features/` and `Domain/UseCases/` and infer the feature list from folder names and use case names.

## Step 2. Define personas and jobs

From the brief and the idea, write:

- 1 to 3 personas. Name, one-line context, primary frustration, success moment.
- For each persona, 2 to 4 jobs to be done in the format: "When [situation], I want to [motivation], so I can [outcome]."

Present them in chat. Call AskUserQuestion to confirm which persona is primary. Do not proceed without confirmation.

## Step 3. Build the feature list

Derive features from the jobs. For each feature produce:

| Field | Rule |
|---|---|
| Name | PascalCase noun, becomes the folder name under `Features/` |
| Job served | Which JTBD it fulfils |
| Priority | P0 (v1 blocker), P1 (v1 nice), P2 (later) |
| Screens | List of screens, each one future View |
| Data touched | Entities read or written |
| Depends on | Other features that must exist first |

Respect the scope from Step 1. Tiny MVP means P0 only, maximum 5 features. Present the table. Call AskUserQuestion:

```json
[
  {
    "question": "Feature list looks right?",
    "header": "Confirm",
    "multiSelect": false,
    "options": [
      {"label": "Approve", "description": "Write the files"},
      {"label": "Cut features", "description": "I will tell you which to remove"},
      {"label": "Add features", "description": "I will tell you what is missing"}
    ]
  }
]
```

Iterate until approved. Maximum 3 rounds.

## Step 4. Write the files

### Docs/product.md

```
# Product

## Personas
[Name: context. Frustration. Success moment.] x1 to 3. Mark the primary one.

## Jobs to be done
[Grouped by persona, "When... I want... so I can..." format]

## Feature list
[The approved table from Step 3, sorted by priority then dependency order]

## User flows
[For each P0 feature: numbered steps from entry point to success state. Max 8 steps each.]

## Out of scope for v1
[Explicit list. Include anything the user mentioned and then cut.]

## Open questions
[Anything unresolved that architecture-designer must decide]
```

### Docs/Features/<Name>.md, one per feature

```
# Feature: <Name>

Status: specified
Priority: <P0|P1|P2>
Depends on: <feature names or none>

## Job
[The JTBD this serves, one line]

## Screens
[One line per screen: ScreenName. What the user sees. What they can do.]

## Acceptance criteria
[Given / When / Then, 3 to 6 criteria]

## Entities
[Entities this feature reads or writes. Names only. domain-modeler owns the definitions.]

## Notes
[Edge cases, platform constraints, anything the implementer must know]
```

Register every created file in `Docs/file-map.md` with Layer `Docs`.

## Step 5. Update mode

If `Docs/product.md` already existed, ask what changed (new feature, cut feature, priority change, new persona). Apply the change to `product.md` and to the affected `Docs/Features/<Name>.md`. Never regenerate untouched features. Bump the Status line of a changed feature to `respecified`.

## Step 6. Hand off

Tell the user:

> Product is defined. Docs/product.md and one spec per feature in Docs/Features/ are written.
>
> Next: say "design the architecture" to run architecture-designer. It reads the feature list and decides modules, data flow and technical choices.

## What this skill produces

1. `Docs/product.md`: personas, jobs, feature table, flows, scope boundaries
2. `Docs/Features/<Name>.md`: one spec stub per feature, consumed by every downstream skill

## Dependencies

- Requires: `Docs/project-brief.md`, `Docs/conventions.md` (ios-project-foundation)
- Feeds: architecture-designer, domain-modeler, feature-builder

## Rules

- Always read project-brief.md before proposing anything. Respect the non-goals listed there.
- Always confirm the primary persona and the feature list before writing files.
- Never write a feature without at least 3 acceptance criteria.
- Never define entity fields here. Names only. domain-modeler owns the shapes.
- Never exceed the scope chosen in Step 1.
- Feature names are PascalCase and become folder names. No spaces, no accents.
- Never use em dashes in any output file.
