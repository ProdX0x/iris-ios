---
name: data-layer-generator
description: >
  Implement the Data layer for a feature: repository implementations, remote and local data sources, DTOs and mappers, honouring the repository protocols in Domain. Produces Data/ files. Use this skill whenever the user says "generate the data layer", "implement the repository", "API client for", "persistence for", "SwiftData model for", "CloudKit for", "mapper", "DTO", "génère la couche data", "implémente le repository", "client API", "persistance", or when dependency-injector finds a repository protocol with no implementation. Requires domain-modeler and architecture-designer.
---

# Data Layer Generator

## Prerequisites check

Check for `Docs/conventions.md`, `Docs/domain-model.md` and `Docs/architecture.md`. If any is missing, say:

> The data layer implements Domain protocols under the persistence decisions in architecture.md. Run domain-modeler and architecture-designer first.

Then stop. If present, read all three plus `Docs/file-map.md`. Go straight to Step 1.

## Step 1. Scope and sources

Call AskUserQuestion:

```json
[
  {
    "question": "Which repository?",
    "header": "Scope",
    "multiSelect": false,
    "options": [
      {"label": "All for one feature", "description": "Every repository protocol of the feature"},
      {"label": "One repository", "description": "I will name it"},
      {"label": "Whole product", "description": "Every protocol without an implementation"}
    ]
  },
  {
    "question": "Data sources for this scope?",
    "header": "Sources",
    "multiSelect": true,
    "options": [
      {"label": "Remote", "description": "REST/GraphQL per architecture.md networking ADR"},
      {"label": "Local", "description": "SwiftData/CoreData/files per persistence ADR"},
      {"label": "Remote with local cache", "description": "Both, remote is source of truth"},
      {"label": "In-memory", "description": "For prototypes and previews"}
    ]
  }
]
```

If Remote is chosen and no API contract is in the project (`Docs/api.md` or an OpenAPI file), ask the user to paste the endpoints and one sample JSON per endpoint. Do not invent field names.

Search `Docs/file-map.md` and `Data/` for every target type name. Existing implementations are never regenerated.

## Step 2. Design per repository

For each repository protocol, present in chat:

```
InvoiceRepository
  Impl:        InvoiceRepositoryImpl
  Remote:      InvoiceRemoteDataSource (protocol) ← URLSessionInvoiceRemoteDataSource
  Local:       InvoiceLocalDataSource (protocol) ← SwiftDataInvoiceLocalDataSource
  DTOs:        InvoiceDTO (Codable), InvoiceLineDTO
  Model:       InvoiceModel (@Model, SwiftData) if local
  Mapper:      InvoiceMapper (DTO ↔ Invoice, Model ↔ Invoice)
  Strategy:    remote first, write-through cache, local on offline
  Error map:   URLError → InvoiceError.network, DecodingError → InvoiceError.corruptData
```

Call AskUserQuestion to approve. Maximum 3 rounds.

## Step 3. Generate

Files, one type each, under the paths from conventions.md:

- `Data/DTOs/<Feature>/<Noun>DTO.swift`: `Codable`, `Sendable`, field names match the API exactly, `CodingKeys` when they differ from Swift style
- `Data/DataSources/Remote/<Feature>/<Noun>RemoteDataSource.swift`: protocol
- `Data/DataSources/Remote/<Feature>/URLSession<Noun>RemoteDataSource.swift`: implementation using the shared `HTTPClient` from `Core/Networking/` (create it once if absent, register it)
- `Data/DataSources/Local/<Feature>/<Noun>LocalDataSource.swift`: protocol
- `Data/DataSources/Local/<Feature>/<Engine><Noun>LocalDataSource.swift`: implementation
- `Data/DataSources/Local/<Feature>/<Noun>Model.swift`: `@Model` class if SwiftData
- `Data/Mappers/<Feature>/<Noun>Mapper.swift`: static pure functions `toDomain` and `toDTO` / `toModel`
- `Data/Repositories/<Feature>/<Noun>RepositoryImpl.swift`

Repository implementation shape:

```swift
// InvoiceRepositoryImpl.swift
// Layer: Data
// Purpose: InvoiceRepository over remote API with local cache

import Foundation

final class InvoiceRepositoryImpl: InvoiceRepository {
    private let remote: InvoiceRemoteDataSource
    private let local: InvoiceLocalDataSource
    private let mapper: InvoiceMapper

    init(remote: InvoiceRemoteDataSource, local: InvoiceLocalDataSource, mapper: InvoiceMapper = InvoiceMapper()) {
        self.remote = remote
        self.local = local
        self.mapper = mapper
    }

    func fetchAll() async throws(InvoiceError) -> [Invoice] {
        do {
            let dtos = try await remote.fetchAll()
            let invoices = dtos.map(mapper.toDomain)
            try await local.replaceAll(invoices.map(mapper.toModel))
            return invoices
        } catch let error as URLError where error.code == .notConnectedToInternet {
            return try await local.fetchAll().map(mapper.toDomain)
        } catch {
            throw InvoiceError.storage(underlying: String(describing: error))
        }
    }
}
```

Rules for bodies:
- Every external error is mapped to the feature's domain error. Nothing else crosses the boundary.
- Mappers are pure. No async, no side effects, tested by test-generator.
- No business rule in Data. If a rule is needed, redirect to business-logic-engine.
- SwiftData `@Model` classes never leave Data. Domain sees entities only.

## Step 4. Register and document

Append every file to `Docs/file-map.md`. Add a `## Data strategy` section per feature to `Docs/architecture.md` with the Step 2 block.

## Step 5. Hand off

Tell the user:

> Data layer for [scope] is implemented and mapped to domain errors. Say "wire the dependencies" to register everything in AppContainer, or "generate tests" for mapper and repository tests.

## What this skill produces

1. DTOs, data sources, models, mappers and repository implementations under `Data/`
2. `## Data strategy` blocks in `Docs/architecture.md`

## Dependencies

- Requires: `Docs/domain-model.md`, `Docs/architecture.md`, `Docs/conventions.md`
- Feeds: dependency-injector, test-generator

## Rules

- Always honour the exact repository protocol signature. Never change a Domain protocol from here.
- Always map external errors to the domain error enum.
- Never expose a DTO or @Model outside Data.
- Never invent API field names. Ask for a sample payload.
- Never put caching policy in a use case. It belongs in the repository implementation.
- Never use em dashes in any output file.
