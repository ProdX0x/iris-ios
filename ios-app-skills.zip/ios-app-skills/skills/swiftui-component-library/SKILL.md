---
name: swiftui-component-library
description: >
  Implement the reusable SwiftUI components inventoried in Docs/design-system.md, one file per component under DesignSystem/Components/, with variants, states, accessibility and previews, using tokens only. Also promotes a feature-local component to the design system when a second feature needs it. Use this skill whenever the user says "build the component library", "create the DS components", "make a reusable button", "component for", "promote this component", "shared component", "crée les composants", "bibliothèque de composants", "composant réutilisable", "factorise ce composant", or when view-generator reports a missing DS component. Requires ui-ux-designer.
---

# SwiftUI Component Library

## Prerequisites check

Check for `Docs/design-system.md` and `DesignSystem/Tokens/`. If missing, say:

> Components are built from tokens. Run ui-ux-designer first ("design the UI").

Then stop. If present, read `design-system.md`, `Docs/conventions.md`, `Docs/file-map.md`. Go straight to Step 1.

## Step 1. Scope

Call AskUserQuestion:

```json
[
  {
    "question": "What to build?",
    "header": "Scope",
    "multiSelect": false,
    "options": [
      {"label": "Whole inventory", "description": "Every component in design-system.md not yet implemented"},
      {"label": "One component", "description": "I will name it"},
      {"label": "Promote from a feature", "description": "Move a Features/*/Presentation/Components/ file into DesignSystem"},
      {"label": "Add a variant", "description": "Extend an existing DS component"}
    ]
  }
]
```

Cross-check the inventory against `Docs/file-map.md`. Components already in `DesignSystem/Components/` are never regenerated. If the user names a component absent from the inventory, add the row to `design-system.md` first (redirect to ui-ux-designer extend mode or do it inline if trivial and say so).

## Step 2. Design the API

For each component, present its public API before writing:

```
DSButton
  init(_ title: String, variant: Variant = .primary, isLoading: Bool = false, action: @escaping () -> Void)
  Variant: primary, secondary, destructive, ghost
  Disabled: via .disabled() environment, styled automatically
  Sizing: full width by default, .dsButtonCompact() modifier for inline
  Accessibility: title is the label, isLoading sets .accessibilityValue("Loading")
```

API rules:
- Small, explicit initialisers. No configuration bag with 12 optionals.
- Variants are nested enums.
- Style follows the SwiftUI `ButtonStyle` / `ViewModifier` idiom where it fits, so consumers can `.buttonStyle(.dsPrimary)`.
- No callbacks with domain types. Strings, IDs, closures only.

Call AskUserQuestion to approve. Maximum 3 rounds.

## Step 3. Implement

```swift
// DSButton.swift
// Layer: DesignSystem
// Purpose: Primary action button with variants and loading state

import SwiftUI

struct DSButton: View {
    enum Variant { case primary, secondary, destructive, ghost }

    private let title: String
    private let variant: Variant
    private let isLoading: Bool
    private let action: () -> Void

    @Environment(\.isEnabled) private var isEnabled

    init(_ title: String, variant: Variant = .primary, isLoading: Bool = false, action: @escaping () -> Void) {
        self.title = title
        self.variant = variant
        self.isLoading = isLoading
        self.action = action
    }

    var body: some View {
        Button(action: action) {
            ZStack {
                Text(title).opacity(isLoading ? 0 : 1)
                if isLoading { ProgressView().tint(foreground) }
            }
            .font(DSFont.body.weight(.semibold))
            .frame(maxWidth: .infinity, minHeight: 44)
            .padding(.horizontal, DSSpacing.m)
            .background(background, in: RoundedRectangle(cornerRadius: DSRadius.m))
            .foregroundStyle(foreground)
        }
        .disabled(isLoading || !isEnabled)
        .opacity(isEnabled ? 1 : 0.4)
        .accessibilityLabel(title)
        .accessibilityValue(isLoading ? Text("Loading") : Text(""))
    }

    private var background: Color {
        switch variant {
        case .primary: DSColor.accent
        case .secondary: DSColor.backgroundSecondary
        case .destructive: DSColor.statusDanger
        case .ghost: .clear
        }
    }

    private var foreground: Color {
        switch variant {
        case .primary, .destructive: DSColor.textOnAccent
        case .secondary, .ghost: DSColor.textPrimary
        }
    }
}

#Preview("Variants") {
    VStack(spacing: DSSpacing.m) {
        DSButton("Primary") {}
        DSButton("Secondary", variant: .secondary) {}
        DSButton("Destructive", variant: .destructive) {}
        DSButton("Ghost", variant: .ghost) {}
        DSButton("Loading", isLoading: true) {}
        DSButton("Disabled") {}.disabled(true)
    }
    .padding()
}
```

Every component file:
- Tokens only. Zero literal colours, fonts, or numeric spacing.
- One preview showing every variant and state, plus one preview with `.dynamicTypeSize(.accessibility3)` and one with `.preferredColorScheme(.dark)`.
- Accessibility label, value and traits set where the default is not enough.
- No dependency on Domain or any feature. `import SwiftUI` only.

Modifiers go in `DesignSystem/Modifiers/<Name>Modifier.swift` with a `View` extension in the same file.

## Step 4. Promote mode

When promoting a feature component:
1. Read the feature file. Strip every feature type from its signature (replace `InvoiceRowItem` with strings and closures).
2. Create the DS version with the `DS` prefix.
3. Replace the feature component with a thin wrapper that maps the feature model to the DS component, or delete it if the wrapper would be trivial and update the View directly.
4. Show before and after in chat. Apply after approval.
5. Update `file-map.md`: new DS file, deleted or modified feature file.

## Step 5. Register and hand off

Append every file to `Docs/file-map.md`. Mark each row of the inventory in `design-system.md` with `Status: implemented`.

Tell the user:

> [n] components implemented under DesignSystem/Components/ with previews. Say "generate the view for [screen]" to use them.

## What this skill produces

1. `DesignSystem/Components/DS<Name>.swift`, one per component
2. `DesignSystem/Modifiers/<Name>Modifier.swift` as needed
3. Status updates in `Docs/design-system.md`

## Dependencies

- Requires: `Docs/design-system.md`, `DesignSystem/Tokens/` (ui-ux-designer)
- Feeds: view-generator

## Rules

- Always `DS` prefix. Always one component per file.
- Always tokens. Never literals.
- Never import Domain or a feature type into DesignSystem.
- Never regenerate an existing component. Extend with a variant.
- Every component ships with variant, dark mode and accessibility-size previews.
- Never use em dashes in any output file.
