---
name: test-generator
description: >
  Generate unit tests (Swift Testing) for use cases, business rules, mappers, ViewModels and coordinators, plus UI tests (XCTest) for critical user flows, with hand-written mocks, one test file per type, under Tests/. Use this skill whenever the user says "generate tests", "write tests for", "unit test", "UI test", "cover this", "mock for", "test coverage", "génère les tests", "écris les tests", "test unitaire", "test UI", "couvre ce code", "mock pour", or at the end of every feature-builder run. Requires ios-project-foundation and the code under test.
---

# Test Generator

## Prerequisites check

Check for `Docs/conventions.md` and `Docs/file-map.md`. If missing, say:

> Tests follow the project conventions. Run ios-project-foundation first.

Then stop. If present, read both, plus `Docs/domain-model.md` (rules table) and `Docs/Features/*.md` (acceptance criteria). Go straight to Step 1.

## Step 1. Scope

Call AskUserQuestion:

```json
[
  {
    "question": "What to test?",
    "header": "Scope",
    "multiSelect": false,
    "options": [
      {"label": "One feature", "description": "Every use case, rule, mapper, ViewModel and flow of one feature"},
      {"label": "One type", "description": "I will name it"},
      {"label": "Uncovered only", "description": "Every type in file-map.md without a matching <Type>Tests file"},
      {"label": "UI flows", "description": "XCTest UI tests for the P0 user flows in Docs/product.md"}
    ]
  }
]
```

Search `Tests/` and `file-map.md` for existing `<Type>Tests` and `Mock<Protocol>`. Existing tests are extended, never rewritten. Existing mocks are reused.

## Step 2. Plan the cases

Present a case table before writing:

```
CreateInvoiceUseCaseTests
| Case | Given | When | Then | Rule / AC |
|---|---|---|---|---|
| creates draft with computed total | client exists, 2 lines, 20% VAT | execute | invoice.status == .draft, total == 120.00 | R-02 |
| throws when client missing | clients.fetch throws notFound | execute | throws InvoiceError.clientNotFound | AC-3 |
| does not save on failure | repository.save throws | execute | throws, saveCallCount == 1, no partial state | AC-4 |
```

Sources for cases:
- Every rule ID in the `## Business rules` table gets at least one test
- Every acceptance criterion in the feature spec gets at least one test
- Every `Phase` transition of a ViewModel gets one test
- Every mapper gets a round trip test and a malformed input test
- Every coordinator route gets a test that `navigate(to:)` mutates `path` or `modal` as expected

Call AskUserQuestion to approve. Maximum 3 rounds.

## Step 3. Generate mocks

One mock per protocol in `Tests/UnitTests/Mocks/Mock<Protocol>.swift`:

```swift
// MockInvoiceRepository.swift
// Layer: Tests
// Purpose: Recording mock for InvoiceRepository

import Foundation
@testable import <AppName>

final class MockInvoiceRepository: InvoiceRepository, @unchecked Sendable {
    var fetchAllResult: Result<[Invoice], InvoiceError> = .success([])
    var saveResult: Result<Void, InvoiceError> = .success(())
    private(set) var saveCalls: [Invoice] = []
    private(set) var deleteCalls: [InvoiceID] = []

    func fetchAll() async throws(InvoiceError) -> [Invoice] { try fetchAllResult.get() }
    func fetch(id: InvoiceID) async throws(InvoiceError) -> Invoice {
        guard let found = try fetchAllResult.get().first(where: { $0.id == id }) else { throw .notFound(id) }
        return found
    }
    func save(_ invoice: Invoice) async throws(InvoiceError) { saveCalls.append(invoice); try saveResult.get() }
    func delete(id: InvoiceID) async throws(InvoiceError) { deleteCalls.append(id) }
}
```

Mocks record calls and return configurable results. No logic. No third-party mocking library.

Fixtures: `Tests/UnitTests/Fixtures/<Entity>+Fixture.swift` with `static func fixture(...)` using sensible defaults, one per entity, reused by previews through `#if DEBUG` when conventions allow.

## Step 4. Generate unit tests

Swift Testing, one file per type, path mirrors the source layer:

```swift
// CreateInvoiceUseCaseTests.swift
// Layer: Tests
// Purpose: R-02 and AC-3, AC-4 of Invoices

import Testing
@testable import <AppName>

@Suite("CreateInvoiceUseCase")
struct CreateInvoiceUseCaseTests {
    private let invoices = MockInvoiceRepository()
    private let clients = MockClientRepository()

    private func makeSUT() -> DefaultCreateInvoiceUseCase {
        DefaultCreateInvoiceUseCase(invoices: invoices, clients: clients, calculator: InvoiceTotalCalculator())
    }

    @Test("creates a draft with the computed total (R-02)")
    func createsDraft() async throws {
        clients.fetchResult = .success(.fixture())
        let sut = makeSUT()

        let invoice = try await sut.execute(.fixture(vatRate: .percent(20)))

        #expect(invoice.status == .draft)
        #expect(invoice.total == Money(120, currency: .eur))
        #expect(invoices.saveCalls.count == 1)
    }

    @Test("throws when the client does not exist (AC-3)")
    func throwsWhenClientMissing() async {
        clients.fetchResult = .failure(.notFound(.fixture))
        let sut = makeSUT()

        await #expect(throws: InvoiceError.clientNotFound) {
            try await sut.execute(.fixture())
        }
        #expect(invoices.saveCalls.isEmpty)
    }
}
```

ViewModel tests run with `@MainActor` on the suite and assert `phase` after each action. Coordinator tests assert `path.count` and `modal`.

Test rules:
- Arrange, act, assert with blank lines between. One behaviour per test.
- Test names describe behaviour and cite the rule or AC ID.
- No sleeping, no timers. Async is awaited.
- No test touches the network, the disk or the keychain. `AppEnvironment.test` only.

## Step 5. Generate UI tests

XCTest, `Tests/UITests/<Flow>UITests.swift`, one class per P0 flow from `product.md`. Use accessibility identifiers set by view-generator (`ds.<screen>.<element>`). If identifiers are missing, list them and redirect to view-generator before writing the test. Launch with `-uiTesting` argument so the app uses `AppEnvironment.test` seeded data.

## Step 6. Register and hand off

Append every file to `Docs/file-map.md`. Add a `## Test coverage` section to `Docs/Features/<Name>.md` listing rule IDs and AC IDs covered.

Tell the user:

> [n] test files, [n] mocks, [n] fixtures generated. Run `xcodebuild test -scheme <AppName>` or the Xcode test navigator. Say "audit the layers" to finish the feature with layer-auditor.

## What this skill produces

1. `Tests/UnitTests/<Layer>/<Feature>/<Type>Tests.swift`
2. `Tests/UnitTests/Mocks/Mock<Protocol>.swift`
3. `Tests/UnitTests/Fixtures/<Entity>+Fixture.swift`
4. `Tests/UITests/<Flow>UITests.swift`

## Dependencies

- Requires: `Docs/conventions.md`, `Docs/file-map.md`, the code under test
- Reads: `Docs/domain-model.md` rules table, `Docs/Features/*.md` acceptance criteria
- Feeds: feature-builder completion gate

## Rules

- Always one test file per type, mirroring the source path.
- Always cite the rule or AC ID in the test name.
- Never use a mocking library. Hand-written recording mocks only.
- Never rewrite an existing test file. Append cases.
- Never touch network, disk or keychain in unit tests.
- Never use em dashes in any output file.
