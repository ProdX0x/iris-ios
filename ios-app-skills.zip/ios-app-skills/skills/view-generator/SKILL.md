---
name: view-generator
description: >
  Generate SwiftUI views bound to an existing ViewModel, using only DesignSystem tokens and components, with previews for every state. Produces Features/<Name>/Presentation/Views/ files. Use this skill whenever the user says "generate the view", "build the screen", "SwiftUI for [screen]", "make the UI for", "génère la vue", "construis l'écran", "fais l'interface de", "écran SwiftUI", or after viewmodel-generator finishes a screen. Requires viewmodel-generator and ui-ux-designer output (Docs/design-system.md).
---

# View Generator

## Prerequisites check

Check for `Docs/conventions.md`, `Docs/design-system.md` and the target `<Screen>ViewModel.swift`. If any is missing, say which one:

> Views bind to a ViewModel and use the design system. Run [viewmodel-generator | ui-ux-designer] first.

Then stop. If all present, read them plus `Docs/Features/<Feature>.md` and `Docs/file-map.md`. Go straight to Step 1.

## Step 1. Identify the screen and layout

Read the ViewModel's `Phase` enum and actions. Then call AskUserQuestion:

```json
[
  {
    "question": "Layout pattern?",
    "header": "Layout",
    "multiSelect": false,
    "options": [
      {"label": "List", "description": "Scrollable list with rows, search, pull to refresh"},
      {"label": "Detail", "description": "Single item, sections, actions bar"},
      {"label": "Form", "description": "Inputs, validation feedback, submit"},
      {"label": "Dashboard", "description": "Cards and summary blocks"}
    ]
  },
  {
    "question": "Design reference?",
    "header": "Reference",
    "multiSelect": false,
    "options": [
      {"label": "Design system only", "description": "Compose from DesignSystem/Components"},
      {"label": "I will paste a wireframe or screenshot", "description": "Match a mockup"},
      {"label": "Mirror an existing screen", "description": "Same structure as a screen already in the app"}
    ]
  }
]
```

Search `Docs/file-map.md` for `<Screen>View`. If it exists, switch to extend mode.

## Step 2. Map states to UI

Present a table before writing:

```
| Phase | UI |
|---|---|
| .idle / .loading | DSLoadingView (design system) |
| .empty | DSEmptyState(title:, action:) |
| .loaded(items) | List of InvoiceRow inside DSScreen |
| .failed(message) | DSErrorState(message:, retry:) |
```

List every design system component the view will use. For each, confirm it exists in `DesignSystem/Components/` via `file-map.md`. If one is missing, stop and redirect to swiftui-component-library. Never inline a component the design system should own.

Call AskUserQuestion to approve. Maximum 3 rounds.

## Step 3. Generate

```swift
// InvoiceListView.swift
// Layer: Presentation
// Purpose: Invoice list screen bound to InvoiceListViewModel

import SwiftUI

struct InvoiceListView: View {
    @State private var viewModel: InvoiceListViewModel

    init(viewModel: InvoiceListViewModel) {
        _viewModel = State(initialValue: viewModel)
    }

    var body: some View {
        DSScreen(title: String(localized: "invoices.title")) {
            content
        }
        .searchable(text: $viewModel.searchQuery)
        .refreshable { await viewModel.refresh() }
        .toolbar {
            ToolbarItem(placement: .primaryAction) {
                DSIconButton(icon: .plus, label: String(localized: "invoices.create")) {
                    viewModel.tapCreate()
                }
            }
        }
        .task { await viewModel.load() }
    }

    @ViewBuilder
    private var content: some View {
        switch viewModel.phase {
        case .idle, .loading:
            DSLoadingView()
        case .empty:
            DSEmptyState(title: String(localized: "invoices.empty"), actionTitle: String(localized: "invoices.create")) {
                viewModel.tapCreate()
            }
        case .loaded:
            List(viewModel.filteredItems) { item in
                InvoiceRow(item: item)
                    .contentShape(Rectangle())
                    .onTapGesture { viewModel.select(id: item.id) }
                    .swipeActions { deleteButton(for: item.id) }
            }
            .listStyle(.plain)
        case .failed(let message):
            DSErrorState(message: message) {
                Task { await viewModel.load() }
            }
        }
    }

    private func deleteButton(for id: InvoiceID) -> some View {
        Button(role: .destructive) {
            Task { await viewModel.delete(id: id) }
        } label: {
            Label(String(localized: "common.delete"), systemImage: "trash")
        }
    }
}

#Preview("Loaded") {
    InvoiceListView(viewModel: .preview(phase: .loaded(InvoiceRowItem.samples)))
}

#Preview("Empty") {
    InvoiceListView(viewModel: .preview(phase: .empty))
}

#Preview("Failed") {
    InvoiceListView(viewModel: .preview(phase: .failed(message: "Could not load invoices.")))
}
```

For `ObservableObject` mode: `@StateObject private var viewModel` and `_viewModel = StateObject(wrappedValue:)`.

Feature-only subviews (`InvoiceRow`) go in `Features/<Name>/Presentation/Components/`, one file each. If a subview is generic (no feature type in its signature), it belongs in `DesignSystem/Components/` instead, and you redirect to swiftui-component-library.

Previews need a `.preview(phase:)` factory. Create `Features/<Name>/Presentation/ViewModels/<Screen>ViewModel+Preview.swift` with mock use cases from `Tests/UnitTests/Mocks/` if they exist, otherwise minimal inline stubs marked `#if DEBUG`.

Rules for the body:
- No colours, fonts, spacing literals. Tokens only (`DSColor`, `DSFont`, `DSSpacing`).
- No business logic. No formatting. No `if` on domain values beyond switching on Phase.
- No `NavigationLink` with a destination. Navigation is `viewModel.select(...)`.
- Every user-facing string via `String(localized:)` when catalog mode. Add the keys to `Localizable.xcstrings` with base-language values.
- `body` under 40 lines. Extract `@ViewBuilder` properties.
- Accessibility: every interactive element has a label. Every image has a description or is decorative.

## Step 4. Register and hand off

Append every file to `Docs/file-map.md`. Add new localisation keys to the String Catalog. Update `Docs/Features/<Name>.md` Screens section with `View: done`.

Tell the user:

> [Screen]View generated with [n] previews. Say "wire the navigation" for coordinator-navigator, or "generate UI tests" for test-generator.

## What this skill produces

1. `Features/<Name>/Presentation/Views/<Screen>View.swift`
2. `Features/<Name>/Presentation/Components/<Row|Card|Section>.swift` as needed
3. `Features/<Name>/Presentation/ViewModels/<Screen>ViewModel+Preview.swift`
4. String Catalog keys

## Dependencies

- Requires: `<Screen>ViewModel.swift` (viewmodel-generator), `Docs/design-system.md` (ui-ux-designer), `DesignSystem/Components/` (swiftui-component-library)
- Feeds: coordinator-navigator, test-generator

## Rules

- Always map every Phase case to a UI. A missing case is a bug.
- Always use design system tokens and components. Never a raw `Color`, `Font` or numeric padding.
- Never put navigation destinations in a View.
- Never put logic in a View beyond switching on state.
- Never inline a reusable component. Redirect to swiftui-component-library.
- Always ship at least three previews: loaded, empty, failed.
- Never use em dashes in any output file.
