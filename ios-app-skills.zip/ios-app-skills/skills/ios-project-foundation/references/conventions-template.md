# Conventions

Single source of truth for this project. Every skill reads this file before generating code. If code disagrees with this file, the code is wrong.

## Targets
- Minimum iOS: [version]
- Swift: [version], strict concurrency: [complete | minimal]
- Xcode: [version]
- Observation: [@Observable | ObservableObject]

## Architecture
- Pattern: MVVM in the Presentation layer, Clean Architecture across three layers.
- Layers and the only allowed dependency direction:
  - Presentation depends on Domain
  - Data depends on Domain
  - Domain depends on nothing (no UIKit, no SwiftUI, no Foundation networking, no SwiftData)
- Navigation: Coordinators. Views never push other views. Views emit intents, coordinators decide.
- Dependency injection: constructor injection. One `AppContainer` in `Core/DI/`. No global singletons except `AppContainer.shared` used only at the composition root.
- Concurrency: async/await only. No Combine. No completion handlers. Every ViewModel is `@MainActor`.

## Folder layout
```
App/                 entry point, AppDelegate, Info.plist, Resources/
Core/                DI/, Navigation/, Extensions/, Utilities/
DesignSystem/        Tokens/, Components/, Modifiers/
Domain/              Entities/, ValueObjects/, Repositories/, UseCases/, Errors/
Data/                Repositories/, DataSources/Remote/, DataSources/Local/, DTOs/, Mappers/
Features/<Name>/     Presentation/Views/, Presentation/ViewModels/, Presentation/Components/, Coordinator/
Tests/               UnitTests/<Layer>/, UITests/
Docs/                project-brief.md, conventions.md, architecture.md, domain-model.md, design-system.md, file-map.md, Features/
```
- Domain and Data are grouped by feature inside each subfolder: `Domain/UseCases/<Feature>/`, `Data/Repositories/<Feature>/`.
- Feature-only UI components live in `Features/<Name>/Presentation/Components/`. If a component is used by two features, it moves to `DesignSystem/Components/`.

## Naming
| Thing | Rule | Example |
|---|---|---|
| Entity | Noun, no suffix | `Invoice` |
| Value object | Noun, no suffix | `Money` |
| Repository protocol | `<Noun>Repository` | `InvoiceRepository` |
| Repository impl | `<Noun>RepositoryImpl` | `InvoiceRepositoryImpl` |
| Use case protocol | `<Verb><Noun>UseCase` | `CreateInvoiceUseCase` |
| Use case impl | `Default<Verb><Noun>UseCase` | `DefaultCreateInvoiceUseCase` |
| Data source | `<Noun><Remote|Local>DataSource` | `InvoiceRemoteDataSource` |
| DTO | `<Noun>DTO` | `InvoiceDTO` |
| Mapper | `<Noun>Mapper` | `InvoiceMapper` |
| ViewModel | `<Screen>ViewModel` | `InvoiceListViewModel` |
| View | `<Screen>View` | `InvoiceListView` |
| Coordinator | `<Feature>Coordinator` | `InvoicesCoordinator` |
| Route enum | `<Feature>Route` | `InvoicesRoute` |
| Domain error | `<Noun>Error` | `InvoiceError` |
| Test | `<TypeUnderTest>Tests` | `CreateInvoiceUseCaseTests` |
| Mock | `Mock<Protocol>` | `MockInvoiceRepository` |

## File rules
- One top-level type per file. File name equals type name. `InvoiceListViewModel.swift` contains `InvoiceListViewModel` and nothing else.
- Extensions of a type live in `<Type>+<Concern>.swift` next to the type.
- No file over 300 lines. Split by concern.
- No `Utils.swift`, `Helpers.swift`, `Extensions.swift` catch-all files.
- Every new file is registered in `Docs/file-map.md`.

## Code style
- Access control: [strict | default]. Default to `private` and widen only when needed.
- Every dependency is a protocol. Concrete types are injected, never instantiated inside a consumer.
- Use cases expose one `execute` method.
- ViewModels expose state as stored properties and actions as methods. No `@Published` unless ObservableObject mode.
- Views are dumb: read state, call actions, render. No business logic, no formatting logic beyond presentation.
- No force unwrap. No `try!`. No `as!`.
- Errors: typed domain errors. Never `Error` alone at a public boundary.
- Strings: [String Catalog only | hardcoded allowed]. No user-facing string literal in a View if catalog mode.
- No `TODO` left in generated code. Unfinished work goes in Docs/Features/<name>.md.

## Testing
- Unit tests: Swift Testing (`@Test`, `#expect`). One test file per type.
- UI tests: XCTest. One test class per critical user flow.
- Every use case has a test. Every ViewModel has a test. Every mapper has a test.
- Mocks are hand-written, live in `Tests/UnitTests/Mocks/`, one per protocol.

## Dependencies
- Policy: [zero | minimal | pragmatic]
- Allowed packages: [list or "none"]

## Localisation
- [String Catalog from day one | English only for v1]
- Base language: [en | fr]
