---
name: ios-project-foundation
description: >
  Build the shared context files for an iOS project from a short interview. Produces project-brief.md, conventions.md and file-map.md inside Docs/. This is the foundation every other iOS skill reads before writing a single line of Swift. Use this skill at the start of any new iOS or SwiftUI project, or when onboarding Claude onto an existing Xcode project. Trigger whenever the user says "set up my iOS project", "init the project context", "onboard me on this app", "start a new iOS app", "create the project foundation", "nouveau projet iOS", "initialise le projet", "pose les fondations", "configure les conventions", or opens a project folder that has no Docs/project-brief.md. Always produces three files saved into Docs/ at the project root.
---

# iOS Project Foundation

## CRITICAL: Auto-start on load

The moment this skill is loaded, installed, uploaded, or triggered, you MUST immediately run Step 1 below. Your very next message to the user is the interview. Nothing else.

Do NOT:
- Summarise this skill
- Describe what files it creates
- Explain how it works
- Ask if the user wants to run it
- Confirm installation

Do THIS:
- Go straight to Step 1
- Send the interview as your first and only response

## Step 1. Detect existing project

Before asking anything, scan the working directory:

1. Look for `*.xcodeproj`, `*.xcworkspace` or `Package.swift`. Note the project name.
2. Look for `Docs/project-brief.md`, `Docs/conventions.md`, `Docs/file-map.md`.
3. If all three exist, read them and say:

> Foundation already exists. Tell me what to update (brief, conventions or file map), or say "rebuild" to start over.

Then stop and wait.

4. If a Swift project exists but no Docs/ files, note every top-level folder and count `.swift` files. You will need this in Step 4. Then continue to Step 2.
5. If nothing exists, continue to Step 2.

## Step 2. Run the project interview

You MUST call the AskUserQuestion tool. Do not type the questions as chat text. AskUserQuestion supports a maximum of 4 questions per call, so send two calls: Batch 1 first, wait for answers, then Batch 2.

### Batch 1 (your very first action, no text before it)

```json
[
  {
    "question": "What is the app and what does it do in one sentence?",
    "header": "App",
    "multiSelect": false,
    "options": [
      {"label": "Utility", "description": "Solves one clear task (converter, tracker, calculator)"},
      {"label": "Content", "description": "Reads, browses or consumes content (feed, reader, catalogue)"},
      {"label": "Social or community", "description": "Users interact with each other"},
      {"label": "Business tool", "description": "Internal or professional workflow"}
    ]
  },
  {
    "question": "Minimum iOS version and Swift toolchain?",
    "header": "Targets",
    "multiSelect": false,
    "options": [
      {"label": "iOS 17+, Swift 6", "description": "Observation framework, strict concurrency. Recommended."},
      {"label": "iOS 16+, Swift 5.10", "description": "NavigationStack available, ObservableObject required"},
      {"label": "iOS 18+, Swift 6", "description": "Latest APIs only"}
    ]
  },
  {
    "question": "Where does the data live?",
    "header": "Data",
    "multiSelect": true,
    "options": [
      {"label": "Local only", "description": "SwiftData or file storage, no server"},
      {"label": "CloudKit", "description": "Apple sync, no custom backend"},
      {"label": "REST or GraphQL API", "description": "Custom backend over HTTPS"},
      {"label": "Firebase or Supabase", "description": "Third-party BaaS"}
    ]
  },
  {
    "question": "Third-party dependencies policy?",
    "header": "Dependencies",
    "multiSelect": false,
    "options": [
      {"label": "Zero third-party", "description": "Apple frameworks only. Recommended for App Store review speed."},
      {"label": "SPM allowed, minimal", "description": "One or two vetted packages maximum"},
      {"label": "SPM allowed, pragmatic", "description": "Whatever ships faster"}
    ]
  }
]
```

### Batch 2 (send immediately after Batch 1 answers, no commentary between)

```json
[
  {
    "question": "Who is the user and what is their main frustration today?",
    "header": "User",
    "multiSelect": false,
    "options": [
      {"label": "Consumer", "description": "General public, App Store discovery"},
      {"label": "Prosumer", "description": "Power users who pay for quality"},
      {"label": "Internal team", "description": "Enterprise or TestFlight distribution"}
    ]
  },
  {
    "question": "Monetisation?",
    "header": "Business",
    "multiSelect": false,
    "options": [
      {"label": "Free", "description": "No payment logic"},
      {"label": "One-time purchase", "description": "Paid upfront or single IAP"},
      {"label": "Subscription", "description": "StoreKit 2 subscription tiers"},
      {"label": "Undecided", "description": "Design the architecture to allow it later"}
    ]
  },
  {
    "question": "Code style preferences?",
    "header": "Style",
    "multiSelect": true,
    "options": [
      {"label": "Strict access control", "description": "Everything private unless proven otherwise"},
      {"label": "Protocol-first", "description": "Every dependency behind a protocol"},
      {"label": "Async/await only", "description": "No Combine, no completion handlers"},
      {"label": "Localisation from day one", "description": "String Catalog, no hardcoded copy"}
    ]
  }
]
```

After both batches, ask in chat for the app name and bundle identifier if not already detected from an existing `.xcodeproj`. Then move to Step 3.

## Step 3. Write Docs/project-brief.md

Create `Docs/project-brief.md`. Use this exact structure:

```
# Project Brief

## App
[Name, one-sentence purpose, category from question 1]

## Bundle
[Bundle identifier, minimum iOS version, Swift version, Xcode version]

## User
[2 to 3 sentences on who uses this and the frustration it removes]

## Core promise
[One sentence: what the user gets that they cannot get elsewhere]

## Data
[Where data lives, sync strategy, offline expectations]

## Business model
[From question 6, plus what it implies for architecture: StoreKit, entitlements, feature gating]

## Dependency policy
[From question 4, with the allowed list if any]

## Non-goals
[3 things this app will NOT do in version 1]
```

Keep it under 300 words. Every line must be something a later skill would reference when making a decision.

## Step 4. Write Docs/conventions.md

Create `Docs/conventions.md`. This is the single source of truth for naming, layering and style. Every other skill reads it before generating code.

Load `references/conventions-template.md` from this skill folder. Fill every placeholder from the interview answers. Do not leave any `[...]` placeholder in the output. The template already encodes the non-negotiable architecture:

- MVVM for presentation
- Clean Architecture in three layers: Domain, Data, Presentation
- Coordinators for navigation
- Constructor injection through a single `AppContainer`
- One type per file, file name equals type name

If the user chose iOS 16, replace `@Observable` with `ObservableObject` and `@Published` throughout the template and note it in the Observation section.

Keep conventions.md under 600 words. Rules, not prose.

## Step 5. Write Docs/file-map.md

Create `Docs/file-map.md`. This is the anti-duplication registry. Every skill that creates a file MUST append a row here. Every skill that is about to create a file MUST search this table first.

```
# File Map

Registry of every source file in the project. One row per file. Updated by every skill that creates or deletes a file. Search this table before creating anything.

| Path | Type | Layer | Purpose | Created by |
|---|---|---|---|---|
```

If an existing project was detected in Step 1, walk every `.swift` file and add one row per file. Infer Layer from the folder (Domain, Data, Presentation, Core, DesignSystem, App, Tests, Unknown). Infer Purpose from the primary type declaration. Set Created by to `existing`. Flag any file that contains more than one top-level type with `[multi-type]` in the Purpose column.

## Step 6. Confirm and hand off

Tell the user:

> Foundation is in place. Three files are now in Docs/: project-brief.md, conventions.md and file-map.md. Every iOS skill reads these before doing anything. Edit them anytime.
>
> Next steps, in order:
>
> - Say "define the product" to run product-conception and write the feature list
> - Say "design the architecture" to run architecture-designer
> - Say "build feature [name]" to run feature-builder end to end
>
> Each of these is a separate skill. Pick one and go.

## What this skill produces

Three files in `Docs/` at the project root:

1. `project-brief.md`: what the app is, for whom, data strategy, business model, dependency policy
2. `conventions.md`: naming, layering, file rules, style rules, the contract every other skill obeys
3. `file-map.md`: the registry of every source file, the anti-duplication mechanism

## Dependencies

- None. This is the foundation skill.
- `references/conventions-template.md` in this skill folder.

## Rules

- When this skill triggers, go straight to Step 1. No summary, no preamble.
- Always detect an existing project before interviewing. Never overwrite existing Docs/ files without the user saying "rebuild".
- Always put the three files in `Docs/`. Never in the project root, never in the Xcode group, never scattered.
- Never leave a placeholder in conventions.md.
- Never invent a bundle identifier. Ask.
- Keep project-brief.md under 300 words and conventions.md under 600 words.
- Never use em dashes in any output file.
- British English in skill files. Code identifiers and comments in English. User-facing copy in the language the user writes in.
