---
name: business-logic-engine
description: >
  Extract and implement business rules as pure, testable domain services and entity methods. Turns acceptance criteria and product rules into Swift logic that lives in Domain, never in ViewModels or Views. Produces Domain/Services/ files and a rules table in Docs/domain-model.md. Use this skill whenever the user says "write the business rules", "implement the logic for", "validation rules", "calculation logic", "domain service", "the rule is", "règles métier", "logique métier", "implémente la règle", "calcul de", "validation de", or when a use case needs a rule that spans several entities. Requires domain-modeler.
---

# Business Logic Engine

## Prerequisites check

Check for `Docs/conventions.md` and `Docs/domain-model.md`. If either is missing, say:

> Business rules attach to entities. Run domain-modeler first ("model the domain").

Then stop. If present, read both, plus `Docs/Features/*.md` and `Docs/file-map.md`. Go straight to Step 1.

## Step 1. Collect the rules

Call AskUserQuestion:

```json
[
  {
    "question": "Where do the rules come from?",
    "header": "Source",
    "multiSelect": false,
    "options": [
      {"label": "Feature specs", "description": "Extract from acceptance criteria in Docs/Features/*.md"},
      {"label": "I will describe them", "description": "I will type the rules in chat"},
      {"label": "Existing code", "description": "Find rules currently buried in ViewModels or Views and move them"}
    ]
  }
]
```

If "Existing code": grep `Features/` for `if`, `guard`, `switch`, arithmetic and `Date` logic inside ViewModels and Views. List every candidate rule with its file and line. These are extraction targets.

## Step 2. Write the rules table

Every rule gets an ID and a home before any code:

```
| ID | Rule (plain language) | Inputs | Output | Home | Feature |
|---|---|---|---|---|---|
| R-01 | An invoice cannot be paid twice | Invoice.status | InvoiceError.alreadyPaid | Invoice.markPaid() | Invoices |
| R-02 | Total = sum(lines) + VAT, rounded to 2 decimals | [InvoiceLine], VATRate | Money | InvoiceTotalCalculator | Invoices |
```

Home decision:
- Rule touches one entity's own state: entity method (mutating or computed)
- Rule touches several entities or needs a policy: domain service in `Domain/Services/<Feature>/<Name>.swift`
- Rule is a pure calculation: `struct <Name>Calculator` with a single `calculate` method, stateless

Call AskUserQuestion to approve the table. Iterate, maximum 3 rounds.

## Step 3. Implement

Entity methods are added to the existing entity file, or to `<Entity>+Rules.swift` next to it if the entity file would exceed 150 lines.

Domain services:

```swift
// InvoiceTotalCalculator.swift
// Layer: Domain
// Purpose: R-02 invoice total with VAT

import Foundation

struct InvoiceTotalCalculator: Sendable {
    func calculate(lines: [InvoiceLine], vatRate: VATRate) -> Money {
        let subtotal = lines.reduce(Money.zero) { $0 + $1.amount }
        return subtotal.applying(vatRate).rounded(scale: 2)
    }
}
```

Every rule implementation carries its rule ID in the Purpose line. No rule without an ID. No ID without a test (test-generator reads this table).

If a rule needs data the entity does not have, stop and say which field is missing. Do not add fields silently. Send the user to domain-modeler.

## Step 4. Remove extracted duplicates

If Step 1 found rules in ViewModels or Views: after the domain implementation exists, replace the original code with a call to the domain method. Show every replacement as before and after in chat before applying. Never leave the old logic in place.

## Step 5. Update Docs/domain-model.md

Add or update a `## Business rules` section with the approved table. Register new files in `Docs/file-map.md`.

## Step 6. Hand off

Tell the user:

> [n] rules implemented in Domain, all traceable by ID. Say "generate the use cases" to wire them, or "generate tests" to cover every rule.

## What this skill produces

1. Entity methods and domain services under `Domain/`
2. `## Business rules` table in `Docs/domain-model.md`

## Dependencies

- Requires: `Docs/domain-model.md` (domain-modeler), `Docs/conventions.md`
- Feeds: use-case-generator, test-generator, code-deduplicator

## Rules

- Always give every rule an ID before implementing it.
- Always keep rules in Domain. Never in a ViewModel, never in a View, never in Data.
- Never add a field to an entity here. Redirect to domain-modeler.
- Never import anything but Foundation.
- Domain services are stateless structs. If it needs state, it is an entity.
- Never leave extracted logic duplicated at its original site.
- Never use em dashes in any output file.
