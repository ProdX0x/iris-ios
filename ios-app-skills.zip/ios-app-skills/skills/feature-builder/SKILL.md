---
name: feature-builder
description: >
  Orchestrate every iOS skill to deliver one feature end to end: spec, domain, rules, use cases, data, DI, ViewModels, views, navigation, tests, deduplication and audit, in the only valid order, with a gate between each stage. Use this skill whenever the user says "build feature [name]", "implement [name] end to end", "ship the [name] feature", "full feature", "from spec to tests", "construis la fonctionnalité", "implémente [nom] de bout en bout", "livre la feature", "feature complète", or names a feature from Docs/product.md and wants it done. Requires ios-project-foundation and architecture-designer. Every other skill is invoked as a stage.
---

# Feature Builder

## CRITICAL: Auto-start on load

When this skill triggers, go straight to Step 1. Do not summarise the pipeline. Do not list the stages. Start immediately.

## Prerequisites check

Check for `Docs/conventions.md`, `Docs/architecture.md`, `Docs/design-system.md` and `Core/DI/AppContainer.swift`. For each missing item, name the skill that produces it:

> feature-builder needs: [conventions.md → ios-project-foundation] [architecture.md → architecture-designer] [design-system.md → ui-ux-designer] [AppContainer.swift → dependency-injector bootstrap]. Run those first.

Then stop. If all present, read `conventions.md`, `architecture.md` and `file-map.md`. Go to Step 1.

## Step 1. Pick the feature

If the user named a feature, look for `Docs/Features/<Name>.md`. Otherwise call AskUserQuestion listing every feature from `Docs/product.md` whose Status is not `done`, sorted by priority then dependency order, as the options. If `product.md` is missing, ask the user to describe the feature in chat and run product-conception in one-feature mode first.

Read the feature spec. Check `Depends on`. If a dependency feature is not `Status: done`, stop:

> <Name> depends on <Other>, which is not done. Build <Other> first, or say "ignore dependency" to proceed with stubs.

Create or update `Docs/Features/<Name>.md` with a `## Build log` section:

```
## Build log
| Stage | Skill | Status | Files |
|---|---|---|---|
| 1 Spec | product-conception | pending | |
| 2 Domain | domain-modeler | pending | |
| 3 Rules | business-logic-engine | pending | |
| 4 Use cases | use-case-generator | pending | |
| 5 Data | data-layer-generator | pending | |
| 6 DI | dependency-injector | pending | |
| 7 ViewModels | viewmodel-generator | pending | |
| 8 Components | swiftui-component-library | pending | |
| 9 Views | view-generator | pending | |
| 10 Navigation | coordinator-navigator | pending | |
| 11 Tests | test-generator | pending | |
| 12 Dedupe | code-deduplicator | pending | |
| 13 Audit | layer-auditor | pending | |
```

## Step 2. Run the pipeline

Run the stages in this exact order. For every stage:

1. Announce the stage in one line: `Stage 4/13: use-case-generator for Invoices.`
2. Invoke the skill by following its SKILL.md with the feature pre-selected (answer its scope question with this feature, do not ask the user again).
3. The skill's own approval gates still apply. Wait for the user at each of them.
4. When the skill hands off, update the Build log row: `done` and the list of files created.
5. If the skill redirects to another skill (for example, viewmodel-generator finds a missing use case), run that skill inline for the missing piece, log it as a sub-stage `4a`, then resume.
6. If a stage fails or the user says "stop", mark the row `blocked` with the reason and stop the pipeline. The feature stays `Status: in progress`.

Stage rules:
- Stage 1 is skipped if the spec already has acceptance criteria. Log `skipped: spec exists`.
- Stage 3 is skipped if the spec's acceptance criteria contain no rule beyond CRUD. Log `skipped: no rules`.
- Stage 5 uses the data sources declared for this feature in `architecture.md`. Never ask again.
- Stage 8 runs only for components that view-generator's plan needs and that are missing from `DesignSystem/Components/`. Run stage 9's Step 2 first to get the list, then stage 8, then the rest of stage 9.
- Stage 12 runs in "One feature" scope.
- Stage 13 runs in "One feature" scope. A FAIL verdict sends the pipeline back to the responsible stage. Maximum 2 loops, then stop and report.

## Step 3. Gate between stages

After each stage, call AskUserQuestion:

```json
[
  {
    "question": "Stage <n> done. Continue?",
    "header": "Gate",
    "multiSelect": false,
    "options": [
      {"label": "Continue", "description": "Run stage <n+1>"},
      {"label": "Review files first", "description": "Show me what was created before moving on"},
      {"label": "Stop here", "description": "Pause the pipeline, resume later with the same command"}
    ]
  }
]
```

The pipeline is resumable: on a later run for the same feature, read the Build log and start at the first row that is not `done` or `skipped`.

## Step 4. Close the feature

When stage 13 returns PASS:

1. Set `Status: done` in `Docs/Features/<Name>.md`.
2. Update the feature row in `Docs/product.md` to `done`.
3. Append a `## Delivered` section to the spec: screens, use cases, rules, tests count, files count.
4. If a build command is available, run it and run the tests. Report the result verbatim.

Tell the user:

> Feature <Name> delivered. [n] files, [n] tests, audit PASS. Docs/Features/<Name>.md has the full build log.
>
> Next: say "build feature [next P0 name]" to continue, or "audit the layers" for a whole-project check.

## What this skill produces

1. Every artefact of every stage skill for one feature
2. A complete `## Build log` and `## Delivered` section in `Docs/Features/<Name>.md`
3. Updated `Docs/product.md` status

## Dependencies

- Requires: ios-project-foundation, architecture-designer, ui-ux-designer, dependency-injector bootstrap
- Invokes, in order: product-conception, domain-modeler, business-logic-engine, use-case-generator, data-layer-generator, dependency-injector, viewmodel-generator, swiftui-component-library, view-generator, coordinator-navigator, test-generator, code-deduplicator, layer-auditor
- May invoke on redirect: swift-coder, file-structure-organizer

## Rules

- Always run stages in the listed order. Never generate a View before its ViewModel, never a ViewModel before its use cases, never a use case before its entities.
- Always respect each stage skill's own approval gates. The orchestrator never auto-approves.
- Always log every stage, including skipped and blocked, in the Build log.
- Never declare a feature done without a PASS from layer-auditor.
- Never ask a question a stage skill already answered from the spec or architecture.
- Never use em dashes in any output file.
