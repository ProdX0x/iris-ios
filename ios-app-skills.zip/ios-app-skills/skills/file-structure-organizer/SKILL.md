---
name: file-structure-organizer
description: >
  Generate the complete folder tree and stub files of the iOS project from Docs/architecture.md, and register every file in Docs/file-map.md. Also audits an existing project and moves misplaced files to their correct layer. Use this skill whenever the user says "generate the file structure", "create the folders", "scaffold the project", "organise my files", "where should this file go", "clean up the project tree", "audit the structure", "génère l'arborescence", "crée les dossiers", "range les fichiers", "où mettre ce fichier", "nettoie l'arbo". Requires ios-project-foundation and architecture-designer.
---

# File Structure Organiser

## Prerequisites check

Check for `Docs/conventions.md` and `Docs/architecture.md`. If either is missing, say:

> The tree is generated from the architecture. Run ios-project-foundation then architecture-designer first.

Then stop. If both exist, read them fully plus `Docs/file-map.md`. Go straight to Step 1.

## Step 1. Choose mode

Call AskUserQuestion:

```json
[
  {
    "question": "What do you need?",
    "header": "Mode",
    "multiSelect": false,
    "options": [
      {"label": "Scaffold from scratch", "description": "Create every folder and stub file from architecture.md"},
      {"label": "Scaffold one feature", "description": "Create only Features/<Name> and its Domain and Data folders"},
      {"label": "Audit existing tree", "description": "Find misplaced files and propose moves"},
      {"label": "Place one file", "description": "Tell me where a given type belongs"}
    ]
  }
]
```

## Step 2. Build the target tree

Derive the tree from the Folder layout section of `conventions.md` and the Feature map of `architecture.md`. One folder per feature under `Features/`, and matching feature subfolders under `Domain/UseCases/`, `Domain/Entities/`, `Domain/Repositories/`, `Data/Repositories/`, `Data/DataSources/`, `Data/DTOs/`, `Data/Mappers/`.

Print the full tree in a plain code block before creating anything:

```
<AppName>/
├── App/
│   ├── <AppName>App.swift
│   └── Resources/
│       ├── Assets.xcassets/
│       └── Localizable.xcstrings
├── Core/
│   ├── DI/
│   │   ├── AppContainer.swift
│   │   └── AppContainer+<Feature>.swift
│   ├── Navigation/
│   │   ├── AppCoordinator.swift
│   │   └── AppRoute.swift
│   ├── Extensions/
│   └── Utilities/
├── DesignSystem/
│   ├── Tokens/
│   ├── Components/
│   └── Modifiers/
├── Domain/
│   ├── Entities/<Feature>/
│   ├── ValueObjects/
│   ├── Repositories/<Feature>/
│   ├── UseCases/<Feature>/
│   └── Errors/
├── Data/
│   ├── Repositories/<Feature>/
│   ├── DataSources/Remote/<Feature>/
│   ├── DataSources/Local/<Feature>/
│   ├── DTOs/<Feature>/
│   └── Mappers/<Feature>/
├── Features/
│   └── <Feature>/
│       ├── Presentation/
│       │   ├── Views/
│       │   ├── ViewModels/
│       │   └── Components/
│       └── Coordinator/
├── Tests/
│   ├── UnitTests/
│   │   ├── Domain/<Feature>/
│   │   ├── Data/<Feature>/
│   │   ├── Presentation/<Feature>/
│   │   └── Mocks/
│   └── UITests/
└── Docs/
```

Call AskUserQuestion to approve the tree. Do not create anything before approval.

## Step 3. Create folders and stubs

For every folder: create it. Add a `.gitkeep` only in folders that would otherwise be empty.

For every file named in the Feature map of `architecture.md`: create a stub with the correct type declaration, a one-line doc comment stating its layer and purpose, and nothing else. Stub template:

```swift
// <FileName>.swift
// Layer: <Domain|Data|Presentation|Core|App>
// Purpose: <one line from architecture.md>

import Foundation

<protocol|struct|final class|enum> <TypeName> {
}
```

Stubs never contain logic. Downstream skills fill them. A stub must compile.

Do not create stubs for files that already exist in `file-map.md`. If a file exists at the wrong path, go to Step 5 instead of creating a duplicate.

## Step 4. Register everything

Append one row per created file to `Docs/file-map.md`:

```
| Features/Invoices/Presentation/ViewModels/InvoiceListViewModel.swift | class | Presentation | Screen state and actions for invoice list | file-structure-organizer |
```

Sort the table by Path after appending.

## Step 5. Audit mode

Walk every `.swift` file. For each, check:

1. Path matches the layer implied by the type name suffix (`ViewModel` in `Features/*/Presentation/ViewModels/`, `RepositoryImpl` in `Data/Repositories/`, and so on per the Naming table in conventions.md)
2. File name equals the primary type name
3. Exactly one top-level type per file
4. No forbidden import for its layer (`import SwiftUI` in Domain, `import Data` in Presentation)
5. File is present in `file-map.md`

Output a table of violations:

```
| File | Violation | Proposed fix |
|---|---|---|
```

Call AskUserQuestion to approve moves. Apply approved moves with `git mv` when in a git repo, plain move otherwise. Update the Xcode project only if using folder-synchronised groups (Xcode 16+). Otherwise tell the user which groups to re-link. Update `file-map.md` for every move.

## Step 6. Place one file mode

Ask for the type name and its responsibility in one line. Answer with the exact path, the reason (which rule in conventions.md), and whether a file with that name already exists in `file-map.md`. If it exists, say so and stop. Never create a second file with the same type name.

## Step 7. Hand off

Tell the user:

> Tree is in place with [n] folders and [n] stub files, all registered in Docs/file-map.md.
>
> Next: say "model the domain" to run domain-modeler, or "build feature [name]" to run feature-builder.

## What this skill produces

1. The complete folder tree under the project root
2. Compilable stub files, one type each
3. Updated `Docs/file-map.md`

## Dependencies

- Requires: `Docs/conventions.md`, `Docs/architecture.md`, `Docs/file-map.md`
- Feeds: every code-generating skill

## Rules

- Always print the tree and get approval before creating anything.
- Always check file-map.md before creating a file. A type name that already exists is never created again.
- Never put logic in a stub.
- Never create catch-all files (Utils, Helpers, Extensions, Constants).
- Never create a folder that conventions.md does not define. Propose a conventions change instead.
- Never move a file without approval.
- Never use em dashes in any output file.
