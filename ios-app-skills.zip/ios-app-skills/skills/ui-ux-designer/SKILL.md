---
name: ui-ux-designer
description: >
  Design the visual and interaction system of the app: design tokens (colour, typography, spacing, radius, motion), component inventory, screen wireframes as text, and interaction rules following Apple Human Interface Guidelines. Produces Docs/design-system.md and DesignSystem/Tokens/ files. Use this skill whenever the user says "design the UI", "design system", "tokens", "colour palette", "typography", "wireframe", "how should this screen look", "UX for", "conçois l'interface", "design system", "palette", "typographie", "maquette", "à quoi doit ressembler", or before view-generator runs for the first time. Requires ios-project-foundation. Reads Docs/product.md.
---

# UI/UX Designer

## Prerequisites check

Check for `Docs/project-brief.md` and `Docs/conventions.md`. If missing, say:

> The design system follows the product brief. Run ios-project-foundation first.

Then stop. If present, read both plus `Docs/product.md`, `Docs/Features/*.md` and `Docs/design-system.md` if present. If `design-system.md` exists, go to Step 6 (extend mode). Otherwise go straight to Step 1.

## Step 1. Gather direction

Call AskUserQuestion:

```json
[
  {
    "question": "Visual direction?",
    "header": "Direction",
    "multiSelect": false,
    "options": [
      {"label": "Native Apple", "description": "System colours, SF fonts, standard controls. Fastest, always HIG compliant."},
      {"label": "Native with brand accent", "description": "System base, one brand colour, custom components where it matters"},
      {"label": "Custom branded", "description": "Full palette, custom type scale, bespoke components"}
    ]
  },
  {
    "question": "Brand inputs?",
    "header": "Brand",
    "multiSelect": false,
    "options": [
      {"label": "I have hex codes and fonts", "description": "I will paste them"},
      {"label": "I have a reference app or screenshots", "description": "I will describe or paste"},
      {"label": "Propose for me", "description": "Derive from the product brief"}
    ]
  },
  {
    "question": "Appearance support?",
    "header": "Appearance",
    "multiSelect": true,
    "options": [
      {"label": "Light and dark", "description": "Both, semantic colours required"},
      {"label": "Dynamic Type", "description": "Full range including accessibility sizes"},
      {"label": "Reduce Motion", "description": "Every animation has a reduced variant"},
      {"label": "iPad layouts", "description": "Size class aware"}
    ]
  }
]
```

Wait for pasted inputs if applicable.

## Step 2. Define tokens

Present the token set in chat. Every token is semantic, never named after its value.

```
Colour (light / dark)
  ds.background.primary      #FFFFFF / #000000
  ds.background.secondary    #F2F2F7 / #1C1C1E
  ds.text.primary            #000000 / #FFFFFF
  ds.text.secondary          #3C3C43 99% / #EBEBF5 60%
  ds.accent                  <brand> / <brand adjusted>
  ds.status.success / warning / danger / info

Typography (Dynamic Type mapped)
  ds.font.largeTitle   → .largeTitle, bold
  ds.font.title        → .title2, semibold
  ds.font.body         → .body
  ds.font.caption      → .caption

Spacing (4pt grid)
  ds.space.xs 4 · s 8 · m 16 · l 24 · xl 32 · xxl 48

Radius
  ds.radius.s 6 · m 12 · l 20 · pill 999

Motion
  ds.motion.fast 0.15s · standard 0.25s · slow 0.4s, easeInOut
  Reduce Motion: cross-fade only
```

Call AskUserQuestion to approve. Maximum 3 rounds.

## Step 3. Component inventory

From the screens in `Docs/Features/*.md`, list every reusable component the app needs. Prefix `DS`. For each: name, purpose, variants, states, which screens use it.

```
| Component | Purpose | Variants | States | Used by |
|---|---|---|---|---|
| DSScreen | Page container, title, background, safe areas | plain, grouped | none | every screen |
| DSButton | Primary action | primary, secondary, destructive, ghost | enabled, disabled, loading | Form, Detail |
| DSEmptyState | No content placeholder | with action, without | none | List screens |
| DSErrorState | Failure with retry | inline, fullscreen | none | every loading screen |
| DSLoadingView | Progress placeholder | inline, fullscreen | none | every loading screen |
| DSCard | Grouped content block | elevated, flat | none | Dashboard, Detail |
| DSTextField | Text input with validation | default, secure, multiline | idle, focused, error | Form |
| DSBadge | Status label | success, warning, danger, neutral | none | Rows |
```

A component earns a row only if two or more screens use it, or if it encodes a rule (validation display, loading). Feature-only components stay in the feature folder and are not listed here.

## Step 4. Wireframes

For each P0 screen, a text wireframe:

```
┌─────────────────────────────┐
│ ‹ Back        Invoices   [+]│  DSScreen title, toolbar
├─────────────────────────────┤
│ 🔍 Search                   │  .searchable
├─────────────────────────────┤
│ ▢ Acme Corp      €1,200  ● │  InvoiceRow: title, amount, DSBadge
│ ▢ Globex         €340    ● │
│ ...                         │
├─────────────────────────────┤
│ (empty) DSEmptyState        │  when no invoices
└─────────────────────────────┘
```

Plus interaction notes per screen: tap targets, swipe actions, haptics, transitions, empty and error behaviour.

## Step 5. Write the files

`Docs/design-system.md`:

```
# Design System

## Direction
[From Step 1, 2 sentences]

## Tokens
[Step 2 block, final]

## Components
[Step 3 table]

## Wireframes
[Step 4, one per P0 screen]

## Interaction rules
[Haptics policy, animation policy, loading policy, error display policy, empty state policy]

## Accessibility
[Dynamic Type range, VoiceOver labelling rule, contrast minimum 4.5:1, Reduce Motion behaviour, minimum tap target 44pt]

## HIG references
[Which HIG patterns each screen type follows]
```

Token files, one per category, under `DesignSystem/Tokens/`:

```swift
// DSColor.swift
// Layer: DesignSystem
// Purpose: Semantic colour tokens, light and dark

import SwiftUI

enum DSColor {
    static let backgroundPrimary = Color("ds.background.primary", bundle: .main)
    static let textPrimary = Color("ds.text.primary", bundle: .main)
    static let accent = Color("ds.accent", bundle: .main)
}
```

Colour values go into `App/Resources/Assets.xcassets` as colour sets with light and dark appearances. Never hex literals in Swift. `DSFont`, `DSSpacing`, `DSRadius`, `DSMotion` follow the same pattern with static constants.

Register every file in `Docs/file-map.md`.

## Step 6. Extend mode

If `design-system.md` exists, ask what to add: a token, a component row, a wireframe. Add only that. Never rename an existing token. If a token must change value, change it in the asset catalogue and note the date in the doc.

## Step 7. Hand off

Tell the user:

> Design system is written: [n] tokens, [n] components inventoried, [n] wireframes. Say "build the component library" to run swiftui-component-library and implement the DS components.

## What this skill produces

1. `Docs/design-system.md`
2. `DesignSystem/Tokens/DSColor.swift`, `DSFont.swift`, `DSSpacing.swift`, `DSRadius.swift`, `DSMotion.swift`
3. Colour sets in the asset catalogue

## Dependencies

- Requires: `Docs/project-brief.md`, `Docs/conventions.md`
- Reads if present: `Docs/product.md`, `Docs/Features/*.md`
- Feeds: swiftui-component-library, view-generator

## Rules

- Always name tokens semantically. Never `blue500`, always `accent` or `status.info`.
- Always provide light and dark values for every colour.
- Always map typography to Dynamic Type styles. Never fixed point sizes as the primary scale.
- Never put hex literals in Swift files.
- Never inventory a component used by only one screen.
- Every interactive element meets 44pt and 4.5:1 contrast.
- Never use em dashes in any output file.
