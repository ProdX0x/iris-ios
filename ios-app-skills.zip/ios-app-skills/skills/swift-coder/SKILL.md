---
name: swift-coder
description: >
  Write or modify Swift code inside an existing file with strict respect for Docs/conventions.md: minimal targeted edits, layer rules, naming, no duplication, no dead code. The general-purpose implementation skill used when no specialised generator applies, and for bug fixes. Use this skill whenever the user says "write the code for", "implement this function", "fix this bug", "refactor this", "add this method", "why does this crash", "écris le code", "implémente", "corrige ce bug", "refactore", "ajoute cette méthode", "pourquoi ça plante", or pastes Swift code asking for changes. Requires ios-project-foundation.
---

# Swift Coder

## Prerequisites check

Check for `Docs/conventions.md` and `Docs/file-map.md`. If missing, say:

> I write code against the project conventions. Run ios-project-foundation first, or say "no conventions" to proceed with Apple defaults for this one task.

If the user says "no conventions", proceed with Swift API Design Guidelines and note that nothing is registered. Otherwise read both files plus `Docs/architecture.md` and `Docs/domain-model.md` if present. Go straight to Step 1.

## Step 1. Locate the change

Call AskUserQuestion:

```json
[
  {
    "question": "What kind of change?",
    "header": "Change",
    "multiSelect": false,
    "options": [
      {"label": "Bug fix", "description": "Something is wrong, minimal targeted fix"},
      {"label": "New function or method", "description": "Add behaviour to an existing type"},
      {"label": "Refactor", "description": "Same behaviour, better structure"},
      {"label": "Explain or diagnose", "description": "No edit yet, tell me what is happening"}
    ]
  }
]
```

Ask for the file path or the pasted code if not given. Read the whole file. Read every type it references that lives in the project.

Before proposing anything, search `Docs/file-map.md` and grep the codebase for a function or type that already does what is being asked. If one exists, propose reusing it instead of writing new code. State the path.

## Step 2. Plan the edit

Output a plan before touching anything:

```
File: Features/Invoices/Presentation/ViewModels/InvoiceListViewModel.swift
Change 1 (line 42): guard on empty query before filtering
  Before: return items.filter { $0.title.contains(searchQuery) }
  After:  guard !searchQuery.isEmpty else { return items }
          return items.filter { $0.title.localizedCaseInsensitiveContains(searchQuery) }
Reason: R-07, empty query returns everything, and search must be case insensitive
Layer check: Presentation, allowed
Duplication check: no existing filter helper in file-map.md
```

For bug fixes: only lines that cause the bug. If you notice an unrelated improvement, list it under `Not applied` with one line each. Never apply it.

For new code: state which layer it belongs to per conventions.md. If it does not belong in the target file, say where it goes and stop, or redirect to the specialised skill (viewmodel-generator, use-case-generator, data-layer-generator, swiftui-component-library).

Call AskUserQuestion to approve the plan. No edit before approval.

## Step 3. Apply

Use targeted string replacement per change. Never rewrite the whole file for a partial change. Keep the file header comment. Keep existing formatting.

After applying, run a self-check on the edited file:

| Check | Rule |
|---|---|
| Layer | No forbidden import for the file's layer |
| Naming | Matches the Naming table |
| Access | `private` by default |
| Safety | No force unwrap, no `try!`, no `as!` |
| Concurrency | `@MainActor` where UI state is touched, `Sendable` where crossing actors |
| Size | File under 300 lines, function under 40 lines |
| Dead code | No unused variable, parameter, import or function introduced |
| Strings | Catalog keys in catalog mode |

Report any violation you had to accept and why.

## Step 4. Diagnose mode

For "Explain or diagnose": read the code and the call sites. Answer in this order: what happens, why, the exact line, the fix in one sentence. Then offer to apply it via Bug fix mode. No edit.

## Step 5. Register and hand off

If a new file was created (only when the plan justified it), append to `Docs/file-map.md`. If a rule was implemented, add its ID to the `## Business rules` table in `domain-model.md`.

Tell the user:

> Applied [n] change(s) to [file]. [Not applied: list]. Say "generate tests" to cover this, or "dedupe" to check for duplicates across the project.

## What this skill produces

1. Targeted edits in existing files
2. Rarely, a new file registered in `Docs/file-map.md`

## Dependencies

- Requires: `Docs/conventions.md`, `Docs/file-map.md`
- Reads if present: `Docs/architecture.md`, `Docs/domain-model.md`
- Feeds: test-generator, code-deduplicator

## Rules

- Always plan with before and after per change, and get approval, before editing.
- Always search for existing code that does the job before writing new code.
- Never touch lines unrelated to the requested change. Mention, do not apply.
- Never move logic across layers silently. Say it and redirect.
- Never introduce a catch-all file.
- Never leave a TODO. Unfinished work goes in Docs/Features/<name>.md.
- Never use em dashes in any output file.
