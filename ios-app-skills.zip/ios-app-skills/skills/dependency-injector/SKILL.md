---
name: dependency-injector
description: >
  Build and maintain the composition root: a single AppContainer with typed factories for repositories, use cases, ViewModels and coordinators, environment-specific wiring (live, preview, test) and no service locator lookups. Produces Core/DI/ files. Use this skill whenever the user says "wire the dependencies", "dependency injection", "container", "how do I inject", "factory for", "preview container", "test container", "câble les dépendances", "injection de dépendances", "conteneur", "comment injecter", or when coordinator-navigator or view-generator reports a missing factory. Requires use-case-generator and data-layer-generator output.
---

# Dependency Injector

## Prerequisites check

Check for `Docs/conventions.md`, `Docs/architecture.md` and `Docs/file-map.md`. If missing, say:

> DI wires what the architecture defines. Run architecture-designer first.

Then stop. If present, read all three. Read `Core/DI/AppContainer.swift` if it exists. Go straight to Step 1.

## Step 1. Scope

Call AskUserQuestion:

```json
[
  {
    "question": "What to wire?",
    "header": "Scope",
    "multiSelect": false,
    "options": [
      {"label": "Bootstrap the container", "description": "Create AppContainer and the environment variants for the first time"},
      {"label": "One feature", "description": "Add factories for every type of one feature"},
      {"label": "Missing factories", "description": "Scan for make... calls that do not exist and add them"},
      {"label": "Audit", "description": "Find direct instantiations that bypass the container"}
    ]
  }
]
```

## Step 2. Build the dependency graph

From `file-map.md`, collect for the scope every protocol and its implementation, every use case and its `init` parameters, every ViewModel and its `init`, every coordinator. Present the graph:

```
InvoiceListViewModel
  ← FetchInvoicesUseCase        = DefaultFetchInvoicesUseCase
      ← InvoiceRepository       = InvoiceRepositoryImpl
          ← InvoiceRemoteDataSource = URLSessionInvoiceRemoteDataSource ← HTTPClient
          ← InvoiceLocalDataSource  = SwiftDataInvoiceLocalDataSource  ← ModelContainer
  ← DeleteInvoiceUseCase        = DefaultDeleteInvoiceUseCase ← InvoiceRepository
  ← InvoicesNavigating          = InvoicesCoordinator (passed by the coordinator itself)
```

Lifetimes:
- Shared, one instance per app: `HTTPClient`, `ModelContainer`, repositories, data sources. Stored as `lazy var` or `let` in the container.
- Transient, one per screen: use cases (cheap structs), ViewModels. Built by factory methods.
- Coordinators: owned by their parent coordinator, not by the container. The container builds them on request from the parent.

Flag any type that cannot be resolved (missing implementation). Redirect to data-layer-generator or use-case-generator with the exact type name. Do not stub.

Call AskUserQuestion to approve. Maximum 3 rounds.

## Step 3. Generate

`Core/DI/AppContainer.swift`:

```swift
// AppContainer.swift
// Layer: Core
// Purpose: Composition root. The only place concrete types are chosen.

import Foundation
import SwiftData

@MainActor
final class AppContainer {
    static let shared = AppContainer(environment: .live)

    let environment: AppEnvironment

    init(environment: AppEnvironment) {
        self.environment = environment
    }

    // MARK: Shared infrastructure
    lazy var httpClient: HTTPClient = environment.makeHTTPClient()
    lazy var modelContainer: ModelContainer = environment.makeModelContainer()
}
```

`Core/DI/AppEnvironment.swift`: `enum AppEnvironment { case live, preview, test }` with the infrastructure factories per case (live URLSession vs stub client, on-disk vs in-memory ModelContainer).

`Core/DI/AppContainer+<Feature>.swift`, one extension per feature:

```swift
// AppContainer+Invoices.swift
// Layer: Core
// Purpose: Factories for the Invoices feature

import Foundation

extension AppContainer {
    // MARK: Data (shared)
    var invoiceRepository: InvoiceRepository {
        registry.resolve(InvoiceRepository.self) {
            InvoiceRepositoryImpl(
                remote: URLSessionInvoiceRemoteDataSource(client: httpClient),
                local: SwiftDataInvoiceLocalDataSource(container: modelContainer)
            )
        }
    }

    // MARK: Domain (transient)
    func makeFetchInvoicesUseCase() -> FetchInvoicesUseCase {
        DefaultFetchInvoicesUseCase(invoices: invoiceRepository)
    }

    // MARK: Presentation (transient)
    func makeInvoiceListViewModel(coordinator: any InvoicesNavigating) -> InvoiceListViewModel {
        InvoiceListViewModel(
            fetchInvoices: makeFetchInvoicesUseCase(),
            deleteInvoice: makeDeleteInvoiceUseCase(),
            coordinator: coordinator
        )
    }

    func makeInvoicesCoordinator() -> InvoicesCoordinator {
        InvoicesCoordinator(container: self)
    }
}
```

`Core/DI/Registry.swift`: a tiny typed cache (`resolve(_:factory:)`) keyed by `ObjectIdentifier`, used only for shared lifetimes, private to the container. No global lookup API. No string keys.

Preview and test:
- `AppContainer.preview` static in `Core/DI/AppContainer+Preview.swift` under `#if DEBUG`, using in-memory data sources and sample data from `Tests/UnitTests/Mocks/` or DesignSystem sample fixtures.
- Test targets build `AppContainer(environment: .test)` and override repositories through a `override<T>(_:with:)` method available only in `.test` and `.preview`.

## Step 4. Audit mode

Grep the project for `RepositoryImpl(`, `DataSource(`, `UseCase(`, `ViewModel(`, `Coordinator(` outside `Core/DI/`, previews and tests. Each hit is a bypass. Report the table and replace with a factory call after approval.

## Step 5. Register and hand off

Append every file to `Docs/file-map.md`. Write or update the `## Dependency graph` section of `Docs/architecture.md` with the Step 2 graph.

Tell the user:

> Container wired for [scope]: [n] shared instances, [n] factories. Say "wire the navigation" for coordinator-navigator, or "generate tests" to use the test container.

## What this skill produces

1. `Core/DI/AppContainer.swift`, `AppEnvironment.swift`, `Registry.swift`, `AppContainer+Preview.swift`
2. `Core/DI/AppContainer+<Feature>.swift` per feature
3. `## Dependency graph` in `Docs/architecture.md`

## Dependencies

- Requires: `Docs/architecture.md`, `Docs/conventions.md`, implementations from data-layer-generator and use-case-generator
- Feeds: coordinator-navigator, view-generator previews, test-generator

## Rules

- Always one composition root. Never a second container, never a global service locator.
- Always constructor injection. Never property injection, never `@Environment` for domain services.
- Never expose concrete types from factories. Return the protocol.
- Never instantiate a domain or data type outside `Core/DI/`, previews or tests.
- Never stub a missing implementation. Redirect.
- Never use em dashes in any output file.
