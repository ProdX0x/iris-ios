---
name: use-case-generator
description: >
  Generate use cases (interactors) for the Domain layer: one protocol plus one default implementation per user action, orchestrating repositories and business rules. Produces Domain/UseCases/<Feature>/ files. Use this skill whenever the user says "generate the use cases", "create a use case for", "interactor", "application logic for", "wire the domain", "génère les use cases", "crée un use case", "cas d'utilisation", or when viewmodel-generator needs an action that has no use case yet. Requires domain-modeler.
---

# Use Case Generator

## Prerequisites check

Check for `Docs/conventions.md` and `Docs/domain-model.md`. If missing, say:

> Use cases orchestrate entities and repositories. Run domain-modeler first.

Then stop. If present, read both plus `Docs/Features/*.md`, `Docs/file-map.md`, and the `## Business rules` table if it exists. Go straight to Step 1.

## Step 1. Scope

Call AskUserQuestion:

```json
[
  {
    "question": "Which use cases?",
    "header": "Scope",
    "multiSelect": false,
    "options": [
      {"label": "All for one feature", "description": "Derive from the feature spec's screens and acceptance criteria"},
      {"label": "One use case", "description": "I will name the action"},
      {"label": "Whole product", "description": "Every feature in Docs/Features/"}
    ]
  }
]
```

## Step 2. Derive the use case list

From the acceptance criteria and screens, list every user-initiated or system-initiated action. Naming per conventions.md: `<Verb><Noun>UseCase`. Allowed verbs: Fetch, Create, Update, Delete, Search, Sync, Validate, Submit, Toggle, Export, Import. Propose a new verb only with a reason.

Before listing, search `Docs/file-map.md` and `Domain/UseCases/` for each name. Mark existing ones. Existing use cases are never regenerated.

Present:

```
| Use case | Input | Output | Repositories | Rules applied | Error |
|---|---|---|---|---|---|
| FetchInvoicesUseCase | none | [Invoice] | InvoiceRepository | none | InvoiceError |
| CreateInvoiceUseCase | CreateInvoiceInput | Invoice | InvoiceRepository, ClientRepository | R-02 | InvoiceError |
```

Call AskUserQuestion to approve. Maximum 3 rounds.

## Step 3. Generate

One protocol and one implementation per use case. Two files.

`Domain/UseCases/<Feature>/<Verb><Noun>UseCase.swift`:

```swift
// CreateInvoiceUseCase.swift
// Layer: Domain
// Purpose: Create an invoice for a client applying R-02

import Foundation

protocol CreateInvoiceUseCase: Sendable {
    func execute(_ input: CreateInvoiceInput) async throws(InvoiceError) -> Invoice
}

struct CreateInvoiceInput: Sendable, Equatable {
    let clientID: ClientID
    let lines: [InvoiceLine]
    let vatRate: VATRate
}
```

`Domain/UseCases/<Feature>/Default<Verb><Noun>UseCase.swift`:

```swift
// DefaultCreateInvoiceUseCase.swift
// Layer: Domain
// Purpose: Default implementation of CreateInvoiceUseCase

import Foundation

struct DefaultCreateInvoiceUseCase: CreateInvoiceUseCase {
    private let invoices: InvoiceRepository
    private let clients: ClientRepository
    private let calculator: InvoiceTotalCalculator

    init(invoices: InvoiceRepository, clients: ClientRepository, calculator: InvoiceTotalCalculator) {
        self.invoices = invoices
        self.clients = clients
        self.calculator = calculator
    }

    func execute(_ input: CreateInvoiceInput) async throws(InvoiceError) -> Invoice {
        _ = try await clients.fetch(id: input.clientID).mapError(InvoiceError.init)
        let total = calculator.calculate(lines: input.lines, vatRate: input.vatRate)
        let invoice = Invoice(id: InvoiceID(), clientID: input.clientID, lines: input.lines, total: total, status: .draft)
        try await invoices.save(invoice)
        return invoice
    }
}
```

Rules for the body:
- One `execute` method. Exactly one.
- All dependencies are protocols, injected via `init`.
- Input is a dedicated `<Verb><Noun>Input` struct when more than one parameter. Defined in the protocol file.
- No formatting, no UI state, no logging framework.
- Cross-feature reads go through the other feature's repository protocol, never its use case, unless composition is explicit in architecture.md.

If a use case needs a rule not in the rules table, stop and redirect to business-logic-engine. If it needs a repository method that does not exist, stop and redirect to domain-modeler.

## Step 4. Register

Append every file to `Docs/file-map.md`. Add a `## Use cases` section to `Docs/domain-model.md` with the approved table if not present, or merge rows.

## Step 5. Hand off

Tell the user:

> [n] use cases generated under Domain/UseCases/. Say "generate the data layer" to implement the repositories, or "generate the viewmodel for [screen]" to consume them.

## What this skill produces

1. `Domain/UseCases/<Feature>/<Name>UseCase.swift` (protocol and input)
2. `Domain/UseCases/<Feature>/Default<Name>UseCase.swift` (implementation)
3. `## Use cases` table in `Docs/domain-model.md`

## Dependencies

- Requires: `Docs/domain-model.md`, `Docs/conventions.md`
- Feeds: viewmodel-generator, dependency-injector, test-generator

## Rules

- Always search file-map.md before naming a use case.
- Always one protocol plus one default implementation. Never a concrete class alone.
- Never put UI concerns, formatting, or navigation in a use case.
- Never instantiate a repository inside a use case.
- Never let a use case call a ViewModel or a coordinator.
- Never use em dashes in any output file.
