---
name: layer-auditor
description: >
  Verify total consistency between layers and documentation: every import respects the dependency direction, every protocol has one implementation registered in the container, every ViewModel maps every error, every screen in a spec has a View and a ViewModel, every rule has a test, and Docs/file-map.md equals the disk. Produces Docs/audit-<date>.md with a pass or fail verdict. Use this skill whenever the user says "audit the layers", "check consistency", "is the architecture respected", "what is missing", "pre-release check", "review the project", "audite les couches", "vérifie la cohérence", "l'architecture est-elle respectée", "qu'est-ce qui manque", "revue du projet", or as the final gate of feature-builder. Requires ios-project-foundation and architecture-designer.
---

# Layer Auditor

## Prerequisites check

Check for `Docs/conventions.md`, `Docs/architecture.md` and `Docs/file-map.md`. If missing, say:

> The audit checks code against architecture.md and conventions.md. Run the foundation skills first.

Then stop. If present, read all three plus `Docs/domain-model.md`, `Docs/design-system.md`, every `Docs/Features/*.md`. Go straight to Step 1.

## Step 1. Scope

Call AskUserQuestion:

```json
[
  {
    "question": "Audit scope?",
    "header": "Scope",
    "multiSelect": false,
    "options": [
      {"label": "Whole project", "description": "Every check, every file"},
      {"label": "One feature", "description": "Vertical slice from spec to tests"},
      {"label": "Docs versus disk", "description": "Only file-map.md synchronisation"}
    ]
  }
]
```

## Step 2. Run the checks

Each check produces pass, warn or fail with a list of offenders.

**C1. Dependency direction**
Grep every file's imports. Domain: only Foundation. Data: never SwiftUI, never a Features type. Presentation: never a Data type (`Impl`, `DTO`, `DataSource`, `Model` @Model). DesignSystem: never Domain, never Features. Fail on any violation.

**C2. One type per file, name equals file**
Parse top-level declarations. Fail on mismatch.

**C3. Protocol coverage**
Every `Repository`, `UseCase`, `DataSource`, `Navigating` protocol has exactly one non-mock implementation and one factory or property in `Core/DI/`. Warn on zero implementations, fail on two.

**C4. Spec to code**
For each `Docs/Features/<Name>.md`, every screen listed has `<Screen>View.swift` and `<Screen>ViewModel.swift` in file-map.md, every entity listed exists in `Domain/Entities/`, every acceptance criterion ID appears in at least one test name. Fail on missing view or viewmodel, warn on missing test.

**C5. Rules to tests**
Every rule ID in the `## Business rules` table appears in at least one test name. Warn on gaps.

**C6. Error mapping**
Every `case` of every domain error enum is handled in at least one ViewModel `message(for:)` or equivalent, or falls into a documented default. Warn on unmapped cases.

**C7. Navigation**
Every `<Feature>Route` case is handled in `view(for:)`. Every `navigate(to:)` call in ViewModels targets an existing case. No `NavigationLink(destination:)` anywhere in Features. Fail on any.

**C8. Design system**
No `Color(red:`, `Color(hex:`, `.font(.system(size:`, or numeric padding literals in Features or DesignSystem/Components. Warn.

**C9. Safety**
No `!` force unwrap on optionals outside tests and previews, no `try!`, no `as!`, no `fatalError` outside preconditions in `AppEnvironment`. Fail.

**C10. Registry**
file-map.md rows equal the set of `.swift` files on disk, minus build artefacts. Fail on drift, and list both directions.

**C11. Dead documentation**
Every ADR referenced in code comments exists. Every feature spec with `Status: specified` older than the newest code file in its folder is flagged as possibly stale. Warn.

## Step 3. Write the report

`Docs/audit-<YYYY-MM-DD>.md`:

```
# Audit <date>

Scope: <scope>
Verdict: PASS | FAIL (<n> fails, <n> warns)

| Check | Result | Offenders |
|---|---|---|
| C1 Dependency direction | pass | |
| C3 Protocol coverage | fail | ClientRepository: no implementation |
| ... | | |

## Fix plan
[Ordered list: offender, responsible skill, one-line action]
1. ClientRepository has no implementation → data-layer-generator → "generate the data layer for Clients"
2. AC-4 of Invoices untested → test-generator → "generate tests for CreateInvoiceUseCase"
```

Register the report in `Docs/file-map.md` with Layer `Docs`.

## Step 4. Offer fixes

Call AskUserQuestion:

```json
[
  {
    "question": "Next?",
    "header": "Fix",
    "multiSelect": false,
    "options": [
      {"label": "Fix C10 now", "description": "Synchronise file-map.md with disk immediately"},
      {"label": "Walk the fix plan", "description": "Trigger each responsible skill in order"},
      {"label": "Stop here", "description": "I will handle it"}
    ]
  }
]
```

C10 is the only check this skill fixes itself. Everything else is delegated to the responsible skill by name. Never patch code from the auditor.

## Step 5. Hand off

Tell the user:

> Audit written to Docs/audit-<date>.md. Verdict: [PASS | FAIL]. [n] items in the fix plan, each mapped to the skill that owns it.

## What this skill produces

1. `Docs/audit-<date>.md` with verdict, table and ordered fix plan
2. Optionally, a synchronised `Docs/file-map.md`

## Dependencies

- Requires: `Docs/conventions.md`, `Docs/architecture.md`, `Docs/file-map.md`
- Reads: `Docs/domain-model.md`, `Docs/design-system.md`, `Docs/Features/*.md`
- Delegates to: every generator skill, code-deduplicator

## Rules

- Always run every check in scope. Never skip a check because it is slow.
- Always name the responsible skill for every offender.
- Never edit source code from this skill. Only file-map.md.
- A FAIL verdict blocks feature-builder from declaring a feature done.
- Never use em dashes in any output file.
