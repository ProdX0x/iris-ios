---
name: viewmodel-generator
description: >
  Generate MVVM ViewModels for SwiftUI screens: observable state, explicit actions, use case orchestration, error to user-message mapping and navigation intents sent to a coordinator. Produces Features/<Name>/Presentation/ViewModels/ files. Use this skill whenever the user says "generate the viewmodel", "viewmodel for [screen]", "screen state", "MVVM for this view", "génère le viewmodel", "état de l'écran", "logique de présentation", or when view-generator needs a ViewModel that does not exist. Requires use-case-generator output for the actions the screen needs.
---

# ViewModel Generator

## Prerequisites check

Check for `Docs/conventions.md` and `Docs/domain-model.md`. If missing, say:

> ViewModels consume use cases. Run domain-modeler and use-case-generator first.

Then stop. If present, read both plus `Docs/Features/<Feature>.md`, `Docs/architecture.md`, `Docs/file-map.md`. Note the Observation mode in conventions.md (`@Observable` or `ObservableObject`). Go straight to Step 1.

## Step 1. Identify the screen

Call AskUserQuestion:

```json
[
  {
    "question": "Which screen?",
    "header": "Screen",
    "multiSelect": false,
    "options": [
      {"label": "Pick from feature spec", "description": "I will choose from the Screens list in Docs/Features/"},
      {"label": "Describe a new screen", "description": "Not yet in a spec, I will describe it"},
      {"label": "All screens of a feature", "description": "Generate every ViewModel of one feature"}
    ]
  }
]
```

For each target screen, search `Docs/file-map.md` for `<Screen>ViewModel`. If it exists, read it and switch to extend mode: only add missing state or actions, never rewrite.

## Step 2. Design the state and actions

Present in chat before writing:

```
InvoiceListViewModel
  State:
    phase: Phase (.idle | .loading | .loaded([InvoiceRowItem]) | .empty | .failed(message: String))
    searchQuery: String
    isRefreshing: Bool
  Derived:
    filteredItems: [InvoiceRowItem]   (computed, no stored duplicate)
  Actions:
    load()          → FetchInvoicesUseCase
    refresh()       → FetchInvoicesUseCase
    delete(id:)     → DeleteInvoiceUseCase
    select(id:)     → coordinator.navigate(.detail(id))   [navigation intent]
    tapCreate()     → coordinator.navigate(.create)       [navigation intent]
  Presentation models:
    InvoiceRowItem (id, title, amountText, statusBadge)  built from Invoice in Presentation, not in Domain
  Error mapping:
    InvoiceError.notFound → "This invoice no longer exists."
    InvoiceError.storage  → "Could not load invoices. Pull to retry."
```

Rules for the design:
- State is a single `Phase` enum for the main content plus flat properties for controls. Never several booleans that can contradict (`isLoading` and `hasError` both true).
- Every use case the screen needs must exist. If one is missing, stop and redirect to use-case-generator.
- Navigation is an intent sent to a coordinator protocol. The ViewModel never knows the destination View.
- Presentation models (row items, formatted strings) are structs in `Features/<Name>/Presentation/ViewModels/<Screen>+Models.swift` or a dedicated file if reused across screens of the feature.

Call AskUserQuestion to approve. Maximum 3 rounds.

## Step 3. Generate

`@Observable` mode (iOS 17+):

```swift
// InvoiceListViewModel.swift
// Layer: Presentation
// Purpose: State and actions for the invoice list screen

import Foundation
import Observation

@MainActor
@Observable
final class InvoiceListViewModel {
    enum Phase: Equatable {
        case idle, loading, empty
        case loaded([InvoiceRowItem])
        case failed(message: String)
    }

    private(set) var phase: Phase = .idle
    var searchQuery = ""
    private(set) var isRefreshing = false

    var filteredItems: [InvoiceRowItem] {
        guard case .loaded(let items) = phase else { return [] }
        guard !searchQuery.isEmpty else { return items }
        return items.filter { $0.title.localizedCaseInsensitiveContains(searchQuery) }
    }

    private let fetchInvoices: FetchInvoicesUseCase
    private let deleteInvoice: DeleteInvoiceUseCase
    private weak var coordinator: (any InvoicesNavigating)?

    init(fetchInvoices: FetchInvoicesUseCase, deleteInvoice: DeleteInvoiceUseCase, coordinator: any InvoicesNavigating) {
        self.fetchInvoices = fetchInvoices
        self.deleteInvoice = deleteInvoice
        self.coordinator = coordinator
    }

    func load() async {
        phase = .loading
        await fetch()
    }

    func refresh() async {
        isRefreshing = true
        defer { isRefreshing = false }
        await fetch()
    }

    func delete(id: InvoiceID) async {
        do {
            try await deleteInvoice.execute(id)
            await fetch()
        } catch {
            phase = .failed(message: Self.message(for: error))
        }
    }

    func select(id: InvoiceID) {
        coordinator?.navigate(to: .detail(id))
    }

    func tapCreate() {
        coordinator?.navigate(to: .create)
    }

    private func fetch() async {
        do {
            let invoices = try await fetchInvoices.execute()
            phase = invoices.isEmpty ? .empty : .loaded(invoices.map(InvoiceRowItem.init))
        } catch {
            phase = .failed(message: Self.message(for: error))
        }
    }

    private static func message(for error: InvoiceError) -> String {
        switch error {
        case .notFound: String(localized: "invoice.error.notFound")
        case .storage: String(localized: "invoice.error.storage")
        default: String(localized: "error.generic")
        }
    }
}
```

`ObservableObject` mode (iOS 16): same structure with `final class X: ObservableObject`, `@Published private(set) var`, and no `import Observation`.

Rules for the body:
- `@MainActor` always.
- Setters of state are `private(set)`. Only the ViewModel mutates its state.
- No `import SwiftUI`. Foundation and Observation only.
- No direct repository access. Use cases only.
- No `Task { }` inside the ViewModel. Actions are `async`, the View owns the task.
- Strings come from the String Catalog when conventions.md says catalog mode.

Write `<Screen>+Models.swift` for presentation models, with `init(_ entity:)` mapping from the domain entity. Number and date formatting happens here, once.

## Step 4. Coordinator protocol

If `Features/<Name>/Coordinator/<Name>Navigating.swift` does not exist, create it with the routes the ViewModel needs and register it. coordinator-navigator will implement it. Never implement navigation in this skill.

```swift
protocol InvoicesNavigating: AnyObject {
    func navigate(to route: InvoicesRoute)
}
```

## Step 5. Register and hand off

Append every file to `Docs/file-map.md`. Update the Screens section of `Docs/Features/<Name>.md` with `ViewModel: done`.

Tell the user:

> [n] ViewModel(s) generated. Say "generate the view for [screen]" to build the SwiftUI view, or "generate tests" to cover the state transitions.

## What this skill produces

1. `Features/<Name>/Presentation/ViewModels/<Screen>ViewModel.swift`
2. `Features/<Name>/Presentation/ViewModels/<Screen>+Models.swift`
3. `Features/<Name>/Coordinator/<Name>Navigating.swift` if absent

## Dependencies

- Requires: `Docs/conventions.md`, `Docs/domain-model.md`, use cases from use-case-generator
- Feeds: view-generator, coordinator-navigator, dependency-injector, test-generator

## Rules

- Always design state and actions in chat and get approval before generating.
- Always one Phase enum for main content. Never contradictory booleans.
- Never import SwiftUI in a ViewModel.
- Never call a repository, a data source or another ViewModel.
- Never create a Task inside the ViewModel.
- Never hold a destination View. Navigation is an intent.
- Never format in the View what the ViewModel can format in a presentation model.
- Never use em dashes in any output file.
