---
name: coordinator-navigator
description: >
  Implement navigation with the Coordinator pattern on top of NavigationStack: route enums, feature coordinators, AppCoordinator, tab and modal management, deep link routing, all outside the Views. Produces Core/Navigation/ and Features/<Name>/Coordinator/ files. Use this skill whenever the user says "wire the navigation", "coordinator for", "add a route", "deep link", "navigate from X to Y", "tab bar setup", "câble la navigation", "coordinateur", "ajoute une route", "lien profond", "navigation entre écrans", or when a ViewModel emits a navigation intent with no coordinator implementation. Requires architecture-designer (navigation topology) and viewmodel-generator (Navigating protocols).
---

# Coordinator Navigator

## Prerequisites check

Check for `Docs/conventions.md` and `Docs/architecture.md`. If missing, say:

> Navigation follows the topology in architecture.md. Run architecture-designer first.

Then stop. If present, read both, plus `Docs/file-map.md` and every `Features/*/Coordinator/*Navigating.swift`. Go straight to Step 1.

## Step 1. Scope

Call AskUserQuestion:

```json
[
  {
    "question": "What to wire?",
    "header": "Scope",
    "multiSelect": false,
    "options": [
      {"label": "App root", "description": "AppCoordinator, tabs, root stack, first launch"},
      {"label": "One feature", "description": "Routes and coordinator for one feature"},
      {"label": "Add a route", "description": "One new destination in an existing coordinator"},
      {"label": "Deep links", "description": "URL scheme and universal links to routes"}
    ]
  }
]
```

Search `Docs/file-map.md` for existing `AppCoordinator`, `<Feature>Coordinator`, `<Feature>Route`. Existing coordinators are extended, never rewritten.

## Step 2. Define routes

For the feature, one `enum <Feature>Route: Hashable` with one case per destination, carrying only IDs or value types, never entities:

```swift
// InvoicesRoute.swift
// Layer: Presentation
// Purpose: Every destination reachable inside the Invoices feature

import Foundation

enum InvoicesRoute: Hashable {
    case list
    case detail(InvoiceID)
    case create
    case edit(InvoiceID)
}
```

Sheets and full-screen covers get their own enum `enum <Feature>Modal: Identifiable`. Present the routes and the presentation style (push, sheet, cover) per route in a table. Call AskUserQuestion to approve.

## Step 3. Generate the feature coordinator

```swift
// InvoicesCoordinator.swift
// Layer: Presentation
// Purpose: Owns the Invoices navigation stack and builds its screens

import SwiftUI
import Observation

@MainActor
@Observable
final class InvoicesCoordinator: InvoicesNavigating {
    var path = NavigationPath()
    var modal: InvoicesModal?

    private let container: AppContainer

    init(container: AppContainer) {
        self.container = container
    }

    func navigate(to route: InvoicesRoute) {
        switch route {
        case .list: path = NavigationPath()
        case .detail(let id): path.append(InvoicesRoute.detail(id))
        case .create: modal = .create
        case .edit(let id): path.append(InvoicesRoute.edit(id))
        }
    }

    func pop() { if !path.isEmpty { path.removeLast() } }
    func dismissModal() { modal = nil }

    @ViewBuilder
    func view(for route: InvoicesRoute) -> some View {
        switch route {
        case .list: InvoiceListView(viewModel: container.makeInvoiceListViewModel(coordinator: self))
        case .detail(let id): InvoiceDetailView(viewModel: container.makeInvoiceDetailViewModel(id: id, coordinator: self))
        case .create: InvoiceFormView(viewModel: container.makeInvoiceFormViewModel(mode: .create, coordinator: self))
        case .edit(let id): InvoiceFormView(viewModel: container.makeInvoiceFormViewModel(mode: .edit(id), coordinator: self))
        }
    }
}
```

Plus a root view `Features/<Name>/Coordinator/<Feature>CoordinatorView.swift` that owns the `NavigationStack(path:)`, `.navigationDestination(for: <Feature>Route.self)` and `.sheet(item:)` bindings, and nothing else.

The `container.make...` factories must exist. If not, stop and redirect to dependency-injector with the exact list of factories needed.

## Step 4. Generate the app coordinator

`Core/Navigation/AppCoordinator.swift`: owns `selectedTab`, one child coordinator per tab (from the topology in architecture.md), the onboarding or auth gate, and `handle(url:)` for deep links. `Core/Navigation/AppRoute.swift`: top-level routes (tab selection, global modals). `App/<AppName>App.swift` instantiates `AppCoordinator(container: .shared)` once and renders `AppCoordinatorView`.

Deep links: `handle(url:)` parses the URL into an `AppRoute` and forwards to the right child coordinator. Parsing lives in `Core/Navigation/DeepLinkParser.swift`, pure and testable.

## Step 5. Register and hand off

Append every file to `Docs/file-map.md`. Update the Navigation topology in `Docs/architecture.md` if a route was added.

Tell the user:

> Navigation wired for [scope]. [n] routes, [n] modals. Say "wire the dependencies" if factories are missing, or "generate UI tests" to cover the flows.

## What this skill produces

1. `Features/<Name>/Coordinator/<Feature>Route.swift`, `<Feature>Modal.swift`, `<Feature>Coordinator.swift`, `<Feature>CoordinatorView.swift`
2. `Core/Navigation/AppCoordinator.swift`, `AppRoute.swift`, `AppCoordinatorView.swift`, `DeepLinkParser.swift`

## Dependencies

- Requires: `Docs/architecture.md`, `*Navigating.swift` protocols (viewmodel-generator), `AppContainer` factories (dependency-injector)
- Feeds: test-generator, feature-builder

## Rules

- Always one route enum per feature. Routes carry IDs, never entities.
- Always build screens through AppContainer factories. Never `SomeViewModel(...)` inline in a coordinator.
- Never let a View hold a NavigationPath or a destination.
- Never let a coordinator call a use case or a repository.
- Never let two coordinators reference each other directly. Parent to child only, child talks up through a protocol.
- Never use em dashes in any output file.
